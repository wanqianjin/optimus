import { genMessage } from '../helper'
import antdLocale from '@jidu/robot-ui/es/locale/zh_CN'

const modules = import.meta.globEager('./zh-CN/**/*.ts')
export default {
  message: {
    ...genMessage(modules, 'zh-CN'),
    antdLocale,
  },
}
