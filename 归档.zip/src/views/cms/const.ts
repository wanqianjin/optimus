import { message } from '@jidu/robot-ui'

export const auditStatusList = [
  {
    label: '未提交',
    value: 1,
  },
  {
    label: '待审核',
    value: 2,
  },
  {
    label: '已通过',
    value: 3,
  },
  {
    label: '已驳回',
    value: 4,
  },
  {
    label: '灰度中',
    value: 8,
  },
]

/**
 * 投放对象
 *
 */
export const targetUserList = [
  {
    label: '全部用户',
    value: 1,
  },
  {
    label: '指定用户',
    value: 2,
  },
  {
    label: '用户标签',
    value: 3,
  },
]
export const normalTargetUserList = [
  {
    label: '全部用户',
    value: 1,
  },
  {
    label: '指定用户',
    value: 2,
  },
]

export const effectChannelList: { label: String; value: Number }[] = [
  {
    label: '小程序',
    value: 1,
  },
  {
    label: 'APP',
    value: 2,
  },
  // {
  //   label: 'H5',
  //   value: 3,
  // },
]

export const btnStyleOptions = [
  {
    label: '深色',
    value: 1,
  },
  {
    label: '浅色',
    value: 2,
  },
]
// 常态邀请页面提示
const normalTipList = {
  inviterHomePage: '邀请人主页',
  inviteFriendsDetailsPage: '邀请好友明细页',
  inviterRulePage: '规则页',
  inviterPosterPage: '海报页',
  inviterQRCodePage: '二维码页',
  inviteeHomepage: '受邀人主页',
  lotteryDrawpage: '抽奖页',
}
const normalInvitationToastTip = {
  inviterHomePage: {
    39: '活动主图组件',
    41: '海报邀请组件',
    42: '邀请好友引导悬浮条',
    43: '邀请好友工具组件',
    44: '好友列表组件',
    51: '说明事项组件',
  },
  inviteFriendsDetailsPage: { 48: 'tab组件', 44: '好友列表组件', 49: '奖品列表组件' },
  inviterRulePage: { 55: '规则组件' },
  inviterPosterPage: { 45: '海报组件', 307: '海报素材组件' },
  inviterQRCodePage: { 45: '二维码组件' },
  inviteeHomepage: {
    39: '活动主图组件',
    47: '接受邀请组件',
    52: '弹窗组件',
  },
  lotteryDrawpage: {
    57: '抽奖组件',
  },
}
export const cmsToastTipChange = (payload = {}) => {
  Object.keys(payload).forEach((key) => {
    const errorTitle =
      normalTipList[key] +
      '缺少：' +
      payload[key].map((item) => normalInvitationToastTip[key][item])?.join('、')
    message.error(errorTitle)
    throw new Error(errorTitle)
  })
}
// 获取url图片wh
export const getImgWH = (url: string) => {
  return new Promise((resolve) => {
    // 创建实例对象
    const img = new Image()
    // 图片地址
    img.src = url
    img.onload = () => {
      resolve({ width: img.width, height: img.height })
    }
  })
}
// 全等
export const areAllElementsEqual = (arr) => {
  return arr.every((element) => element === arr[0])
}
