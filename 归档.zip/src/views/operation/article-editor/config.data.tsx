import { FormSchema } from '/@/components/Form'
export const Aritcleschemas: FormSchema[] = [
  {
    field: 'title',
    component: 'Input',
    label: '标题',
    componentProps: {
      placeholder: '请输入标题，不超过50字',
      style: { width: '640px' },
      maxLength: 50,
    },
    required: true,
  },
  {
    field: 'authorId',
    component: 'Select',
    label: '作者',
    // helpMessage: ['ApiSelect组件', '远程数据源本地搜索', '只发起一次请求获取所有选项'],
    required: true,
    slot: 'localSearch',
    colProps: {
      span: 8,
    },
  },
  {
    field: 'onChannelList',
    component: 'CheckboxGroup',
    label: '分发渠道',
    required: true,
    componentProps: {
      defaultValue: [4],
      options: [
        {
          label: 'APP发现频道feed',
          value: 4,
        },
        {
          label: '小程序发现频道feed',
          value: 1,
        },
        {
          label: '其它资源位',
          value: 8,
        },
        {
          label: '官网',
          value: 2,
        },
      ],
    },
  },
  {
    field: 'headImage',
    label: '上传文章头图',
    helpMessage: '支持 JPG、PNG 格式，单图不超过 2M，分辨率 1080*1080',
    component: 'Upload',
    slot: 'headImage',
    required: true,
    ifShow: ({ values }) => {
      return (
        values.onChannelList?.includes(4) ||
        values.onChannelList?.includes(1) ||
        values.onChannelList?.includes(8)
      )
    },
  },
  {
    field: 'subTitle',
    label: '副标题',
    component: 'Input',
    required: ({ values }) => {
      if (values.onChannelList?.includes(1) || values.onChannelList?.includes(4)) {
        return true
      }
      return false
    },
    componentProps: {
      placeholder: '用于feed列表摘要展示，不超过80字',
      maxLength: 80,
      style: { width: '640px' },
    },
    ifShow: ({ values }) => {
      return (
        values.onChannelList?.includes(4) ||
        values.onChannelList?.includes(1) ||
        values.onChannelList?.includes(8)
      )
    },
  },
  {
    field: 'cover0302',
    label: '3:2 封面图',
    component: 'Upload',
    slot: 'cover0302',
    helpMessage: '支持 JPG、PNG 格式，单图不超过 2M',
    required: true,
    ifShow: ({ values }) => {
      return values.onChannelList?.includes(1) || values.onChannelList?.includes(4)
    },
  },
  {
    field: 'cover0101',
    label: '1:1 封面图',
    component: 'Upload',
    slot: 'cover0101',
    required: true,
    helpMessage: '支持 JPG、PNG 格式，单图不超过 2M',
    ifShow: ({ values }) => {
      return values.onChannelList?.includes(4)
    },
  },
  {
    field: 'cover1609',
    label: '16:9 封面图',
    component: 'Upload',
    slot: 'cover1609',
    helpMessage: '支持 JPG、PNG 格式，单图不超过 2M',
    ifShow: ({ values }) => {
      return values.onChannelList?.includes(1)
    },
  },
  {
    label: '入口可见范围',
    field: 'visibleScope',
    component: 'RadioGroup',
    componentProps: {
      options: [
        {
          label: '全部',
          value: 0,
        },
        {
          label: 'CDP标签',
          value: 1,
        },
      ],
    },
    defaultValue: 0,
    required: true,
    ifShow: ({ values }) => {
      return values.onChannelList?.includes(4) || values.onChannelList?.includes(1)
    },
  },
  {
    label: 'CDP标签',
    field: 'cdpTagId',
    component: 'Select',
    slot: 'cdpLabelSlot',
    required: true,
    ifShow: ({ values }) => {
      return (
        (values.onChannelList?.includes(4) || values.onChannelList?.includes(1)) &&
        values.visibleScope === 1
      )
    },
  },
  {
    label: '测试内容',
    field: 'searchFlag',
    component: 'RadioGroup',
    componentProps: ({}) => {
      return {
        options: [
          {
            label: '是',
            value: 0,
          },
          {
            label: '否',
            value: 1,
          },
        ],
      }
    },
    defaultValue: 1,
    required: true,
    ifShow: ({ values }) => {
      return (
        values.onChannelList?.includes(4) ||
        values.onChannelList?.includes(1) ||
        values.onChannelList?.includes(8)
      )
    },
  },
  {
    label: '开始展示时间',
    field: 'scheduledPublishStatus',
    component: 'RadioGroup',
    componentProps: ({}) => {
      return {
        options: [
          {
            label: '上架后',
            value: 0,
          },
          {
            label: '定时上架',
            value: 1,
          },
        ],
      }
    },
    defaultValue: 0,
    required: true,
    ifShow: ({ values }) => {
      return (
        values.onChannelList?.includes(4) ||
        values.onChannelList?.includes(1) ||
        values.onChannelList?.includes(8)
      )
    },
  },
  {
    field: 'scheduledPublishTime',
    label: '上架时间',
    component: 'DatePicker',
    required: true,
    componentProps: {
      valueFormat: 'YYYY-MM-DD HH:mm:ss', // 格式化日期格式
      'show-time': true,
      style: {
        width: '320px',
      },
    },
    ifShow: ({ values }) => {
      return (
        values.scheduledPublishStatus === 1 &&
        !(values.onChannelList.length === 1 && values.onChannelList.includes(2))
      )
    },
    helpMessage: '定时上架时间不能晚于定时下架时间',
  },
  {
    label: '下架时间',
    field: 'scheduledRemovalStatus',
    component: 'RadioGroup',
    componentProps: ({}) => {
      return {
        options: [
          {
            label: '永久有效',
            value: 0,
          },
          {
            label: '定时下架',
            value: 1,
          },
        ],
      }
    },
    defaultValue: 0,
    required: true,
    ifShow: ({ values }) => {
      return (
        values.onChannelList?.includes(4) ||
        values.onChannelList?.includes(1) ||
        values.onChannelList?.includes(8)
      )
    },
  },
  {
    field: 'scheduledRemovalTime',
    label: '定时下架时间',
    component: 'DatePicker',
    required: true,
    componentProps: {
      valueFormat: 'YYYY-MM-DD HH:mm:ss', // 格式化日期格式
      'show-time': true,
      style: {
        width: '320px',
      },
    },
    ifShow: ({ values }) => {
      return (
        values.scheduledRemovalStatus === 1 &&
        !(values.onChannelList.length === 1 && values.onChannelList.includes(2))
      )
    },
    helpMessage: '定时下架时间应大于当前时间',
  },
  {
    field: 'subjectImage',
    label: '上传专题封面',
    helpMessage: '支持 JPG、PNG 格式，单图不超过 2M',
    component: 'Upload',
    slot: 'subjectImage',
    ifShow: ({ values }) => {
      return (
        values.onChannelList?.includes(4) ||
        values.onChannelList?.includes(1) ||
        values.onChannelList?.includes(8)
      )
    },
  },
  {
    field: 'labelNameList',
    component: 'Input',
    label: '标签',
    componentProps: {
      placeholder: '请选择标签',
    },
    slot: 'tag',
    colProps: {
      span: 8,
    },
  },
  {
    field: 'hideComment',
    component: 'Switch',
    label: '是否关闭评论',
    componentProps: {
      checkedChildren: '是',
      unCheckedChildren: '否',
      checkedValue: 1,
      unCheckedValue: 0,
    },
    ifShow: ({ values }) => {
      return (
        values.onChannelList?.includes(4) ||
        values.onChannelList?.includes(1) ||
        values.onChannelList?.includes(8)
      )
    },
  },
  {
    field: 'isOpenLive',
    component: 'Switch',
    label: '视频号直播组件总开关',
    componentProps: {
      checkedChildren: '开',
      unCheckedChildren: '关',
    },
    ifShow: ({ values }) => {
      return (
        values.onChannelList?.includes(4) ||
        values.onChannelList?.includes(1) ||
        values.onChannelList?.includes(8)
      )
    },
  },
  {
    label: '直播组件投放时间',
    field: 'timeRange',
    component: 'RangePicker',
    componentProps: {
      'show-time': true,
      placeholder: ['请选择开始时间', '请选择结束时间'],
    },
    required: true,
    ifShow: ({ values }) => values.isOpenLive,
  },
  {
    field: 'liveTitle',
    component: 'Input',
    label: '直播标题',
    required: true,
    componentProps: {
      placeholder: '请输入直播标题',
      maxLength: 20,
      autocomplete: 'off',
      style: { width: '640px' },
    },
    ifShow: ({ values }) => values.isOpenLive,
  },
  {
    field: 'liveDesc',
    component: 'Input',
    label: '直播描述',
    required: true,
    componentProps: {
      placeholder: '请输入直播描述',
      maxLength: 40,
      autocomplete: 'off',
      style: { width: '640px' },
    },
    ifShow: ({ values }) => values.isOpenLive,
  },
  {
    field: 'dyRoomId',
    component: 'Input',
    label: 'App跳抖音直播间ID',
    helpMessage: '若填写，仅在直播中对 极越 App 生效，小程序仍然跳转至视频号',
    componentProps: {
      placeholder: '选填，请输入抖音直播间的 Room ID，请在【极越】视频号同步开播时使用',
      maxLength: 50,
      autocomplete: 'off',
      style: { width: '640px' },
    },
    ifShow: ({ values }) => values.isOpenLive,
  },
  {
    field: 'voteComponentId',
    label: '添加投票',
    component: 'Select',
    slot: 'voteSearch',
    componentProps: {
      placeholder: '请输入投票ID/名称/标题',
    },
    ifShow: ({ values }) => {
      return (
        values.onChannelList?.includes(4) ||
        values.onChannelList?.includes(1) ||
        values.onChannelList?.includes(8)
      )
    },
  },
  {
    label: '内容摘要（用于搜索）',
    field: 'summary',
    component: 'InputTextArea',
    componentProps: {},
    slot: 'summary',
    ifShow: ({ values }) => {
      return (
        values.onChannelList?.includes(4) ||
        values.onChannelList?.includes(1) ||
        values.onChannelList?.includes(8)
      )
    },
  },
  {
    field: 'content',
    component: 'Input',
    label: '内容 ',
    slot: 'Editor',
    helpMessage:
      '(如配置图片跳转链接，请按此格式来进行配置（将XX换成具体链接）APP:XXXX,MINIAPP:XXXX)',
    required: true,
  },
]
