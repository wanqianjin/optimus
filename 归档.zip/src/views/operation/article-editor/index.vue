<template>
  <PageWrapper dense contentClass="p-4">
    <Card :bordered="false">
      <BasicForm @register="register">
        <template #localSearch="{ model, field }">
          <Select
            style="width: 640px"
            v-model:value="model[field]"
            size="middle"
            placeholder="选择作者"
            :options="options"
            :disabled="disabled"
          />
        </template>
        <template #headImage="{ model, field }">
          <BasicUpload
            ref="headImageUpload"
            v-model:uploadValue="model[field]"
            :maxSize="10"
            :model="model"
            :field="field"
            :disabled="disabled"
            list-type="picture-card"
            :acceptType="['jpg', 'png', 'gif']"
          />
        </template>
        <template #cover0302="{ model, field }">
          <BasicUpload
            v-model:uploadValue="model[field]"
            :prop-option="{ disabled: mode === 'view' }"
            :acceptType="['jpg', 'png', 'gif']"
          />
        </template>
        <template #cover0101="{ model, field }">
          <!--  是否是ugc：0-否，1-是） -->
          <BasicUpload
            v-model:uploadValue="model[field]"
            :prop-option="{ disabled: mode === 'view' || model.ugcFlag === 1 }"
            :acceptType="['jpg', 'png', 'gif']"
            @changeValue="headImageUploadChange"
          />
        </template>
        <template #cover1609="{ model, field }">
          <BasicUpload
            v-model:uploadValue="model[field]"
            :prop-option="{ disabled: mode === 'view' }"
            :acceptType="['jpg', 'png', 'gif']"
          />
        </template>
        <template #cdpLabelSlot="{ model, field }">
          <Select
            v-model:value="model[field]"
            showArrow
            allowClear
            placeholder="请选择cdp标签"
            :options="cdpOptions"
            :disabled="mode === 'view'"
          />
        </template>
        <template #subjectImage="{ model, field }">
          <BasicUpload
            ref="subjectImageupload"
            v-model:uploadValue="model[field]"
            :maxSize="10"
            :model="model"
            :field="field"
            :disabled="disabled"
            listType="picture-card"
            :acceptType="['jpg', 'png', 'gif']"
          />
        </template>
        <template #tag="{ model, field }">
          <TagManage :model="model" :field="field" :disabled="disabled" />
        </template>
        <template #Editor="{ model, field }">
          <Editor
            style="width: 758px"
            :model="model"
            :field="field"
            useJDType="article"
            ref="editor"
            :useJDImgUpload="true"
            :setFieldsValue="setFieldsValue"
          />
        </template>
        <template #voteSearch="{ model, field }">
          <Select
            v-model:value="model[field]"
            :options="voteList"
            :disabled="disabled"
            :default-active-first-option="false"
            :filter-option="false"
            :not-found-content="null"
            show-search
            allowClear
            placeholder="请添加投票ID/投票名称/投票标题"
            @search="debounceVoteSearch"
            size="middle"
            style="width: 640px"
          >
            <template #suffixIcon><SearchIcon /></template>
          </Select>
        </template>
        <template #summary="{ model, field }">
          <Input.TextArea
            v-model:value="model[field]"
            :rows="3"
            style="width: 640px"
            :disabled="mode === 'view'"
          />
          <Button
            style="margin: 10px 0"
            type="primary"
            @click="onSummaryOcr"
            :disabled="mode === 'view'"
            >图转文</Button
          >
        </template>
        <template #formFooter>
          <div class="formFooter">
            <Button @click="handleReset">返回</Button>
            <Button
              v-if="!disabled"
              :loading="loading"
              type="primary"
              @click="customSubmitFunc"
              style="margin-left: 20px"
            >
              提交
            </Button>
          </div>
        </template>
      </BasicForm>
    </Card>
  </PageWrapper>
</template>
<script setup lang="ts">
import { BasicForm, useForm } from '/@/components/Form'
import { onMounted, onUnmounted, ref, computed, defineExpose } from 'vue'
import { Select, SelectProps, message, Card, Button, Input } from '@jidu/robot-ui'
import { Aritcleschemas } from './config.data'
import { PageWrapper } from '/@/components/Page'
import { useDebounceFn } from '@vueuse/core'
import { SearchIcon } from '@robot/icon'

import {
  queryAllVestListApi,
  createArticleApi,
  updateArticleApi,
  queryArticleDetailApi,
  queryVoteByArticleApi,
  queryCDPTagListApi,
  summaryOcr,
} from '/@/api/operation'
// import NewBasicUpload from '/@/components/JD/Upload/BasicUpload.vue'
import BasicUpload from '/@/components/JD/Upload/BasicUpload.vue'
import TagManage from '/@/components/JD/TagManage.vue'
import Editor from '/@/components/JD/Editor.vue'
import { useRouter } from 'vue-router'

interface Options {
  label: string
  value: string
}
const editor = ref(null)
let headImageUpload = ref(null)
// let videoUpload = ref(null)
let subjectImageupload = ref(null)
const mode = ref()
const router = useRouter()
let options = ref<SelectProps['options']>([])
let voteList = ref<SelectProps['options']>([])

const [register, { setProps, setFieldsValue, getFieldsValue, validate, clearValidate }] = useForm({
  wrapperCol: {
    span: 10,
  },
  schemas: Aritcleschemas,
  labelWidth: 160,
  showActionButtonGroup: false,
  fieldMapToTime: [['timeRange', ['startTime', 'endTime'], 'YYYY-MM-DD HH:mm:ss']],
})
const disabled = computed(() => {
  return mode.value === 'view'
})

const cdpOptions = ref([])
const getCdplabels = () => {
  queryCDPTagListApi().then((res) => {
    let data = []
    // console.log('cdp标签',res)
    res.forEach((item: any) => {
      data.push({
        value: item.tagId,
        label: item.tagCname,
      })
    })
    cdpOptions.value = data
  })
}
function extractImageUrlsFromRichTextString(richTextString) {
  const imgTagRegex = /<img[^>]+src="([^">]+)"/g
  let match
  const urls = []
  while ((match = imgTagRegex.exec(richTextString)) !== null) {
    urls.push(match[1])
  }
  return urls
}
const onSummaryOcr = async () => {
  const data = getFieldsValue()
  if (data.content) {
    try {
      const urls = extractImageUrlsFromRichTextString(data.content)
      const res = await summaryOcr({ imageUrlList: urls })
      data.summary = res
      setFieldsValue({
        summary: res,
      })
    } catch (error) {
      console.log('error===>', error)
    }
  }
}

// 1:1封面图上传，无专题封面图回填
const headImageUploadChange = (e) => {
  const data = getFieldsValue()
  if (!data.subjectImage) {
    setSubjectImageUploadValue({
      url: e,
      name: '专题封面.png',
    })
  }
}

onMounted(async () => {
  window.addEventListener('beforeunload', handleBeforeunload)
  const routerQuery = router.currentRoute.value?.query
  mode.value = routerQuery?.mode
  const articleId = routerQuery?.articleId

  try {
    await getCdplabels()
    await voteSeach('')
    setFieldsValue({ onChannelList: [4] })
    if (mode.value === 'view' || mode.value === 'edit') {
      const res = await queryArticleDetailApi({ articleId })

      // 为了查看/编辑展示的逻辑， 需要删除为空或者空字符的展示placeholder
      !res?.voteComponentId && delete res.voteComponentId
      // 直播配置信息
      if (res.liveInfo && res.liveInfo.liveTitle) {
        res.isOpenLive = true
        const { liveTitle, liveDesc, startTime, endTime, dyRoomId } = res.liveInfo
        res.liveTitle = liveTitle
        res.liveDesc = liveDesc
        res.timeRange = [startTime, endTime]
        res.dyRoomId = dyRoomId
      }

      res.videoImage &&
        setVideoImageUploadValue({
          url: res.videoImage,
          name: '封面.png',
        })
      res.headImage &&
        setHeadImageUploadValue({
          url: res.headImage,
          name: '头图.png',
        })

      res.subjectImage &&
        setSubjectImageUploadValue({
          url: res.subjectImage,
          name: '专题封面.png',
        })
      res.video &&
        setVideoUploadValue({
          url: res.video,
          name: '视频.mp4',
        })
      // 放到setContentHtmlValue前面，否则RadioGroup类型回显数据会有问题，只走defaultValue值
      setFieldsValue({
        ...res,
      })
      setContentHtmlValue(res.content) // 给编辑器设置初始值

      clearValidate('subTitle')

      // imagesRef.value.setMultipleUploadValue(images)
      if (mode.value === 'view') {
        setEditorDisabled() // 禁用富文本
        setProps({
          disabled: true,
          showSubmitButton: false,
          resetButtonOptions: {
            text: '返回',
          },
        })
      }
    } else {
    }
  } catch (error) {
    console.log('error===>', error)
  }
  queryAllVestListApi({}).then((res) => {
    let data: Options[] = []
    res.forEach((item: any) => {
      data.push({
        value: item.authorId,
        label: item.nickName,
      })
    })
    options.value = data
  })
})
onUnmounted(() => {
  window.removeEventListener('beforeunload', handleBeforeunload)
})
function handleBeforeunload(e) {
  e = e || window.event
  if (e) {
    e.returnValue = '关闭提示' //  Chrome requires returnValue to be set.
  }
  return '关闭提示'
}
const voteSeach = async (value) => {
  // status = -1 为默认搜索全部 1 下架 2 上架。产品需求 全部即可
  const res = await queryVoteByArticleApi({ keyword: value, status: -1 })
  const data: Options[] = []
  res?.voteList.forEach((item) => {
    const label = `${item?.title} - ${item?.typeDesc} - ${item?.statusDesc}`
    data.push({
      value: String(item?.voteId),
      label: label,
    })
  })
  voteList.value = data
}

const debounceVoteSearch = useDebounceFn(voteSeach, 900)

function handleReset() {
  router.push({
    name: 'ArticleList',
  })
}

const loading = ref(false)
async function customSubmitFunc() {
  try {
    await validate()
    const values = getFieldsValue()
    // 如果没有专题封面图且未回填1:1封面图，设置为头图
    if (!values.subjectImage) {
      setSubjectImageUploadValue({
        url: values.headImage,
        name: '专题封面.png',
      })
    }

    // 如果只是官网，则设置 searchFlag 为0，删除副标题，设置定时上下架时间为空
    if (values.onChannelList.length === 1 && values.onChannelList.includes(2)) {
      values.searchFlag = 0
      values.scheduledPublishStatus = 0
      values.scheduledRemovalStatus = 0
      if (!values.subjectId) {
        delete values.subTitle
      }
    }

    // 不是app || 小程序 没有cdp可见范围，比例封面图
    if (!values.onChannelList.includes(1) && !values.onChannelList.includes(4)) {
      delete values.cdpTagId
      delete values.cover0101
      delete values.cover0302
      delete values.cover1609
    }

    if (values.video && !values.videoImage) {
      message.warning('请上传视频封面')
      return
    }
    // 0代表上架后
    if (values.scheduledPublishStatus === 0) {
      values.scheduledPublishTime = ''
    }
    const liveInfoName = ['liveTitle', 'liveDesc', 'startTime', 'endTime', 'dyRoomId']
    // 当关闭直播live 需要删除对应的值
    if (!values?.isOpenLive) {
      liveInfoName.map((item: string) => {
        delete values[item]
      })
    }
    // liveInfo为后端定义字段
    values.liveInfo = {
      liveTitle: values.liveTitle ?? '',
      liveDesc: values.liveDesc ?? '',
      startTime: values.startTime ?? '',
      endTime: values.endTime ?? '',
      dyRoomId: values.dyRoomId ?? '',
    }

    if (values.scheduledPublishStatus === 0) {
      delete values.scheduledPublishTime
    }
    if (values.scheduledRemovalStatus === 0) {
      delete values.scheduledRemovalTime
    }

    // 来自编辑
    loading.value = true
    console.log('values====>', values)
    if (mode.value === 'edit') {
      values.content = values.content?.replace(/&amp;/g, '&') // 解决'&'被转移'&amp;' 导致c端不能正常解析到参数问题
      await updateArticleApi({ ...values, articleId: router.currentRoute.value?.query?.articleId })
    } else {
      values.content = values.content?.replace(/&amp;/g, '&')
      await createArticleApi(values)
    }
    message.success('提交成功')
    setTimeout(
      () =>
        router.push({
          //传递参数使用query的话，指定path或者name都行，但使用params的话，只能使用name指定
          name: 'ArticleList',
        }),
      500,
    )
    loading.value = false
  } catch (error) {
    loading.value = false
  }
}
function setContentHtmlValue(value) {
  editor.value.setContentHtmlValue(value)
}
function setEditorDisabled() {
  editor.value.setEditorDisabled()
}
function setVideoUploadValue(params) {
  // videoUpload.value.setUploadValue(params)
  setFieldsValue({
    video: params.url,
  })
}
function setVideoImageUploadValue(params) {
  setFieldsValue({
    videoImage: params.url,
  })
  // videoImageupload.value.setUploadValue(params)
}
function setHeadImageUploadValue(params) {
  setFieldsValue({
    headImage: params.url,
  })
  // headImageUpload.value.setUploadValue(params)
}
function setSubjectImageUploadValue(params) {
  setFieldsValue({
    subjectImage: params.url,
  })
  // subjectImageupload.value.setUploadValue(params)
}
defineExpose({
  customSubmitFunc,
  setFieldsValue,
  setProps,
  setContentHtmlValue,
  setEditorDisabled,
  setVideoUploadValue,
  setVideoImageUploadValue,
  setHeadImageUploadValue,
  getFieldsValue,
  setSubjectImageUploadValue,
})
</script>
<style lang="less" scoped>
.form-wrap {
  padding: 24px;
  background-color: @component-background;
}

.formFooter {
  margin-left: 160px;
}
</style>
