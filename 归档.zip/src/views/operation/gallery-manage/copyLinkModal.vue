<template>
  <BasicModal
    v-bind="$attrs"
    @register="registerModal"
    title="复制链接"
    :minHeight="20"
    width="800px"
    :destroyOnClose="true"
    @ok="handleConfirm"
  >
    <div class="pt-3px pr-3px">
      <Form.Item name="miniProgram" labelAlign="left" :wrapper-col="{ offset: 1 }">
        <span style="margin-right: 10px">小程序链接:</span>
        <Input
          v-model:value="miniProgram"
          style="width: 400px; margin-right: 10px"
          :disabled="true"
        />
        <Button @click="handleCopyLink({ link: miniProgram, type: '小程序' })">复制</Button>
      </Form.Item>
      <Form.Item name="htmlLink" labelAlign="left" :wrapper-col="{ offset: 1 }">
        <span style="margin-right: 32px">H5链接:</span>
        <Input v-model:value="htmlLink" style="width: 400px; margin-right: 10px" :disabled="true" />
        <Button @click="handleCopyLink({ link: htmlLink, type: 'H5' })">复制</Button>
      </Form.Item>
    </div>
  </BasicModal>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { BasicModal, useModalInner } from '/@/components/Modal'
import { Form, Button, Input, message } from '@jidu/robot-ui'
import copy from 'copy-to-clipboard'

let miniProgram = ref('')
let htmlLink = ref('')
const httpBase = {
  dev: {
    jidu: 'https://m.jidudev.com',
  },
  test: {
    jidu: 'https://m.jidutest.com',
  },
  staging: {
    jidu: 'https://m.jidustaging.com',
  },
  alpha: {
    jidu: 'https://m-alpha.jidustaging.com',
  },
  prod: {
    jidu: 'https://m.jiduapp.cn',
  },
}
let VITE_APP_ENV = import.meta.env.VITE_APP_ENV
const [registerModal, { closeModal }] = useModalInner((data) => {
  htmlLink.value = `${httpBase[VITE_APP_ENV].jidu}/hybrid/pages/atlas?pictureStoreId=${data.record.pictureStoreId}`
  miniProgram.value = htmlLink.value
})

function handleConfirm() {
  closeModal()
}

function handleCopyLink(params) {
  const { link, type } = params
  copy(link)
  message.success(`${type}链接复制成功`)
}
</script>

<style lang="less" scoped>
.prompt {
  position: absolute;
  left: 40px;
  bottom: 20px;
}
</style>
