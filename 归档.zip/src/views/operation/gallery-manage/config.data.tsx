import { BasicColumn } from '/@/components/Table/src/types/table'
import { FormProps } from '/@/components/Table'

export function getBasicTableColumns(): BasicColumn[] {
  return [
    {
      title: '图库ID',
      dataIndex: 'pictureStoreId',
      width: 200,
    },
    {
      title: '图库标题',
      dataIndex: 'title',
      width: 150,
    },
    {
      title: '发布时间',
      dataIndex: 'releaseTime',
      width: 240,
    },
    {
      title: '状态',
      dataIndex: 'status',
      width: 150,
      slots: { customRender: 'status' },
    },
    {
      title: '渠道',
      dataIndex: 'onChannelList',
      width: 160,
      slots: { customRender: 'onChannelList' },
    },
  ]
}

export function getFormConfig(): Partial<FormProps> {
  return {
    labelWidth: 100,
    schemas: [
      {
        label: '图库标题',
        field: 'title',
        component: 'Input',
        colProps: {
          xl: 6,
          xxl: 6,
        },
      },
      {
        label: '图库ID',
        field: 'pictureStoreId',
        component: 'Input',
        colProps: {
          xl: 6,
          xxl: 6,
        },
      },
      {
        label: '状态',
        field: 'status',
        component: 'Select',
        colProps: {
          xl: 6,
          xxl: 6,
        },
        componentProps: () => {
          return {
            options: [
              {
                label: '全部',
                value: -1,
              },
              {
                label: '未上架',
                value: 1,
              },
              {
                label: '已上架',
                value: 2,
              },
            ],
          }
        },
      },
      {
        label: '渠道',
        field: 'onChannel',
        component: 'Select',
        colProps: {
          xl: 6,
          xxl: 6,
        },
        componentProps: () => {
          return {
            options: [
              {
                label: '全部',
                value: 0,
              },
              {
                label: '小程序',
                value: 1,
              },
              {
                label: 'APP',
                value: 4,
              },
            ],
          }
        },
      },
    ],
  }
}
