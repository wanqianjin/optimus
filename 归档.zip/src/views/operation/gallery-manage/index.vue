<template>
  <PageWrapper dense>
    <BasicTable @register="registerTable">
      <template #toolbar>
        <Button
          type="primary"
          @click="handleCreate"
          :disabled="!hasPermission('/operation/gallery-create')"
          >新增</Button
        >
      </template>
      <template #status="{ record }">
        <Switch
          :checked="record.status"
          :checked-value="2"
          :un-checked-value="1"
          :checked-children="record.statusDesc"
          :un-checked-children="record.statusDesc"
          @change="(value) => handleStatusChange(record, value)"
          :loading="record.pictureStoreId === currentId && statusload"
          :disabled="!hasPermission('operation_gallery-manage_status_click')"
        />
      </template>
      <template #onChannelList="{ record }">
        <div>
          {{
            record.onChannelList[1]
              ? '小程序,App'
              : record.onChannelList[0] === 1
              ? '小程序'
              : 'APP'
          }}
        </div>
      </template>
      <template #action="{ record }">
        <Button
          type="link"
          size="small"
          @click="handlePreview(record.pictureStoreId)"
          :disabled="!hasPermission('/operation/gallery-view')"
          >查看</Button
        >
        <Button
          type="link"
          size="small"
          @click="handleEdit(record.pictureStoreId)"
          :disabled="!hasPermission('/operation/gallery-create')"
          >编辑</Button
        >
        <Button type="link" size="small" @click="showDrawer(record)">预览</Button>
        <Button
          v-if="record.status === 2"
          type="link"
          size="small"
          @click="handleCopyLink(record)"
          :disabled="!hasPermission('operation_gallery-manage_copy_click')"
        >
          复制链接
        </Button>
        <Button
          v-if="record.status === 1"
          type="link"
          size="small"
          @click="handleDelete(record)"
          :disabled="!hasPermission('operation_gallery-manage_delete_click')"
        >
          删除
        </Button>
      </template>
    </BasicTable>
    <contentDrawer :links="previewLink" :visible="visible" @close="closeDrawer" />
    <copyLinkModal @register="registerCopyModal" />
  </PageWrapper>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { PageWrapper } from '/@/components/Page'
import { BasicTable, useTable } from '/@/components/Table'
import { useModal } from '/@/components/Modal'
import { Button, Modal, message, Switch } from '@jidu/robot-ui'
import copyLinkModal from './copyLinkModal.vue'
import { getBasicTableColumns, getFormConfig } from './config.data'
import { useRouter } from 'vue-router'
import {
  deletePictureStoreApi,
  queryPictureStoreListApi,
  updatePictureStoreApi,
} from '/@/api/operation'
import { usePermission } from '/@/hooks/web/usePermission'
import contentDrawer from '../components/contentDrawer.vue'

const { hasPermission } = usePermission()
const router = useRouter()
let VITE_APP_ENV
let currentId = ref('')
let statusload = ref(false)

const visible = ref<boolean>(false)
// 二维码预览需要的url
const previewLink = ref({
  h5Link: '',
  miniLink: '',
})
const httpBase = {
  dev: {
    jidu: 'https://m.jidudev.com',
  },
  test: {
    jidu: 'https://m.jidutest.com',
  },
  staging: {
    jidu: 'https://m.jidustaging.com',
  },
  alpha: {
    jidu: 'https://m-alpha.jidustaging.com',
  },
  prod: {
    jidu: 'https://m.jiduapp.cn',
  },
}

const [registerTable, { reload }] = useTable({
  title: '投放列表',
  columns: getBasicTableColumns(),
  api: queryPictureStoreListApi,
  useSearchForm: true,
  formConfig: getFormConfig(),
  canResize: false,
  showTableSetting: true,
  striped: false,
  actionColumn: {
    width: 240,
    title: '操作',
    dataIndex: 'action',
    slots: { customRender: 'action' },
  },
})

const [registerCopyModal, { openModal: openCopyModal }] = useModal()

onMounted(() => {
  VITE_APP_ENV = import.meta.env.VITE_APP_ENV
})

async function handleStatusChange(record, value) {
  currentId.value = record.pictureStoreId
  let hide
  //下架
  if (value === 1) {
    try {
      hide = message.loading('下架中')
      statusload.value = true
      await updatePictureStoreApi({
        pictureStoreId: record.pictureStoreId,
        status: value,
        onChannelList: record.onChannelList,
      })
      hide()
      message.success('下架成功')
      statusload.value = false
      reload()
    } catch (error) {
      hide()
      statusload.value = false
    }
  } else {
    // 上线
    let hide
    try {
      hide = message.loading('上架中')
      statusload.value = true
      await updatePictureStoreApi({
        pictureStoreId: record.pictureStoreId,
        status: value,
        onChannelList: record.onChannelList,
      })
      hide()
      message.success('上架成功')
      statusload.value = false
      reload()
    } catch (error) {
      hide()
      statusload.value = false
    }
  }
}

function handleCreate() {
  router.push({
    name: 'GalleryCreate',
    params: { mode: 'create' },
  })
}

function handlePreview(pictureStoreId) {
  router.push({
    name: 'GalleryView',
    query: {
      mode: 'view',
      pictureStoreId: pictureStoreId,
    },
  })
}

function handleEdit(pictureStoreId) {
  router.push({
    name: 'GalleryCreate',
    query: {
      mode: 'edit',
      pictureStoreId: pictureStoreId,
    },
  })
}
const closeDrawer = () => {
  visible.value = false
}
const showDrawer = (record) => {
  previewLink.value.h5Link = `${httpBase[VITE_APP_ENV].jidu}/hybrid/pages/atlas?pictureStoreId=${record.pictureStoreId}`
  previewLink.value.miniLink = `/pages/h5?url=${encodeURIComponent(previewLink.value.h5Link)}`
  visible.value = true
}

function handleCopyLink(record) {
  openCopyModal(true, { record })
}

function handleDelete(record) {
  Modal.confirm({
    title: '确定要删除吗？',
    content: `确认删除图库《${record.title}》吗？`,
    okText: '确认',
    cancelText: '取消',
    onOk: async () => {
      try {
        await deletePictureStoreApi({
          pictureStoreId: record.pictureStoreId,
        })
        message.success('删除成功')
        reload()
      } catch (error) {
        reload()
      }
    },
  })
}
</script>
