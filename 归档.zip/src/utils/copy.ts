/**
 * 引用与非引用值 深拷贝方法
 */
export function deepClone<T>(data: T): T {
  if (typeof data !== 'object' || typeof data == 'function' || data === null) {
    return data
  }

  let item: any
  if (Array.isArray(data)) {
    item = []
  }

  if (!Array.isArray(data)) {
    item = {}
  }

  for (let i in data) {
    if (Object.prototype.hasOwnProperty.call(data, i)) {
      item[i] = deepClone(data[i])
    }
  }

  return item
}