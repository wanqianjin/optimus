import Jet, { Monitor, BatchSend } from '@jidu/jet-h5' // 此处以 h5 举例
Jet.extend(Monitor) // 就可以使用了！！
Jet.extend(BatchSend)

import { deterMineBorwser } from './index'

let myJet
let userId = ''

const getJet = (userName) => {
  userId = userName || ''
  if (myJet) {
    return myJet
  }
  // 批量上报好像有问题。 logBatchSend，节后找shuo.yu 看下
  myJet = new Jet({
    isCreateUUID: true,
    init: {
      client: 13,
      user_id: userName,
    },
    logUrl: '/api/jadlc/program/logs',
    logBatchSend: true,
    auto: {
      url: '/api/event-collector/event/web/track',
    },
  })
}

/**
 *
 * @param {string} tag 通用字端
 * @param {object} obj 自定义json
 */
const setPerformance = async (tag, obj, url) => {
  if (!myJet) {
    return
  }
  // 过滤无用埋点，比方说结束时间比开始时间还早的， 或者超过5s的
  const { endTime, startTime } = obj
  if (startTime && endTime && (endTime < startTime || endTime - startTime > 5000)) {
    return
  }

  // 上报 duration
  if (startTime && endTime) {
    Object.assign(obj, { duration: endTime - startTime })
  }
  // 获取 path
  if (tag === 'pageLoad' || tag === 'pageAvailable' || tag === 'networkRequestEnd') {
    Object.assign(obj, { path: window.location.pathname })
    // 如果是小程序获取path方式
    // const pages = getCurrentPages(); // 获取加载的页面
    // const currentPage = pages[pages.length - 1]; // 获取当前页面的对象
    // const route = currentPage.route; // 当前页面url
    // Object.assign(obj, {path: route})
  }

  // version 看各自项目
  Object.assign(obj, {
    version: __BUILD_TIME__,
    deviceSource: 'pc',
    browserModel: deterMineBorwser(),
  })

  myJet.log({
    traceId: myJet.createUUID().replace(/-/g, '').slice(0, 32),
    spanId: myJet.createUUID().replace(/-/g, '').slice(0, 16),
    userId,
    desc: `optimus ${tag} ${JSON.stringify(obj)}`, // 描述 string 类型
    level: 'info', // 日志等级 默认 INFO
    url: url || '',
    programType: 'web-optimus',
  })
}

export { getJet, setPerformance }
