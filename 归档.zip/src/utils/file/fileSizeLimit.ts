import { h } from 'vue'
import { Modal } from '@jidu/robot-ui'

/**
 * 上传资源限制大小弹框
 * file: 文件流
 * fileRef: inputdom节点
 * reject: funtion beforeUpload函数promise成功reject
 * resolve: funtion beforeUpload函数promise失败resolve
 * maxSize?: number  上传资源最大值,单位kb,默认350kb
 * title?: string 弹框标题
 * content?: string 弹框内容
 * okText?: string 确认按钮弹框
 * onOk?: Function 确认按钮回调
 * onCancel?: Function 取消按钮回调
 */
type data = {
  file: any
  fileRef: any
  reject: Function
  resolve: Function
  maxSize?: number
  content?: any
  title?: string
  okText?: string
  onOk?: Function
  onCancel?: Function
}

export const beforeUploadFileSizeLimit = (data: data) => {
  // 资源最大值
  const maxSize = data.maxSize || 350
  // 资源大小 kb
  const size = data.file.size / 1024
  // 资源类型
  const isVideo = data.file.type.indexOf('video') > -1
  // 资源最大不能超过2M, 超过就不能上传
  const isLimit = data.file.size / 1024 / 1024 < 2
  if (isVideo) {
    return data.resolve(true)
  }
  // 弹框内容
  const modalContent =
    data?.content ||
    h('div', {}, [
      h('span', '资源不得超过'),
      h('span', { style: { color: 'red' } }, `${maxSize}kb`),
      h('span', ', 当前资源大小'),
      h('span', { style: { color: 'red' } }, `${new Number(size).toFixed(2)}kb`),
      h('span', ', 请修改资源大小后重新上传'),
    ])
  // `资源不得超过${maxSize}kb, 当前资源大小${new Number(size).toFixed(
  //   2,
  // )}kb, 请修改资源大小后重新上传`
  const title = data?.title || '资源大小不符合规范'
  const onOk =
    data.onOk ||
    function () {
      setTimeout(() => {
        data.fileRef.setUploadEmpty()
      })
      return data.reject(false)
    }
  const onCancel =
    data.onCancel ||
    function () {
      if (!isLimit) {
        setTimeout(() => {
          data.fileRef.setUploadEmpty()
        })
        return data.reject(false)
      }
      return data.resolve(true)
    }

  if (size < maxSize) {
    return onCancel()
  }
  Modal.error({
    title,
    content: modalContent,
    closable: true,
    okText: '确认',
    onOk() {
      onOk()
    },
    onCancel() {
      onCancel()
    },
  })
}
