/**
 *
 * @param arr options数组, eg: [{id: 1, name: 'hello'}]
 * @param keyObj 转换的keys对象，比如 {id: 'value', name: 'label'}
 * @returns 转换后的结果[{value: 1, label: 'hello'}]
 */
export const formatOps = (arr: Object[], keyObj: Object): Object[] => {
  if (!keyObj) {
    return arr
  }
  const res: object[] = []
  arr.forEach((element) => {
    const temp: object = {}
    Object.keys(keyObj).forEach((item) => {
      temp[keyObj[item]] = element[item]
    })
    res.push(temp)
  })
  return res
}

export function timeWeekFormat(times) {
  //定义一个日期对象;
  const dateTime = new Date(times)
  //获得系统年份;
  const year = dateTime.getFullYear()
  //获得系统月份;
  let month = dateTime.getMonth() + 1
  //获得系统当月分天数;
  let day = dateTime.getDate()
  //获得系统小时;
  let hours = dateTime.getHours()
  //获得系统分钟;
  let minutes = dateTime.getMinutes()
  //获得系统秒数;
  // var second = dateTime.getSeconds()
  //获得系统星期几;
  let dayCycle = dateTime.getDay()
  //使用数组更改日期样式;
  const dayCycleArray = ['日', '一', '二', '三', '四', '五', '六']
  for (let i = 0; i < 7; i++) {
    if (dayCycle == i) {
      //将dayCycleArray的数赋值到系统星期几里面中去;
      dayCycle = dayCycleArray[i]
    }
  }
  month < 10 ? (month = '0' + month) : month
  day < 10 ? (day = '0' + day) : day
  hours < 10 ? (hours = '0' + hours) : hours
  minutes < 10 ? (minutes = '0' + minutes) : minutes
  // second < 10 ? (second = '0' + second) : second
  //打印完整的系统日期;
  const dateStr = `${year}-${month}-${day} 周${dayCycle} ${hours}:${minutes}`
  return dateStr
}

/**
 * 时间戳转换
 */
export function transformTime(timestamp) {
  if (timestamp) {
    const myDate = new Date(timestamp)
    const year = myDate.getFullYear()
    const month = myDate.getMonth() + 1 < 10 ? '0' + (myDate.getMonth() + 1) : myDate.getMonth() + 1
    const day = myDate.getDate() < 10 ? '0' + myDate.getDate() : myDate.getDate()

    const hour = myDate.getHours() < 10 ? '0' + myDate.getHours() : myDate.getHours()
    const minute = myDate.getMinutes() < 10 ? '0' + myDate.getMinutes() : myDate.getMinutes()
    const second = myDate.getSeconds() < 10 ? '0' + myDate.getSeconds() : myDate.getSeconds()
    return `${year}-${month}-${day} ${hour}:${minute}:${second}`
  } else {
    return timestamp
  }
}
