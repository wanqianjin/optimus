import { defHttp } from '/@/utils/http/axios'

enum Api {
  // 搜索测试
  querySearchResult = '/b/content-backend/backend/content/search',
  // 搜索配置
  querySearch = '/b/content-backend/topSearch/list',
  createSearch = '/b/content-backend/topSearch/create',
  updateSearch = '/b/content-backend/topSearch/update',
  operateSearch = '/b/content-backend/topSearch/operate',
  querySugInfo = '/b/content-backend/topSearch/sugInfo',

  // 卡片配置
  cardCreate = '/b/content-backend/searchCard/create',
  cardUpdate = '/b/content-backend/searchCard/update',
  cardDetail = '/b/content-backend/searchCard/detail',
  cardList = '/b/content-backend/searchCard/list',
}

/**
 * @description: 搜索测试页面获取搜索结果
 */
export const querySearchResult = (params) => {
  return new Promise((resolve) => {
    defHttp.post({ url: Api.querySearchResult, params }).then((res) => {
      // afterFetch取得是res.data.list的数据，这里转换一下
      resolve({
        count: res.searchResultList[0]?.count,
        list: {
          searchResultList: res.searchResultList,
          segmentWordList: res.segmentWordList,
        },
      })
    })
  })
}

/**
 * @description: SUG配置列表
 */
export const querySearch = async (params) => {
  return defHttp.post({ url: Api.querySearch, params })
}

/**
 * @description: 新增热门搜索
 */
export const createSearch = async (params) => {
  return defHttp.post({ url: Api.createSearch, params })
}

/**
 * @description: 编辑热门搜索
 */
export const updateSearch = async (params) => {
  return defHttp.post({ url: Api.updateSearch, params })
}

/**
 * @description: 编辑搜索词/底纹词上架、权重
 */
export const operateSearch = async (params) => {
  return defHttp.post({ url: Api.operateSearch, params })
}

/**
 * @description: 获取搜索sug页接口
 */
export const querySugInfo = async (params) => {
  return defHttp.get({ url: Api.querySugInfo, params })
}

/**
 * @description: 卡片列表
 */
export const cardList = async (params) => {
  return defHttp.post({ url: Api.cardList, params })
}

/**
 * @description: 卡片创建
 */
export const cardCreate = async (params) => {
  return defHttp.post({ url: Api.cardCreate, params })
}

/**
 * @description: 卡片编辑
 */
export const cardUpdate = async (params) => {
  return defHttp.post({ url: Api.cardUpdate, params })
}

/**
 * @description: 卡片详情
 */
export const cardDetail = async (params) => {
  return defHttp.get({ url: Api.cardDetail, params })
}
