import { defHttp } from '/@/utils/http/axios'

enum Api {
  QueryPlatform = '/user-backend/contract/platform',
  CreateContract = '/user-backend/contract/create',
  UpdateContractVersion = '/user-backend/contract/version/edit',
  DeleteContractVersion = '/user-backend/contract/version/del',
  QueryContractList = '/user-backend/contract/list',
  CreateContractVersion = '/user-backend/contract/version/commit',
  ContractVersionList = '/user-backend/contract/version/list',
  QueryContractDetail = '/user-backend/contract/version/preview',
  QueryUnpublishedVersionList = '/user-backend/contract/version/list',
  QueryContractById = '/user-backend/contract/byId',
  QueryNewestVersion = '/user-backend/contract/version/newest',
  QueryPlatformVersion = '/user-backend/contract/platform/version',
  UpdateContract = '/user-backend/contract/update/byId',
  QueryPublishContractList = '/user-backend/contract/version/publish/list',
  PublishVersionContract = '/user-backend/contract/version/publish',
  GetAgreementManagerOptions = '/user-backend/contract/user/list',
}

/**
 * @description: 查询适用渠道
 */
export const queryPlatformApi = (params) => {
  return defHttp.get({ url: Api.QueryPlatform, params })
}

/**
 * @description: 查询协议列表
 */
export const queryContractListApi = (params) => {
  return defHttp.get({ url: Api.QueryContractList, params })
}

/**
 * @description: 创建协议
 */
export const createContractApi = (params) => {
  return defHttp.post({ url: Api.CreateContract, params })
}

/**
 * @description: 编辑某一个版本协议
 */
export const updateContractVersionApi = (params) => {
  return defHttp.post({ url: Api.UpdateContractVersion, params })
}

/**
 * @description: 删除某一个版本协议
 */
export const deleteContractVersionApi = (params) => {
  return defHttp.post({ url: Api.DeleteContractVersion, params })
}

/**
 * @description: 创建协议某一个版本
 */
export const createContractVersionApi = (params) => {
  return defHttp.post({ url: Api.CreateContractVersion, params })
}

/**
 * @description: 查询某个协议下的版本列表
 */
export const contractVersionListApi = (params) => {
  return defHttp.get({ url: Api.ContractVersionList, params })
}

/**
 * @description: 查询某个版本的协议详情
 */
export const queryContractDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryContractDetail, params })
}

/**
 * @description: 查询协议待发布列表
 */
export const queryUnpublishedVersionListApi = (params) => {
  return defHttp.get({ url: Api.QueryUnpublishedVersionList, params })
}

/**
 * @description: 根据协议id查询协议基本信息
 */
export const queryContractByIdApi = (params) => {
  return defHttp.get({ url: Api.QueryContractById, params })
}

/**
 * @description: 根据协议id查询最新协议版本号
 */
export const queryNewestVersionApi = (params) => {
  return defHttp.get({ url: Api.QueryNewestVersion, params })
}

/**
 * @description: 根据platform查询对应的版本号
 */
export const queryPlatformVersionApi = (params) => {
  return defHttp.get({ url: Api.QueryPlatformVersion, params })
}

/**
 * @description: 编辑更新协议
 */
export const updateContractApi = (params) => {
  return defHttp.post({ url: Api.UpdateContract, params })
}

/**
 * @description: 查询协议已发布列表
 */
export const queryPublishContractListApi = (params) => {
  return defHttp.get({ url: Api.QueryPublishContractList, params })
}

/**
 * @description: 发布协议
 */
export const publishVersionContractApi = (params) => {
  return defHttp.post({ url: Api.PublishVersionContract, params })
}

/**
 * @description: 搜索协议管理员
 */
export const getAgreementManagerOptions = (params) => {
  return defHttp.post({ url: Api.GetAgreementManagerOptions, params })
}
