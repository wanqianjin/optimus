import { defHttp } from '/@/utils/http/axios'

enum Api {
  GetUserInfo = '/b/content-backend/user/backend/getUserInfo',
  // GetUserPermission = '/activity-backend-server/resource/getAuthResourceList',
  GetUserPermission = '/b/content-backend/backend/auth/getAuthResourceList',
}

/**
 * @description: getUserInfo
 */
export function getUserInfo() {
  return defHttp.post(
    { url: Api.GetUserInfo },
    {
      errorMessageMode: 'none',
    },
  )
}

/**
 * @description: 获取用户权限信息
 */
export function getUserPermission(params) {
  return defHttp.post(
    { url: Api.GetUserPermission, params },
    {
      errorMessageMode: 'none',
    },
  )
}
