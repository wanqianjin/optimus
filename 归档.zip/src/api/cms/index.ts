import { defHttp } from '/@/utils/http/axios'

enum Api {
  PageAdd = '/user-backend/cms/page/add',
  PageUpdate = '/user-backend/cms/page/update',
  getPageinfo = '/user-backend/cms/page/get',
  PageQueryList = '/user-backend/cms/page/queryList',
  // PageQueryById = '/user-backend/cms/page/queryById',
  PageQueryById = '/user-backend/cms/page/queryByParentPageId',
  // PageComponentAdd = '/user-backend/cms/page/component/add',
  PageComponentAdd = '/user-backend/cms/page/list/add',
  PageauditStatusUpdate = '/user-backend/cms/page/auditStatus/update',
  QueryAuditList = '/user-backend/cms/page/queryAuditList',
  DownloadEventLinks = '/user-backend/cms/page/downloadEventLinks',
  DeletePage = '/user-backend/cms/page/del',

  // 活动页搭建
  UpdatePageStatus = '/user-backend/cms/page/auditStatus/update',
  UpdateActivityPage = '/user-backend/page/update',
  GetActivityList = '/activity-backend-server/common/activity/list',
  GetPosterTemplateListApi = '/activity-backend-server/activity/poster/template/list',
  // 裂变活动
  QueryTemplateListApi = '/user-backend/cms/page/getTemplate',
  // 根据项目获取渠道列表
  QueryChannelListByProject = '/user-backend/cms/page/getChannelListByItemId',

  //展车接口
  getPageInfo = '/user-backend/cms/page/getPageInfo',
  addPageInfo = '/user-backend/cms/page/addPageInfo',

  // 购车   - 精选服务接口-投放对象-用户标签
  getCdpTagList = '/user-backend/cms/page/getCdpTagList',
  getSaleCarInfo = '/user-backend/cms/page/getSaleCarInfo',
  // 常态化邀请 -投放对象-用户分群
  getGroupList = '/user-backend/cms/page/getGroupList',
  // 常态化邀请 -海报-展示渠道
  GetChannelList = '/user-backend/cms/page/getNormalActivityPosterChannel',
  // 常态化邀请 -海报素材-海报素材列表
  GetPosterList = '/b/content-backend/backend/middle/poster/metaList',
  // 常态化邀请 -海报素材-预览海报
  ViewPoster = '/b/content-backend/backend/poster/meta/view',

  // 我的页面配置
  GetTabList = '/user-backend/mine/tablist',
  AddTabConf = '/user-backend/mine/tabConf/add',
  UpdateTabConf = '/user-backend/mine/tabConf/update',
  DelTabConf = '/user-backend/mine/tabConf/del',
  OrderUpdateTabConf = '/user-backend/mine/tabConf/orderUpdate',
  GetDetail = '/user-backend/mine/tabConf/getDetail',

  // 车控页面配置
  GetCarConfigList = '/rvc/admin/homePanel/list', // 车控配置列表
  GetCarConfigEnum = '/rvc/admin/homePanel/config', // 车控配置页枚举值
  GetCarCtrlConfigDetails = '/rvc/admin/homePanel/get', // 车控配置详情
  ChangeCarCtrlConfig = '/rvc/admin/homePanel/op', // 变更配置

  // 看频道页面
  GetTopicArticleList = '/b/content-backend/cms/getTopicArticleList',
  NoteArticleDetail = '/b/content-backend/cms/noteArticleDetail',
  GetSubjectInfo = '/b/content-backend/cms/getSubjectInfo',
  GetPageSubSceneType = '/user-backend/cms/page/getPageSubSceneType',

  // 三个频道公用-修改灰度状态
  auditGrayStatusUpdate = '/user-backend/cms/page/auditStatus/update',
}

/**
 * @description: 页面新增
 */
export const pageAddApi = (params) => {
  return defHttp.post({ url: Api.PageAdd, params })
}
/**
 * @description: 页面修改
 */
export const pageUpdateApi = (params) => {
  return defHttp.post({ url: Api.PageUpdate, params })
}
export const getPageinfoApi = (params) => {
  return defHttp.get({ url: Api.getPageinfo, params })
}
/**
 * @description: 页面列表查询
 */
export const pageQueryListApi = (params) => {
  return defHttp.get({ url: Api.PageQueryList, params })
}

/**
 * @description: 页面查看(组件配置项)
 */
export const pageQueryByIdApi = (params) => {
  const { sceneType, ...data } = params
  if (sceneType === 4) {
    return defHttp.get({ url: Api.getPageInfo, params: data })
  } else {
    return defHttp.get({ url: Api.PageQueryById, params: data })
  }
}

/**
 * @description: 提交审核
 */
export const pageAuditStatusUpdateApi = (params) => {
  return defHttp.post({ url: Api.PageauditStatusUpdate, params })
}

/**
 * @description:  页面保存组件
 */
export const pageComponentAddApi = (params) => {
  return defHttp.post({ url: Api.PageComponentAdd, params })
}

/**
 * @description: 审核管理/待审核页面
 */
export const queryAuditListApi = (params) => {
  return defHttp.get({ url: Api.QueryAuditList, params })
}

// 活动页搭建
/**
 * @description: 删除页面
 */
export const deletePageApi = (params) => {
  return defHttp.post({ url: Api.DeletePage, params })
}

/**
 * @description: 获取关联活动列表
 */
export const getActivityListApi = (params) => {
  return defHttp.get({ url: Api.GetActivityList, params })
}

/**
 * 根据项目查询渠道
 */
export const queryChannelListByProjectApi = (params) => {
  return defHttp.get({ url: Api.QueryChannelListByProject, params })
}

/**
 * @description: 下载事件链接
 */
export const downloadEventLinksApi = (params) => {
  return defHttp.post({ url: Api.DownloadEventLinks, params })
}

/**
 * @description: 获取模板数据（目前只适合活动页搭建）
 */
export const getActivityTempListApi = (params) => {
  // const data = { templateIds: [2, 7] }
  // return Promise.resolve(data)
  return defHttp.get({ url: Api.QueryTemplateListApi, params })
}

/**
 * @description: 活动页搭建-裂变活动-邀请海报获取活动测海报模板
 */
export const getPosterTemplateListApi = (params) => {
  return defHttp.get({ url: Api.GetPosterTemplateListApi, params })
}

// -----展车页面-----
/**
 * @description: 展车配置页数据保存
 */
export const addPageInfoApi = (params) => {
  return defHttp.post({ url: Api.addPageInfo, params })
}

// 精选服务组件
/**
 * @description:投放对象-用户标签（获取选择下拉框数据）
 */
export const getCdpTagListApi = (params) => {
  return defHttp.get({ url: Api.getCdpTagList, params })
}
/**
 * @description:投放对象-用户分群（获取选择下拉框数据）
 *
 */
export const getGroupListApi = (params) => {
  return defHttp.get({ url: Api.getGroupList, params })
}
/**
 * @description:海报-展示渠道（获取选择下拉框数据）
 *
 */
export const getPosterChannelListApi = (params) => {
  return defHttp.get({ url: Api.GetChannelList, params })
}
// 我的页面配置
/**
 * @description: 我的页面list
 */
export const getTabListApi = (params) => {
  return defHttp.get({ url: Api.GetTabList, params })
}
/**
 * @description: 新增我的页面配置
 */
export const addTabConfApi = (params) => {
  return defHttp.post({ url: Api.AddTabConf, params })
}
/**
 * @description: 编辑我的页面配置
 */
export const updateTabConfApi = (params) => {
  return defHttp.post({ url: Api.UpdateTabConf, params })
}
/**
 * @description: 删除我的页面配置
 */
export const delTabConfApi = (params) => {
  return defHttp.post({ url: Api.DelTabConf, params }, { joinParamsToUrl: true })
}
/**
 * @description: 列表排序
 */
export const orderUpdateTabConfApi = (params) => {
  return defHttp.post({ url: Api.OrderUpdateTabConf, params })
}
/**
 * @description: 获取详情
 */
export const getDetailApi = (params) => {
  return defHttp.get({ url: Api.GetDetail, params })
}

// 车控页面配置
/**
 * @description: 车控页面 部分配置项枚举
 */
export const getAllCarConfigEnumApi = (params) => {
  return defHttp.get({ url: Api.GetCarConfigEnum, params })
}
/**
 * @description: 车控页面list
 */
export const getCarConfigListApi = (params) => {
  return defHttp.get({ url: Api.GetCarConfigList, params })
}
/**
 * @description: 获取车控配置详情
 */
export const getCarConfigDetailsApi = (params) => {
  return defHttp.get({ url: Api.GetCarCtrlConfigDetails, params })
}
/**
 * @description: 车控配置变更
 * @params: { confDetail, op(10新增, 11修改配置 19删除 20上架 21下架 30同步环境 40移动排序 41更新排序) }
 * @isTransformResponse: false:不处理响应数据，会返回code，data，msg；true:处理相应数据，只返回data
 */
export const changeCarConfigApi = (params, isTransformResponse = true) => {
  return defHttp.post(
    { url: Api.ChangeCarCtrlConfig, params },
    { isTransformResponse: isTransformResponse },
  )
}
/**
 * @description: 获取海报素材列表
 */
export const getPosterListApi = (params) => {
  return defHttp.post({ url: Api.GetPosterList, params })
}
/**
 * @description: 预览海报
 */
export const viewPosterApi = (params) => {
  return defHttp.post({ url: Api.ViewPoster, params })
}
/**
 * @description:【爱车】查询车型配置信息
 */
export const getSaleCarInfoApi = () => {
  return defHttp.get({ url: Api.getSaleCarInfo }, { isTransformResponse: false })
}
/**
 * @description: 获取话题前4篇数据
 */
export const getTopicArticleList = (params) => {
  return defHttp.post({ url: Api.GetTopicArticleList, params })
}

/**
 * @description: 查询某篇笔记的数据
 */
export const noteArticleDetail = (params) => {
  return defHttp.post({ url: Api.NoteArticleDetail, params })
}
/**
 * @description: 查看专题文章总数
 */
export const getSubjectInfoApi = (params) => {
  return defHttp.post({ url: Api.GetSubjectInfo, params }, { isTransformResponse: false })
}

/**
 * @description: 【看页面】获取子场景配置
 */
export const getPageSubSceneType = (params) => {
  return defHttp.get({ url: Api.GetPageSubSceneType, params }, { isTransformResponse: true })
}

/**
 * @description: 修改页面状态-灰度
 */
export const auditGrayStatusApi = (params) => {
  return defHttp.post({ url: Api.auditGrayStatusUpdate, params })
}
