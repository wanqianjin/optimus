import { defHttp } from '/@/utils/http/axios'
// https://jmock.jiduauto.com/project/607/interface/api/cat_16953
enum Api {
  // -----用户成就管理-----
  getAtomicAchievementList = '/user-ares-backend/ares/backend/atomicAchievement/list',
  createAtomicAchievement = '/user-ares-backend/ares/backend/atomicAchievement/create',
  updateAtomicAchievement = '/user-ares-backend/ares/backend/atomicAchievement/update',
  deleteAtomicAchievement = '/user-ares-backend/ares/backend/atomicAchievement/delete',
  getAtomicAchievementDetail = '/user-ares-backend/ares/backend/atomicAchievement/detail',
  cancelAtomicAchievement = '/user-ares-backend/ares/backend/atomicAchievement/cancel',
  upAtomicAchievement = '/user-ares-backend/ares/backend/atomicAchievement/up',
  downAtomicAchievement = '/user-ares-backend/ares/backend/atomicAchievement/down',
  getAtomicAchievementGrantList = '/user-ares-backend/ares/backend/atomicAchievement/grant/list',
  getCdpInfo = '/user-ares-backend/ares/backend/atomicAchievement/cdpInfo',
  getVehicleVersion = '/user-ares-backend/ares/backend/vehicle/version',
  getDisplayLabel = '/user-ares-backend/ares/backend/atomicAchievement/displayLabel/get',
}

/**
 * @description: 查询成就模版列表
 */
export const getAtomicAchievementListApi = (params) => {
  return defHttp.post({ url: Api.getAtomicAchievementList, params })
}

/**
 * @description: 创建原子成就模版
 */
export const createAtomicAchievementApi = (params) => {
  return defHttp.post({ url: Api.createAtomicAchievement, params })
}
/**
 * @description: 编辑原子成就模版
 */
export const updateAtomicAchievementApi = (params) => {
  return defHttp.post({ url: Api.updateAtomicAchievement, params })
}
/**
 * @description: 删除原子成就模版
 */
export const deleteAtomicAchievementApi = (params) => {
  return defHttp.post({ url: Api.deleteAtomicAchievement, params })
}
/**
 * @description: 回收原子成就模版
 */
export const cancelAtomicAchievementApi = (params) => {
  return defHttp.post({ url: Api.cancelAtomicAchievement, params })
}
/**
 * @description: 原子成就上架
 */
export const upAtomicAchievementApi = (params) => {
  return defHttp.post({ url: Api.upAtomicAchievement, params })
}
/**
 * @description: 原子成就下架
 */
export const downAtomicAchievementApi = (params) => {
  return defHttp.post({ url: Api.downAtomicAchievement, params })
}
/**
 * @description: 原子成就凭证列表
 */
export const getAtomicAchievementGrantListApi = (params) => {
  return defHttp.post({ url: Api.getAtomicAchievementGrantList, params })
}
/**
 * @description: 查询原子成就模版详情
 */
export const getAtomicAchievementDetailApi = (params) => {
  return defHttp.get({ url: Api.getAtomicAchievementDetail, params })
}
/**
 * @description: 查询成就中心cdp人群包信息
 */
export const getCdpInfoApi = (params) => {
  return defHttp.get({ url: Api.getCdpInfo, params })
}
/**
 * @description: 查询车型版本
 */
export const getVehicleVersionApi = (params) => {
  return defHttp.get({ url: Api.getVehicleVersion, params })
}
/**
 * @description: 查询勋章展示分类
 */
export const getDisplayLabelApi = (params) => {
  return defHttp.get({ url: Api.getDisplayLabel, params })
}
