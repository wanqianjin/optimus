export interface IEnrollListEnum {
  value: string
  label: string
}
