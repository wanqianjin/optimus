import { defHttp } from '/@/utils/http/axios'
import { IEnrollListEnum } from './model'
import qs from 'qs'
import { ENV_AK } from '/@/enums/akEnum'

export * as model from './model'

enum Api {
  CreateActivity = '/activity-backend-server/activity/enroll/create',
  GetEnrollField = '/activity-backend-server/activity/enroll/getEnrollField',
  QueryEnrollList = '/activity-backend-server/activity/enroll/queryEnrollList',
  QueryEnrollDetail = '/activity-backend-server/activity/enroll/queryEnrollDetail',
  QueryEnrollBaseInfo = '/activity-backend-server/activity/enroll/baseInfo',
  DeleteActivity = '/activity-backend-server/activity/enroll/delete',
  QueryList = '/activity-backend-server/activity/enroll/queryList',
  AuditEnroll = '/activity-backend-server/activity/enroll/auditEnroll', //审核报名信息弹框
  GetapprovalOpinionList = '/activity-backend-server/activity/enroll/approvalOpinionList', //审核意见列表
  CancelRegister = '/activity-backend-server/activity/enroll/user/cancelEnrollDetail', // 取消报名
  EnrollCityList = '/activity-backend-server/activity/enroll/cityList', //查询城市
  EnrollLocationList = '/activity-backend-server/activity/enroll/locationList', //查询地点
  EnrollSceneList = '/activity-backend-server/activity/enroll/scene/querySceneByLocation', //查询场次
  QueryUserByTel = '/activity-backend-server/activity/user/c-terminal/queryUserByTel', //电话查询
  QueryEnrollForm = '/activity-backend-server/activity/enroll/user/queryEnrollForm', // 查询报名表单详情
  UpdateEnrollDetail = '/activity-backend-server/activity/enroll/user/updateEnrollDetail', //修改报名信息
  ValetEnrol = '/activity-backend-server/activity/enroll/user/valetEnroll', // 代用户报名
  UpdateActivity = '/activity-backend-server/activity/enroll/update',
  QueryActivityDetail = '/activity-backend-server/activity/enroll/queryDetail',
  Download = '/activity-backend-server/activity/enroll/download',
  QueryStock = '/activity-backend-server/activity/enroll/queryStock',
  // DeleteScene = '/activity-backend-server/activity/enroll/scene/delete',
  // SaveScene = '/activity-backend-server/activity/enroll/scene/save',
  // UpdateNoScene = '/activity-backend-server/activity/enroll/scene/update',
  BatchSubmit = '/activity-backend-server/activity/enroll/scene/batchSubmit',
  QuerySceneList = '/activity-backend-server/activity/enroll/scene/queryScene',
  UpStatus = '/activity-backend-server/activity/enroll/status/up',
  DownStatus = '/activity-backend-server/activity/enroll/status/down',
  EnrollList = '/activity-backend-server/activity/enroll/activityList',

  ProvinceCity = '/map-location/district/list/provinceCity',
  GetSuggestion = '/activity/activity/common/suggestion',

  ActivityCity = '/activity-backend-server/activity/enroll/cityList',
  ActivityLocation = '/activity-backend-server/activity/enroll/locationList',
  ActivitySupporter = '/activity-backend-server/activity/enroll/activitySupporter',

  ActivityChannelStatus = '/activity-backend-server/activity/enroll/channel/generatedStatus',
  ActivityChannelDownload = '/activity-backend-server/activity/enroll/channel/download',
  ActivityChannelGenerate = '/activity-backend-server/activity/enroll/channel/generate',

  ActivityChannelList = '/activity-backend-server/activity/enroll/channelList',
}

/**
 * @description: 创建线下活动
 */
export const createActivityApi = (params) => {
  return defHttp.post({ url: Api.CreateActivity, params })
}
/**
 * @description: 更新活动
 */
export const updateActivityApi = (params) => {
  return defHttp.post({ url: Api.UpdateActivity, params })
}
/**
 * @description: 获取活动列表
 */
export const queryListApi = (params) => {
  return defHttp.get({ url: Api.QueryList, params })
}
/**
 * @description:  删除列表活动
 */
export const deleteActivityApi = (params) => {
  return defHttp.post({ url: Api.DeleteActivity, params })
}
/**
 * @description: 获取活动列表详情
 */
export const queryActivityDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryActivityDetail, params })
}

/**
 * @description: 获取地址联想词
 */
export const getSuggestionApi = (params) => {
  return defHttp.get({ url: Api.GetSuggestion, params })
}

/**
 * @description: 获取报名字段列表
 */
export const getEnrollFieldApi = (params) => {
  return defHttp.get({ url: Api.GetEnrollField, params })
}

/**
 * @description: 获取报名列表
 */
export const queryEnrollListApi = (params) => {
  return defHttp.get({
    url: Api.QueryEnrollList,
    params,
    paramsSerializer: (params) => {
      return qs.stringify(params, { arrayFormat: 'repeat' })
    },
  })
}

/**
 * @description: 获取报名详情
 */
export const queryEnrollDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryEnrollDetail, params })
}

/**
 * @description: 报名管理页查询活动基础信息
 */
export const queryEnrollBaseInfoApi = (params) => {
  return defHttp.get({ url: Api.QueryEnrollBaseInfo, params })
}

/**
 * @description: 审核报名
 */
export const auditEnrollApi = (params) => {
  return defHttp.post({ url: Api.AuditEnroll, params })
}

/**
 * @description: 审核意见列表
 */
export const getApprovalOpinionListApi = (params) => {
  return defHttp.get({ url: Api.GetapprovalOpinionList, params })
}

/**
 * @description: 取消报名
 */
export const CancelRegisterApi = (params) => {
  return defHttp.post({ url: Api.CancelRegister, params })
}
/**
 * @description: 查询城市
 */
export const enrollCityListApi = (params) => {
  return defHttp.get({ url: Api.EnrollCityList, params })
}
/**
 * @description: 查询地点
 */
export const enrollLocationListApi = (params) => {
  return defHttp.get({ url: Api.EnrollLocationList, params })
}
/**
 * @description: 查询场次
 */
export const enrollSceneListApi = (params) => {
  return defHttp.get({ url: Api.EnrollSceneList, params })
}
/**
 * @description: 查询电话
 */
export const queryUserByTelApi = (params) => {
  return defHttp.get({ url: Api.QueryUserByTel, params })
}
/**
 * @description: 查询报名表格详情
 */
export const queryEnrollFormApi = (params) => {
  return defHttp.get({ url: Api.QueryEnrollForm, params })
}
/**
 * @description: 修改报名信息
 */
export const updateEnrollDetailApi = (params) => {
  return defHttp.post({ url: Api.UpdateEnrollDetail, params })
}
/**
 * @description: 带用户报名
 */
export const valetEnrolApi = (params) => {
  return defHttp.post({ url: Api.ValetEnrol, params })
}
/**
 * @description: 下载
 */
export const downloadApi = (params) => {
  return defHttp.get(
    {
      url: Api.Download,
      params,
      responseType: 'blob',
      paramsSerializer: (params) => {
        return qs.stringify(params, { arrayFormat: 'repeat' })
      },
    },
    {
      isReturnNativeResponse: true,
      errorMessageMode: 'none',
      isTransformResponse: false,
    },
  )
  // return `${Api.Download}`
}

/**
 * @description: 查询库存接口
 */
export const queryStockApi = (params) => {
  return defHttp.get({ url: Api.QueryStock, params })
}

// /**
//  * @description: 删除场次接口
//  */
// export const deleteSceneApi = (params) => {
//   return defHttp.post({ url: Api.DeleteScene, params })
// }

// /**
//  * @description: 保存场次接口
//  */
// export const saveSceneApi = (params) => {
//   return defHttp.post({ url: Api.SaveScene, params })
// }

// /**
//  * @description: 保存不分场次的接口
//  */
// export const updateNoSceneApi = (params) => {
//   return defHttp.post({ url: Api.UpdateNoScene, params })
// }

/**
 * @description: 批量提交场次信息
 */
export const batchSubmit = (params) => {
  return defHttp.post({ url: Api.BatchSubmit, params })
}

/**
 * @description: 查询场次列表接口
 */
export const querySceneListApi = (params) => {
  return defHttp.get({ url: Api.QuerySceneList, params })
}

/**
 * @description: 获取城市列表
 */
export const getProvinceCity = (params = {}) => {
  const currentEnv = import.meta.env.VITE_APP_ENV
  const targetAK = ENV_AK[currentEnv]
  params.ak = targetAK // 中台接口需要传递ak
  return defHttp.get({ url: Api.ProvinceCity, params })
}

/**
 * @description: 活动上架
 */
export const upStatusApi = (params) => {
  return defHttp.post({ url: Api.UpStatus, params })
}

/**
 * @description: 活动下架
 */
export const downStatusApi = (params) => {
  return defHttp.post({ url: Api.DownStatus, params })
}

/**
 * @description: 查询报名活动可选择列表
 */
export const getEnrollListApi = () => {
  return defHttp.get<IEnrollListEnum[]>({ url: Api.EnrollList })
}

/**
 * @description: 查询城市
 */
export const queryActivityCityApi = (params) => {
  return defHttp.get({ url: Api.ActivityCity, params })
}

/**
 * @description: 查询地点
 */
export const queryActivityLocationApi = (params) => {
  return defHttp.get({
    url: Api.ActivityLocation,
    params,
    paramsSerializer: (params) => {
      return qs.stringify(params, { arrayFormat: 'repeat' })
    },
  })
}

/**
 * @description: 查询活动专家
 */
export const queryActivitySupporterApi = (params) => {
  return defHttp.get({ url: Api.ActivitySupporter, params })
}

interface IQueryActivityChannelParams {
  activityId: string
  type: 1 | 2 // 1：小程序链接   2: H5链接
}

/**
 * @description: 获取渠道码生成状态
 */
export const channelStatus = (params: IQueryActivityChannelParams) =>
  defHttp.get<number>({
    url: Api.ActivityChannelStatus,
    params,
  })

/**
 * @description: 获取渠道码&链接
 */
export const channelDownload = (params: IQueryActivityChannelParams) => {
  return defHttp.get<string>({ url: Api.ActivityChannelDownload, params })
}

/**
 * @description: 生成渠道码&渠道链接
 */
export const channelGenerate = (params: IQueryActivityChannelParams) => {
  return defHttp.get<boolean>({ url: Api.ActivityChannelGenerate, params })
}

/**
 * @description: 按活动查询渠道列表
 */
export const getChannelList = (params: { activityId: string }) => {
  return defHttp.get<{ name: string; code: string }[]>({ url: Api.ActivityChannelList, params })
}
