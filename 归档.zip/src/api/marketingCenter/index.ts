import { defHttp } from '/@/utils/http/axios'
import { QueryDetail, ActivityUpdate } from './model'
import * as trans from './trans'
import { IPoepleType } from '/@/views/marketingCenter/red-envelope-create/config.data'

enum Api {
  QueryMarketingList = '/activity-backend-server/activity/definition/search',
  QueryDetail = '/activity-backend-server/activity/definition/detail',
  Upline = '/activity-backend-server/activity/definition/online',
  Downline = '/activity-backend-server/activity/definition/offline',
  Delete = '/activity-backend-server/activity/definition/delete',
  ActivityTypeEnum = '/activity-backend-server/activity/definition/type/list',
  ProjectEnum = '/channel/channel/queryPrivilegedProjectRelation', // 项目列表
  StrategyConfig = '/activity-backend-server/activity/definition/detailConfig',
  ActivityCreate = '/activity-backend-server/activity/definition/create',
  ActivityUpdate = '/activity-backend-server/activity/definition/update',
  QueryRewadList = '/activity-backend-server/activity/grant/list',
  QueryAwardReallyIdOptions = '/activity-backend-server/activity/definition/equity/search',
  QueryAwardReallyIdOptionsByProject = '/activity-backend-server/activity/definition/equity/searchEquityListWithProjectId', // 根据项目查询权益
  GetStrategyConditionEnums = '/activity-backend-server/activity/strategyCondition/types',
  GetEquityTypesOptions = '/activity-backend-server/activity/equity/types',
  GetActivityIdOptions = '/activity-backend-server/activity/definition/invitation/correlation/search',
  GetCDPOptions = '/activity-backend-server/activity/backend/cdp/group/list',
  QueryNormalInviteList = '/activity-backend-server/activity/definition/list',
  RealTimeGroup = '/activity-backend-server/activity//backend/cdp/realTimeGroup/list', //获取cdp实时分群
  UserRelationStatInfo = '/activity-backend-server/activity/grant/invite/queryUserRelationStatInfo', // 奖励查询-邀请有礼-查询统计信息
  UserRelationList = '/activity-backend-server/activity/grant/invite/queryUserRelationList', // 奖励查询-邀请列表
  // 奖励查询-常态邀请-查询统计信息
  NormalUserRelationStatInfo = '/activity-backend-server/activity/grant/normal/invite/queryUserRelationStatInfo',
  // 奖励查询-常态邀请-邀请列表
  NormalUserRelationList = '/activity-backend-server/activity/grant/normal/invite/queryUserRelationList',
  QueryEventApiV2 = '/activity-backend-server/channel/queryEventV2',
  QueryProjectPersonnel = '/activity-backend-server/channel/queryProjectPersonnel',
  QueryProjectActivity = '/activity-backend-server/channel/queryProjectRelationByLevel',
  GetRedPacketStrategyList = '/activity-backend-server/redPacket/getRedPacketStrategyList',
  GetUserInfoAndNotes = '/activity-backend-server/redPacket/getUserInfoAndNotes',
  GetDefaultRedPacketStrategyDetail = '/activity-backend-server/redPacket/getDefaultRedPacketStrategyDetail',
  CreateRedPacketStrategy = '/activity-backend-server/redPacket/createRedPacketStrategy',
  UpdateRedPacketStrategy = '/activity-backend-server/redPacket/updateRedPacketStrategy',
  GetRedPacketStrategyDetail = '/activity-backend-server/redPacket/getRedPacketStrategyDetail',
  GetRedPacketGrantRecordsByStrategy = '/activity-backend-server/redPacket/getRedPacketGrantRecordsByStrategy',
  ReleaseRedPacketStrategy = '/activity-backend-server/redPacket/releaseRedPacketStrategy',
  DownRedPacketStrategy = '/activity-backend-server/redPacket/downRedPacketStrategy',
  GetRedPacketReceiveRecordsByStrategy = '/activity-backend-server/redPacket/getRedPacketReceiveRecordsByStrategy',
  ChannelStatus = '/activity-backend-server/activity/definition/channel/queryGenerateCodeStatus', //查询状态
  ChannelGenerate = '/activity-backend-server/activity/definition/channel/generate', //生成渠道链接码
  ChannelDownload = '/activity-backend-server/activity/definition/channel/downloadChannelCodeLink', //下载
}

export const channelGenerateApi = (params) => {
  return defHttp.get({ url: Api.ChannelGenerate, params })
}
export const channelStatusApi = (params) => {
  return defHttp.get({ url: Api.ChannelStatus, params })
}
export const channelDownloadApi = (params) => {
  return defHttp.get({ url: Api.ChannelDownload, params })
}
/**
 * @description: 获取营销活动列表接口: https://jmock.jiduauto.com/project/110/interface/api/38451
 */
export const queryMarketingListApi = (params) => {
  return defHttp.get({ url: Api.QueryMarketingList, params })
}

export const queryNormalInviteListApi = (params) => {
  return defHttp.get({ url: Api.QueryNormalInviteList, params })
}

/**
 * @description: 获取营销活动详情: https://jmock.jiduauto.com/project/110/interface/api/38695
 */
export const queryDetailApi = async (params) => {
  const res = await defHttp.get<QueryDetail>({ url: Api.QueryDetail, params })
  return trans.transDetail(res)
}

/**
 * @description: 活动上架: https://jmock.jiduauto.com/project/110/interface/api/38439
 */
export const uplineApi = (params) => {
  return defHttp.post({ url: Api.Upline, params })
}

/**
 * @description: 活动下架: https://jmock.jiduauto.com/project/110/interface/api/38443
 */
export const downlineApi = (params) => {
  return defHttp.post({ url: Api.Downline, params })
}

/**
 * @description: 活动删除: https://jmock.jiduauto.com/project/110/interface/api/38535
 */
export const deleteApi = (params) => {
  return defHttp.post({ url: Api.Delete, params })
}

/**
 * @description: 活动类型查询: https://jmock.jiduauto.com/project/110/interface/api/38471
 */
export const activityTypeEnumApi = (params) => {
  return defHttp.get({ url: Api.ActivityTypeEnum, params })
}

/**
 * 获取项目列表
 * @params
 */
export const projectEnumApi = (params) => {
  return defHttp.get({ url: Api.ProjectEnum, params })
}

/**
 * @description:新建营销活动
 */
export const activityCreateApi = (params: ActivityUpdate) => {
  const transParam = trans.transSave(params)
  return defHttp.post({ url: Api.ActivityCreate, params: transParam })
}

/**
 * @description:更新营销活动
 */
export const activityUpdateApi = (params: ActivityUpdate) => {
  const transParam = trans.transSave(params)
  return defHttp.post({ url: Api.ActivityUpdate, params: transParam })
}

/**
 * @description: 奖励查询
 */
export const queryRewadListApi = (params) => {
  return defHttp.get({ url: Api.QueryRewadList, params })
}

/**
 * @description: 权益id模糊查询
 */
export const queryAwardReallyIdOptions = (params) => {
  return defHttp.get({ url: Api.QueryAwardReallyIdOptions, params })
}

/**
 * @description: 根据项目id查询权益
 */
export const queryAwardReallyIdOptionsByProject = (params) => {
  return defHttp.get({ url: Api.QueryAwardReallyIdOptionsByProject, params })
}

/**
 * @description: 活动策略中触发/限制/执行动作条件类型
 */
export const getStrategyConditionEnums = (params: { activityType: number }) => {
  return defHttp.get({ url: Api.GetStrategyConditionEnums, params })
}

/**
 * @description: 活动权益类型
 */
export const getEquityTypesOptions = (params = {}) => {
  return defHttp.get({ url: Api.GetEquityTypesOptions, params })
}

/**
 * @description: 邀请活动可关联的活动列表
 */
export const getActivityIdOptions = (params = {}) => {
  return defHttp.get({ url: Api.GetActivityIdOptions, params })
}

/**
 * @description: 邀请活动可关联的活动列表
 */
export const getCDPOptions = (params = {}) => {
  return defHttp.get({ url: Api.GetCDPOptions, params })
}

/**
 * @description: 获取 CDP 实时分群
 */
export const getRealTimeGroup = (params = {}) => {
  return defHttp.get({ url: Api.RealTimeGroup, params })
}

/**
 * @description: 奖励查询-邀请有礼-查询统计信息
 */
export const getUserRelationStatInfo = (params = {}) => {
  return defHttp.get({ url: Api.UserRelationStatInfo, params })
}
/**
 * @description: 奖励查询-邀请列表
 */
export const getUserRelationList = (params = {}) => {
  return defHttp.get({ url: Api.UserRelationList, params })
}
/**
 * @description: 奖励查询-常态邀请-查询统计信息
 */
export const getNormalUserRelationStatInfo = (params = {}) => {
  return defHttp.get({ url: Api.NormalUserRelationStatInfo, params })
}
/**
 * @description: 奖励查询-常态邀请-邀请列表
 */
export const getNormalUserRelationList = (params = {}) => {
  return defHttp.get({ url: Api.NormalUserRelationList, params })
}

export const queryEventApiV2 = (params = {}) => {
  return defHttp.get({ url: Api.QueryEventApiV2, params })
}

/**
 * @description: 查询员工项目-项目活动
 */
export const queryProjectPersonnel = (params = {}) => {
  return defHttp.get({ url: Api.QueryProjectPersonnel, params })
}

/**
 * @description: 级联查询「项目」-「活动」列表  渠道事件内使用 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const queryProjectActivityApi = (params) => {
  return defHttp.get({ url: Api.QueryProjectActivity, params })
}

/**
 * @description: 获取红包策略列表
 * @param {*} params
 * @return {*}
 */
export const getRedPacketStrategyList = (params = {}) => {
  return defHttp.post({ url: Api.GetRedPacketStrategyList, params })
}

/**
 * @description: 获取用户信息及备注
 * @param {{ userIdList: Array<string> }} params 用户id列表
 * @return {*}
 */
export const getUserInfoAndNotes = (params: { userIdList: Array<string> }) => {
  return defHttp.post<{
    count: number
    list: IPoepleType[]
  }>({ url: Api.GetUserInfoAndNotes, params })
}

// 回显默认红包策略配置
export const getDefaultRedPacketStrategyDetail = (params = {}) => {
  return defHttp.get({ url: Api.GetDefaultRedPacketStrategyDetail, params })
}

// 创建红包策略
export const createRedPacketStrategy = (params = {}) => {
  return defHttp.post({ url: Api.CreateRedPacketStrategy, params })
}

// 更新红包策略
export const updateRedPacketStrategy = (params = {}) => {
  return defHttp.post({ url: Api.UpdateRedPacketStrategy, params })
}

// 回显红包策略配置
export const getRedPacketStrategyDetail = (params = {}) => {
  return defHttp.get({ url: Api.GetRedPacketStrategyDetail, params })
}

// 回显红包策略配置
export const getRedPacketGrantRecordsByStrategy = (params = {}) => {
  return defHttp.post({ url: Api.GetRedPacketGrantRecordsByStrategy, params })
}

// 上线红包策略
export const releaseRedPacketStrategy = (params = {}) => {
  return defHttp.post({ url: Api.ReleaseRedPacketStrategy, params })
}

// 下线红包策略
export const downRedPacketStrategy = (params = {}) => {
  return defHttp.post({ url: Api.DownRedPacketStrategy, params })
}

// 下线红包策略
export const getRedPacketReceiveRecordsByStrategy = (params = {}) => {
  return defHttp.post({ url: Api.GetRedPacketReceiveRecordsByStrategy, params })
}
