export enum ActivityType {
  // 分别为权益发放、抽奖、裂变
  Rights = 101,
  Lottery = 102,
  Fission = 103,
}

export const transDetail = (res) => {
  if (
    res.basicInfo.activityType === ActivityType.Rights ||
    res.basicInfo.activityType === ActivityType.Lottery
  ) {
    //多层结构空值转换
    if (res.limitConditions) {
      !res.limitConditions.registerTime &&
        (res.limitConditions.registerTime = {
          operator: '',
          value: '',
        })
      !res.limitConditions.lotteryCount &&
        (res.limitConditions.lotteryCount = {
          operator: '',
          value: undefined,
        })
    }
    //中奖概率转换
    if (res.actions?.lottery?.length) {
      res.actions.awardPoolConfigInfo.lottery = res.actions.awardPoolConfigInfo.lottery.map(
        (item) => ({
          ...item,
          probability: item.probability * 100,
        }),
      )
    }
  }

  if (res.basicInfo.activityType === ActivityType.Fission) {
    // 裂变类型
    if (res.invitationAwardInfo) {
      // 是否主动领取
      if (res.invitationAwardInfo.inviterReceiveStatus === 'ACTIVE_RECEIVE') {
        res.invitationAwardInfo.inviterReceiveStatus = true
      } else {
        res.invitationAwardInfo.inviterReceiveStatus = false
      }
    }

    // 邀请用户转化
    if (res.limitConditions) {
      if (res.limitConditions?.inviterLimitInfo?.inviterUserStatus === 'USER_WHITE_LIST') {
        res.limitConditions.inviterLimitInfo.inviterUserIds =
          res.limitConditions.inviterLimitInfo.inviterUserIds.join(',')
      }
      if (res.limitConditions?.inviteeLimitInfo?.inviteeUserStatus === 'USER_WHITE_LIST') {
        res.limitConditions.inviteeLimitInfo.inviteeUserIds =
          res.limitConditions.inviteeLimitInfo.inviteeUserIds.join(',')
      }

      !res.limitConditions.inviterLimitInfo &&
        (res.limitConditions.inviterLimitInfo = {
          inviterUserStatus: '',
          inviterUserIds: [],
        })
      !res.limitConditions.inviteeLimitInfo &&
        (res.limitConditions.inviteeLimitInfo = {
          inviterUserStatus: '',
          inviterUserIds: [],
        })
    }
  }
  return res
}

export const transSave = (params) => {
  if (
    params.basicInfo.activityType === ActivityType.Rights ||
    params.basicInfo.activityType === ActivityType.Lottery
  ) {
    //多层结构空值转换
    if (params.limitConditions) {
      !params.limitConditions.selectedConditions.includes('registerTime') &&
        (params.limitConditions.registerTime = null)
      !params.limitConditions.selectedConditions.includes('lotteryCount') &&
        (params.limitConditions.lotteryCount = null)
    }
    if (params.actions) {
      !params.actions.selectedConditions.includes('grantEquity') &&
        (params.actions.grantEquity = null)
    }
    //中奖概率转换
    if (params.actions?.lottery?.length) {
      params.actions.awardPoolConfigInfo.lottery = params.actions.awardPoolConfigInfo.lottery.map(
        (item) => ({
          ...item,
          probability: item.probability / 100,
        }),
      )
    }
    // 一期写死combine
    params.triggerConditions.combine = [params.triggerConditions.selectedConditions]
    params.limitConditions.combine = [params.limitConditions.selectedConditions]
    params.actions.combine = [params.actions.selectedConditions]
  }

  if (params.basicInfo.activityType === ActivityType.Fission) {
    // 裂变类型
    if (params.invitationAwardInfo) {
      // 是否主动领取
      if (params.invitationAwardInfo.inviterReceiveStatus) {
        params.invitationAwardInfo.inviterReceiveStatus = 'ACTIVE_RECEIVE'
      } else {
        params.invitationAwardInfo.inviterReceiveStatus = 'NONE_ACTIVE_RECEIVE'
      }
    }
    // 邀请用户转化
    if (params.limitConditions) {
      // 邀请人
      if (params.limitConditions?.inviterLimitInfo?.inviterUserStatus === 'ALL') {
        params.limitConditions.inviterLimitInfo.inviterUserIds = []
      }
      if (params.limitConditions?.inviterLimitInfo?.inviterUserStatus === 'USER_WHITE_LIST') {
        if (params.limitConditions.inviterLimitInfo.inviterUserIds &&
            typeof params.limitConditions.inviterLimitInfo.inviterUserIds === 'string') {
          params.limitConditions.inviterLimitInfo.inviterUserIds =
            params.limitConditions.inviterLimitInfo.inviterUserIds.split(',')
        } else {
          params.limitConditions.inviterLimitInfo.inviterUserIds = []
        }
      }

      // 受邀人
      if (
        params.limitConditions?.inviteeLimitInfo?.inviteeUserStatus === 'ALL' ||
        params.limitConditions?.inviteeLimitInfo?.inviteeUserStatus === 'USER_FIRST_RESERVE'
      ) {
        params.limitConditions.inviteeLimitInfo.inviteeUserIds = []
      }
      if (params.limitConditions?.inviteeLimitInfo?.inviteeUserStatus === 'USER_WHITE_LIST') {
        if (params.limitConditions.inviteeLimitInfo.inviteeUserIds) {
          params.limitConditions.inviteeLimitInfo.inviteeUserIds =
            params.limitConditions.inviteeLimitInfo.inviteeUserIds.split(',')
        } else {
          params.limitConditions.inviteeLimitInfo.inviteeUserIds = []
        }
      }

      !params.limitConditions.selectedConditions.includes('INVITER_OBJECT') &&
        delete params.limitConditions.inviterLimitInfo
      !params.limitConditions.selectedConditions.includes('INVITEE_OBJECT') &&
        delete params.limitConditions.inviteeLimitInfo
    }
  }

  return params
}
