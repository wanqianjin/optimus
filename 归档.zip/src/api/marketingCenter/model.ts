export interface ILottery {
  awardType: number
  // 权益ID
  awardReallyId: string
  // 数量
  totalNum: number
  // 中奖概率 大于0小于等于1
  probability: number
  // 是否兜底
  defaultAward: number
  // 奖品单人获得数量上限
  singlePersonLimit: number
  // 奖品名称
  awardName: string
}

export interface IBsicInfo {
  activityTitle: string
  activityDesc: string
  activityType: number
  activityTypeDesc: string
  activityStatus: number
  startTime: string
  endTime: string
  city: string[][]
  isEnd: boolean
}

interface IStrategyConditionEnum {
  value: string
  label: string
}

export interface IStrategyConditionEnums {
  actions: IStrategyConditionEnum[]
  triggerConditions: IStrategyConditionEnum[]
  limitConditions: IStrategyConditionEnum[]
  inviterAwards: IStrategyConditionEnum[]
  inviteeAwards: IStrategyConditionEnum[]
}

export interface QueryDetail {
  basicInfo: IBsicInfo
  activityUsersType: number
  activityUsers: string[]
  triggerConditions: {
    selectedConditions: string[]
  }
  limitConditions: {
    selectedConditions: string[]
    combine: string[][]
    registerTime?: {
      operator: string
      value: string[] | string
    }
    channel?: string[][]
    lotteryCount?: {
      operator: string
      value: string[] | string
    }
    inviteeLimitInfo?: {
      inviteeUserStatus: 'ALL' | 'USER_WHITE_LIST'
      inviteeUserIds: string[]
    }
  }
  actions?: {
    selectedConditions: string[]
    combine: string[][]
    grantEquity: {
      // 权益发放
      equityType: number
      equityId: string
    }
    lottery: ILottery[]
    awardPoolConfigInfo: {
      lottery: ILottery[]
      initialLotteryCount: number
    }
  }
  invitationAwardInfo?: {
    inviterAwardType: string
    inviterUserNum: number
    inviterAwardId: string
    inviterReceiveStatus: string
    inviteeAwardType: string
    inviteeAwardId: string
  }
}

export type ActivityUpdate = QueryDetail
