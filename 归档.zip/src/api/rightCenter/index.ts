import { defHttp } from '/@/utils/http/axios'
import { ContentTypeEnum } from '/@/enums/httpEnum'
import { OperationMode } from '/@/enums/rightCenterEnum'

type OptionsItem = { label: string; value: string; disabled?: boolean }

enum Api {
  // -----原子权益-----
  QueryAtomicEquityTypeApi = '/user-ares-backend/ares/backend/atomicEquity/type/getExcludeCoupon',
  QueryAllRightsTypeApi = '/user-ares-backend/ares/backend/atomicEquity/type/get',
  CreateAtomicEquity = '/user-ares-backend/ares/backend/atomicEquity/create',
  UpdateAtomicEquityApi = '/user-ares-backend/ares/backend/atomicEquity/update',
  QueryAtomicEquityListApi = '/user-ares-backend/ares/backend/atomicEquity/list',
  QueryAtomicEquityDetailApi = '/user-ares-backend/ares/backend/atomicEquity/detail',
  DeleteAtomicEquityApi = '/user-ares-backend/ares/backend/atomicEquity/delete',
  UpAtomicEquityApi = '/user-ares-backend/ares/backend/atomicEquity/up',
  DownAtomicEquityApi = '/user-ares-backend/ares/backend/atomicEquity/down',
  GetAtomicEquityParamApi = '/user-ares-backend/ares/backend/atomicEquity/attribute/get',

  // -----权益包-----
  QueryEquityPackageListApi = '/user-ares-backend/ares/backend/equityPackage/list',
  CreatEquityPackageApi = '/user-ares-backend/ares/backend/equityPackage/create',
  QueryEquityPackageDetailApi = '/user-ares-backend/ares/backend/equityPackage/detail',
  UpdateEquityPackageApi = '/user-ares-backend/ares/backend/equityPackage/update',
  normalReceiptStatistics = '/user-ares-backend/ares/backend/equityPackage/receiptStatistics/list',
  equityPackageLabelSign = '/user-ares-backend/ares/backend/equityPackage/label/sign',

  // -----发放记录-----
  GrantAtomicEquityApi = '/user-ares-backend/ares/backend/atomicEquity/grant/list',
  ConfirmGrantVirtualAwardApi = '/user-ares-backend/ares/backend/atomicEquity/virtualAward/grant/confirm',
  ConfirmGrantOfflineAwardApi = '/user-ares-backend/ares/backend/atomicEquity/offlineAward/grant/confirm',
  QueryGrantAtomicEquityApi = '/user-ares-backend/ares/backend/atomicEquity/grant/detail',
  ReverseEquityApi = '/user-ares-backend/ares/backend/atomicEquity/cancel',
  receiptConsumeApi = '/user-ares-backend/ares/backend/atomicEquity/receipt/consume',
  ReverseEquityPackageApi = '/user-ares-backend/ares/backend/equityPackage/cancel',
  GrantEquityPackageApi = '/user-ares-backend/ares/backend/user/equityPackage/detail/list',
  QueryReceiptStatusApi = '/user-ares-backend/ares/backend/receiptStatus/list/get',
  GteEquityPackageGrantProgress = '/user-ares-backend/ares/backend/user/equityPackage/progress/detail',
  QueryEquityPackageGrantDetail = '/user-ares-backend/ares/backend/user/equityPackage/retryGrant',

  // -----三方券码-----
  QueryCouponListApi = '/user-ares-backend/coupon/backend/codePool/list',
  CreateCouponApi = '/user-ares-backend/coupon/backend/codePool/create',
  UpdateCouponApi = '/user-ares-backend/coupon/backend/codePool/update',
  QueryCouponDetailApi = '/user-ares-backend/coupon/backend/codePool/detail',
  QueryPublisherListApi = '/user-ares-backend/coupon/backend/getPublisherList',
  ExportCouponCodeApi = '/user-ares-backend/coupon/backend/exportCouponCode',
  ExportCouponTemplateApi = '/user-ares-backend/coupon/backend/exportCouponTemplate',
  ImportCouponListApi = '/user-ares-backend/coupon/backend/importCouponCodeList',
  WriteCouponStatusApi = '/user-ares-backend/coupon/backend/couponCodeWriteStatus/get',
  QueryDepartmentApi = '/user-ares-backend/coupon/backend/getDepartment',

  // -----权益中心V1.1.0-券模板（优惠券能力建设）-----
  CreateVoucherApi = '/user-ares-backend/ares/backend/atomicEquity/createCoupon',
  UpdateVoucherApi = '/user-ares-backend/ares/backend/atomicEquity/updateCoupon',
  QueryVoucherListApi = '/user-ares-backend/ares/backend/atomicEquity/couponList',
  QueryVoucherDetailApi = '/user-ares-backend/ares/backend/atomicEquity/couponDetail',
  QueryCouponMallTypeApi = '/user-ares-backend/ares/backend/atomicEquity/couponMallTypeList',
  QueryReleaseListApi = '/user-ares-backend/ares/backend/stockPool/list',
  AddStockPoolApi = '/user-ares-backend/ares/backend/stockPool/addTotal',
  QueryFlowListApi = '/user-ares-backend/ares/backend/atomicEquity/couponEventList',
  QueryVoucherTypeApi = '/user-ares-backend/ares/backend/atomicEquity/type/get',
  QueryClientTypeApi = '/user-ares-backend/ares/backend/atomicEquity/availableClientType/get',

  //--------商城接入券-----------
  QueryCouponSubjectTypeApi = '/user-ares-backend/ares/backend/atomicEquity/couponSubjectType/get',

  //------权益中心V1.2-----------
  QueryDepartmentTreeApi = '/user-ares-backend/ares/backend/stockPool/getDepartmentTree',
  QueryCouponCommodityApi = '/user-ares-backend/ares/backend/atomicEquity/couponCommodityTree',
  QueryAddReleaseListApi = '/user-ares-backend/ares/backend/stockPool/addLog/list',

  //------不记名兑换码-----------
  QueryRedeemCodeBatchApi = '/user-ares-backend/ares/backend/redeemCode/batch/list',
  CreateRedeemCodeBatchApi = '/user-ares-backend/ares/backend/redeemCode/batch/create',
  QueryRedeemCodeDetailApi = '/user-ares-backend/ares/backend/redeemCode/batch/detail',
  QueryUseDetailApi = '/user-ares-backend/ares/backend/redeemCode/useDetail/list',
  ExportUseDetailApi = '/user-ares-backend/ares/backend/redeemCode/useDetail/export',
  DeleteRedeemCodeBatchApi = '/user-ares-backend/ares/backend/redeemCode/batch/delete',

  //------权益中心V1.3-----------
  UpdateStockPooApi = '/user-ares-backend/ares/backend/stockPool/update',

  //--------碎片-------------
  QueryAtomicEquityAndCouponApi = '/user-ares-backend/ares/backend/atomicEquity/list/v2',

  //--------车主权益-------------
  QueryDistributeInfoApi = '/user-ares-backend/ares/backend/equityPackage/option/list',

  //--------库存池---------------
  CreateStockPoolsApi = '/user-ares-backend/ares/backend/stockPool/create',
  DeductStockApi = '/user-ares-backend/ares/backend/stockPool/stock/deduct',
  stockPoolLabelSign = '/user-ares-backend/ares/backend/stockPool/label/sign',

  //--------线下提货码信息---------------
  QueryStoreOrgListApi = '/user-ares-backend/ares/backend/atomicEquity/storeOrgList',

  //--------可用业务-------------
  QueryEquityRelateSceneApi = '/user-ares-backend/ares/backend/relateScene/list/get',
  QueryEquityPkgRelateSceneApi = '/user-ares-backend/ares/backend/equityPackage/relateScene/list/get',
  QuerySceneAuthEnableApi = '/user-ares-backend/ares/backend/query/vehicleReceipt/authEnable',

  //--------单人限制枚举值------------
  QueryUserLimitOptionApi = '/user-ares-backend/ares/backend/atomicEquity/userLimitOption',
  // -------个人库存限制枚举-----------
  QueryPersonalLimitSelectList = '/user-ares-backend/ares/backend/limit/list',

  //--------投放管理-------------
  CreatEquityPlaceApi = '/user-ares-backend/ares/backend/equityPlace/create',
  UpdateEquityPlaceApi = '/user-ares-backend/ares/backend/equityPlace/update',
  QueryEquityPlaceDetailApi = '/user-ares-backend/ares/backend/equityPlace/detail',
  QueryEquityPlaceListApi = '/user-ares-backend/ares/backend/equityPlace/list',
  QueryLaunchLocationApi = '/user-ares-backend/ares/backend/placePoint/list',
  UpEquityPlaceApi = '/user-ares-backend/ares/backend/equityPlace/up',
  DownEquityPlaceApi = '/user-ares-backend/ares/backend/equityPlace/down',

  //--------人钱场效-权益侧相关接口--------
  QueryProjectListApi = '/user-ares-backend/ares/backend/project/list',
  QueryCouponCostPriceApi = '/user-ares-backend/ares/backend/coupon/external/query',
  QueryBatchListApi = '/user-ares-backend/ares/backend/credits/batch/list',

  //--------预警邮箱--------------
  QueryIamEmailApi = '/user-ares-backend/ares/backend/staffEmail/get',

  //--------人钱场效-券申请单相关接口--------
  QueryVoucherBudgetListApi = '/user-ares-backend/ares/backend/budget/main/record/list',
  QueryProjectDetailApi = '/user-ares-backend/ares/backend/budget/project/detail/query',
  QueryExternalOptionsApi = '/user-ares-backend/ares/backend/budgetInfo/fill/get',
  QueryGroupCodesApi = '/user-ares-backend/ares/backend/act/v3/group/getByGroupCodes',
  CreateVoucherBudgetListApi = '/user-ares-backend/ares/backend/budget/record/create',
  UpdateVoucherBudgetListApi = '/user-ares-backend/ares/backend/budget/record/update',
  ReCreateVoucherBudgetListApi = '/user-ares-backend/ares/backend/budget/record/recreate',
  QueryVoucherBudgetDetailApi = '/user-ares-backend/ares/backend/budget/main/record/detail',
  QueryVoucherBudgetSingleDetailApi = '/user-ares-backend/ares/backend/budget/single/record/detail',

  // ------获取车型版本参数----------
  QueryVehicleVersion = '/user-ares-backend/ares/backend/vehicleModelEdition/tree',
  // -------- 换绑车 --------
  QuerycarInfoApi = '/user-ares-backend/ares/backend/user/carInfo/query',
  QueryequityPackageApi = '/user-ares-backend/ares/backend/se/equityPackage/query',
  carRebindApi = '/user-ares-backend/ares/backend/se/car/rebind',
}

/**
 * @description: 获取原子权益类型信息
 */
export const queryAtomicEquityTypeApi = () => {
  return defHttp.get({ url: Api.QueryAtomicEquityTypeApi })
}

/**
 * @description: 创建原子权益
 */
export const createAtomicEquityApi = (params) => {
  return defHttp.post({ url: Api.CreateAtomicEquity, params }, { isTransformResponse: false })
}

/**
 * @description: 更新原子权益
 */
export const updateAtomicEquityApi = (params) => {
  return defHttp.post({ url: Api.UpdateAtomicEquityApi, params }, { isTransformResponse: false })
}

/**
 * @description: 获取原子权益列表
 */
export const queryAtomicEquityListApi = (params) => {
  return defHttp.post({ url: Api.QueryAtomicEquityListApi, params })
}

/**
 * @description: 获取原子权益详情
 */
export const queryAtomicEquityDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryAtomicEquityDetailApi, params })
}

/**
 * @description: 删除原子权益
 */
export const deleteAtomicEquityApi = (params) => {
  return defHttp.post({ url: Api.DeleteAtomicEquityApi, params }, { isTransformResponse: false })
}

/**
 * @description: 原子权益上下架
 */
export const atomicEquityStatusTransformApi = (params, status) => {
  if (status === '新建' || status === '下架') {
    return defHttp.post({ url: Api.UpAtomicEquityApi, params }, { isTransformResponse: false })
  } else {
    return defHttp.post({ url: Api.DownAtomicEquityApi, params }, { isTransformResponse: false })
  }
}

/**
 * @description: 获取原子权益专属参数
 */
export const getAtomicEquityParamApi = (params) => {
  return defHttp.get({ url: Api.GetAtomicEquityParamApi, params })
}

/**
 * @description: 获取权益包列表
 */
export const queryEquityPackageListApi = (params) => {
  return defHttp.post({ url: Api.QueryEquityPackageListApi, params })
}

/**
 * @description: 创建权益包
 */
export const createEquityPackageApi = (params) => {
  return defHttp.post({ url: Api.CreatEquityPackageApi, params }, { isTransformResponse: false })
}

/**
 * @description: 查询权益包详情
 */
export const queryEquityPackageDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryEquityPackageDetailApi, params })
}

/**
 * @description: 更新权益包
 */
export const updateEquityPackageApi = (params) => {
  return defHttp.post({ url: Api.UpdateEquityPackageApi, params }, { isTransformResponse: false })
}

/**
 * @description: 权益包权益统计 https://jmock.jiduauto.com/project/607/interface/api/131583
 */
export const normalReceiptStatisticsApi = (params) => {
  return defHttp.get({ url: Api.normalReceiptStatistics, params })
}
/**
 * @description: 权益包打标 https://jmock.jiduauto.com/project/607/interface/api/131583
 */
export const equityPackageLabelSignApi = (params) => {
  return defHttp.post({ url: Api.equityPackageLabelSign, params })
}

/**
 * @description: 获取原子权益发放记录
 */
export const grantAtomicEquityApi = (params) => {
  return defHttp.post({ url: Api.GrantAtomicEquityApi, params })
}

/**
 * @description: 获取权益包发放记录
 */
export const grantEquityPackageApi = (params) => {
  return defHttp.post({ url: Api.GrantEquityPackageApi, params })
}

/**
 * @description: 获取权益凭证状态
 */
export const queryReceiptStatusApi = () => {
  return defHttp.get({ url: Api.QueryReceiptStatusApi })
}
/**
 * @description: 权益包发放详情进度
 */
export const GteEquityPackageGrantProgressApi = (params) => {
  return defHttp.get({ url: Api.GteEquityPackageGrantProgress, params })
}
/**
 * @description: 权益包凭证重新发放子权益
 */
export const QueryEquityPackageGrantDetailApi = (params) => {
  return defHttp.post({ url: Api.QueryEquityPackageGrantDetail, params })
}

/**
 * @description: 确认虚拟兑换奖品发放
 */
export const confirmGrantVirtualAwardApi = (params) => {
  return defHttp.post(
    { url: Api.ConfirmGrantVirtualAwardApi, params },
    { isTransformResponse: false },
  )
}

/**
 * @description: 确认线下实物奖品发放
 */
export const confirmGrantOfflineAwardApi = (params) => {
  return defHttp.post(
    { url: Api.ConfirmGrantOfflineAwardApi, params },
    { isTransformResponse: false },
  )
}

/**
 * @description: 查询原子权益发放详情
 */
export const queryGrantAtomicEquityApi = (params) => {
  return defHttp.get({ url: Api.QueryGrantAtomicEquityApi, params })
}

/**
 * @description: 原子权益凭证逆向（回收）
 */
export const reverseEquityApi = (params) => {
  return defHttp.post({ url: Api.ReverseEquityApi, params }, { isTransformResponse: false })
}
/**
 * @description: 原子权益凭证核销重试（核销重试）
 */
export const receiptConsumeApi = (params) => {
  return defHttp.post({ url: Api.receiptConsumeApi, params }, { isTransformResponse: false })
}

/**
 * @description: 权益包凭证逆向（回收）
 */
export const reverseEquityPackageApi = (params) => {
  return defHttp.post({ url: Api.ReverseEquityPackageApi, params }, { isTransformResponse: false })
}

/**
 * @description: 查询券码列表
 */
export const queryCouponListApi = (params) => {
  return defHttp.post({ url: Api.QueryCouponListApi, params })
}

/**
 * @description: 创建券码池
 */
export const createCouponApi = (params) => {
  return defHttp.post({ url: Api.CreateCouponApi, params })
}

/**
 * @description: 修改券码池
 */
export const updateCouponApi = (params) => {
  return defHttp.post({ url: Api.UpdateCouponApi, params })
}

/**
 * @description: 查询券码池详情
 */
export const queryCouponDetailApi = (params) => {
  return defHttp.post({ url: Api.QueryCouponDetailApi, params })
}

/**
 * @description: 获取发布者数据
 */
export const queryPublisherListApi = () => {
  return defHttp.get({ url: Api.QueryPublisherListApi })
}

/**
 * @description: 导出券码数据
 */
export const exportCouponCodeApi = () => {
  return `/api${Api.ExportCouponCodeApi}`
}

/**
 * @description: 导出券码模板
 */
export const exportCouponTemplateApi = () => {
  return `/api${Api.ExportCouponTemplateApi}`
}

/**
 * @description: 上传券码文件
 */
export const importCouponListApi = (params) => {
  return defHttp.post(
    {
      url: Api.ImportCouponListApi,
      params,
      headers: { 'Content-Type': ContentTypeEnum.FORM_DATA },
    },
    { isTransformResponse: false },
  )
}

/**
 * @description: 写入券码数据
 */
export const writeCouponStatusApi = (params) => {
  return defHttp.post({ url: Api.WriteCouponStatusApi, params })
}

/**
 * @description: 查询归属部门
 */
export const queryDepartmentApi = () => {
  return defHttp.post({ url: Api.QueryDepartmentApi })
}

//权益中心迭代V1.1.0---券模板
/**
 * @description: 查询券模板列表信息
 */
export const queryVoucherListApi = (params) => {
  return defHttp.post({ url: Api.QueryVoucherListApi, params })
}

/**
 * @description: 查询核销标的对应的商铺名称，注：权益1.2版本未使用，后期根据产品需求再调用接口
 */
export const queryStoreNameListApi = (params): Promise<OptionsItem[]> => {
  const data: OptionsItem[] = []
  let searchData: OptionsItem[] = []
  for (let i = 0; i < 55; i++) {
    data.push({
      label: `店铺${i + 1}`,
      value: String(i + 1),
    })
  }
  if (params.keyword === '') {
    searchData = data
  } else {
    searchData = data.filter((item) => item.value === params.keyword)
  }
  return Promise.resolve(searchData)
}

/**
 * @description: 查询店铺对应的商品类目信息，注：权益1.2版本未使用，后期根据产品需求采用
 */
export const queryCategoryTreeApi = () => {
  return `/api${Api.QueryCouponCommodityApi}`
}

/**
 * @description: 创建券模板
 */
export const createVoucherApi = (params) => {
  return defHttp.post({ url: Api.CreateVoucherApi, params })
}

export const updateVoucherApi = (params) => {
  return defHttp.post({ url: Api.UpdateVoucherApi, params })
}

/**
 * @description: 查询券模板信息
 */
export const queryVoucherApi = (params) => {
  return defHttp.get({ url: Api.QueryVoucherDetailApi, params })
}

/**
 * @description: 查询某个券模板发行信息列表信息
 */
export const queryReleaseListApi = (params) => {
  return defHttp.post({ url: Api.QueryReleaseListApi, params })
}

/**
 * @description: 查询累计发行记录
 */
export const queryAddReleaseListApi = (params) => {
  return defHttp.post({ url: Api.QueryAddReleaseListApi, params })
}

/**
 * @description: 查询券流水记录
 */
export const queryFlowListApi = (params) => {
  return defHttp.get({ url: Api.QueryFlowListApi, params })
}

/**
 * @description: 查询商城数据，注：后续产品需求添加了商城信息再调用接口，当前直接写明数据
 */
export const queryCouponMallTypeApi = () => {
  return defHttp.get({ url: Api.QueryCouponSubjectTypeApi })
}

/**
 * @description: 库存池增发
 */
export const addStockPoolApi = (params) => {
  return defHttp.post({ url: Api.AddStockPoolApi, params }, { isTransformResponse: false })
}

/**
 * @description: 获取优惠券类型
 */
export const queryVoucherTypeApi = () => {
  return defHttp.get({ url: Api.QueryVoucherTypeApi })
}

/**
 * @description: 获取所有权益类型
 */
export const queryAllRightsTypeApi = () => {
  return defHttp.get({ url: Api.QueryAllRightsTypeApi })
}

/**
 *
 * @description: 获取所有端类型
 */
export const queryAllAvailableTerminalApi = () => {
  return defHttp.get({ url: Api.QueryClientTypeApi })
}

/**
 * @description: 查询部门信息
 */
export const queryDepartmentTreeApi = (params) => {
  return defHttp.post({ url: Api.QueryDepartmentTreeApi, params })
}

/**
 * @description: 获取提货码网点信息
 */
export const queryStoreOrgListApi = () => {
  return defHttp.get({ url: Api.QueryStoreOrgListApi })
}

//------权益中心V1.4 不记名兑换码-----------

/**
 * @description: 查询兑换码列表信息: https://jmock.jiduauto.com/project/607/interface/api/67743
 */
export const queryRedemptionListApi = (params) => {
  return defHttp.post({ url: Api.QueryRedeemCodeBatchApi, params })
}

/**
 * @description: 查询兑换码详情: https://jmock.jiduauto.com/project/607/interface/api/67651
 */
export const queryRedemptionCodeDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryRedeemCodeDetailApi, params })
}

/**
 * @description: 创建兑换码: https://jmock.jiduauto.com/project/607/interface/api/67431
 */
export const createRedeemCodeBatchApi = (params) => {
  return defHttp.post({ url: Api.CreateRedeemCodeBatchApi, params })
}

/**
 * @description: 兑换码使用明细查询: https://jmock.jiduauto.com/project/607/interface/api/67715
 */
export const queryUseDetailApi = (params) => {
  return defHttp.post({ url: Api.QueryUseDetailApi, params })
}

/**
 * @description: 兑换码导出: https://jmock.jiduauto.com/project/607/interface/api/67719
 */
export const exportUseDetailApi = (params) => {
  return defHttp.post({ url: Api.ExportUseDetailApi, params })
}

/**
 * @description: 兑换码批次作废: https://jmock.jiduauto.com/project/607/interface/api/67747
 */
export const deleteRedeemCodeBatchApi = (params) => {
  return defHttp.post({ url: Api.DeleteRedeemCodeBatchApi, params })
}

//权益中心迭代V1.3.0
/**
 * @description: 编辑更新库存池信息
 */
export const updateStockPooApi = (params) => {
  return defHttp.post({ url: Api.UpdateStockPooApi, params })
}

/**
 * @description: 查询所有原子权益+券
 */
export const queryAtomicEquityAndCouponApi = (params) => {
  return defHttp.post({ url: Api.QueryAtomicEquityAndCouponApi, params })
}

/**
 * @description: 创建库存池
 */
export const createStockPoolsApi = (params) => {
  return defHttp.post({ url: Api.CreateStockPoolsApi, params }, { isTransformResponse: false })
}

/**
 * @description: 库存池扣减，即余额作废
 */
export const deductStockApiApi = (params) => {
  return defHttp.post({ url: Api.DeductStockApi, params })
}
/**
 * @description: 库存打标
 */
export const stockPoolLabelSignApi = (params) => {
  return defHttp.post({ url: Api.stockPoolLabelSign, params })
}

/**
 * @description: 权益包下拉元数据
 */
export const queryDistributeInfoApi = () => {
  return defHttp.get({ url: Api.QueryDistributeInfoApi })
}

/**
 * @description: 获取可用业务
 */
export const queryRelateSceneApi = (params) => {
  if (params === OperationMode.right || params === OperationMode.voucher) {
    return defHttp.get({ url: Api.QueryEquityRelateSceneApi })
  } else if (params === OperationMode.rightPkg) {
    return defHttp.get({ url: Api.QueryEquityPkgRelateSceneApi })
  }
}

/**
 * @description: 查询可用业务白名单
 */
export const querySceneAuthEnableApi = (params) => {
  return defHttp.post({ url: Api.QuerySceneAuthEnableApi, params })
}

/**
 * @description: 获取券单人领取限制枚举
 */
export const queryUserLimitOptionApi = () => {
  return defHttp.get({ url: Api.QueryUserLimitOptionApi })
}
/**
 * @description: 获取个人库存限制枚举
 */
export const queryPersonalLimitSelectListApi = () => {
  return defHttp.get({ url: Api.QueryPersonalLimitSelectList })
}

//------权益中心 投放管理-----------

/**
 * @description: 投放点位数据获取
 */
export const queryLaunchLocationApi = () => {
  return defHttp.get({ url: Api.QueryLaunchLocationApi })
}

/**
 * @description: 创建权益投放
 */
export const creatEquityPlaceApi = (params) => {
  return defHttp.post({ url: Api.CreatEquityPlaceApi, params }, { isTransformResponse: false })
}

/**
 * @description: 更新权益投放
 */
export const updateEquityPlaceApi = (params) => {
  return defHttp.post({ url: Api.UpdateEquityPlaceApi, params }, { isTransformResponse: false })
}

/**
 * @description: 查询权益投放详情
 */
export const queryEquityPlaceDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryEquityPlaceDetailApi, params })
}

/**
 * @description: 查询权益投放列表
 */
export const queryEquityPlaceListApi = (params) => {
  return defHttp.post({ url: Api.QueryEquityPlaceListApi, params })
}

/**
 * @description: 权益投放上下架
 */
export const equityPlaceStatusTransformApi = (params, status) => {
  if (status === '上架') {
    return defHttp.post({ url: Api.DownEquityPlaceApi, params }, { isTransformResponse: false })
  } else {
    return defHttp.post({ url: Api.UpEquityPlaceApi, params }, { isTransformResponse: false })
  }
}

/**
 * @description: 查询三级项目信息。若含有atomicEquityId参数，则查询积分批次对应的三级项目数据；否则查询的是所有的三级项目数据
 */
export const queryProjectListApi = (params) => {
  return defHttp.get({ url: Api.QueryProjectListApi, params }, { isTransformResponse: false })
}

/**
 * @description: 查询券成本信息
 */
export const queryCouponCostPriceApi = (params) => {
  return defHttp.post({ url: Api.QueryCouponCostPriceApi, params })
}

/**
 * @description: 查询积分批次列表
 */
export const queryBatchListApi = (params) => {
  return defHttp.post({ url: Api.QueryBatchListApi, params })
}

/**
 * @description: 库存-预警邮箱获取
 */
export const queryIamEmailApi = (params) => {
  return defHttp.get({ url: Api.QueryIamEmailApi, params })
}

/**
 * @description: 券预算列表查询
 */
export const queryVoucherBudgetManageListApi = (params) => {
  return defHttp.post({ url: Api.QueryVoucherBudgetListApi, params })
}

/**
 * @description: 券预算-根据三级项目id查询三级项目详情
 */
export const queryProjectDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryProjectDetailApi, params })
}

/**
 * @description: 券预算-相关选项options
 */
export const queryExternalOptionsApi = () => {
  return defHttp.get({ url: Api.QueryExternalOptionsApi })
}

/**
 * @description: 券预算-查询费用部门对应的成本中心数据
 */
export const queryGroupCodesApi = (params) => {
  return defHttp.post({ url: Api.QueryGroupCodesApi, params })
}

/**
 * @description: 创建券预算申请单
 */
export const createVoucherBudgetListApi = (params) => {
  return defHttp.post(
    { url: Api.CreateVoucherBudgetListApi, params },
    { isTransformResponse: false },
  )
}

/**
 * @description: 更新券预算申请单
 */
export const updateVoucherBudgetListApi = (params) => {
  return defHttp.post(
    { url: Api.UpdateVoucherBudgetListApi, params },
    { isTransformResponse: false },
  )
}

/**
 * @description: 审批驳回需重新提交券预算申请单
 */
export const reCreateVoucherBudgetListApi = (params) => {
  return defHttp.post(
    { url: Api.ReCreateVoucherBudgetListApi, params },
    { isTransformResponse: false },
  )
}

/**
 * @description: 券预算主单下聚合申请单详情查询
 */
export const queryVoucherBudgetDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryVoucherBudgetDetailApi, params })
}

/**
 * @description: 券预算单个申请单详情查询
 */
export const queryVoucherBudgetSingleDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryVoucherBudgetSingleDetailApi, params })
}
/**
 * @description: 获取车型版本参数
 */
export const queryVehicleVersionApi = (params) => {
  return defHttp.post({ url: Api.QueryVehicleVersion, params })
}
/**
 * @description: 查询用户名下车辆信息
 */
export const querycarInfoApi = (params) => {
  return defHttp.get({ url: Api.QuerycarInfoApi, params })
}

/**
 * @description: 查询SE权益包列表
 */
export const queryequityPackageApi = (params) => {
  return defHttp.get({ url: Api.QueryequityPackageApi, params })
}

/**
 * @description: SE权益包换绑车
 */
export const carRebindApi = (params) => {
  return defHttp.post({ url: Api.carRebindApi, params })
}
