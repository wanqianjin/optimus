import { defHttp } from '/@/utils/http/axios'
// import axios from 'axios'

enum Api {
  // 创建工单
  CreateTicket = '/b/content-backend/ticket/createTicket',
  // 工单详情
  TicketDetail = '/b/content-backend/ticket/v2/ticketDetail',
}

/**
 * @description: 创建工单
 */
export const CreateTicket = (params = {}) => {
  return defHttp.post({ url: Api.CreateTicket, params })
}

/**
 * @description: 工单详情
 */
export const TicketDetail = (params) => {
  return defHttp.get({ url: Api.TicketDetail, params })
}
