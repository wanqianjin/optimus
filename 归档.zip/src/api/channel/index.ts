import { defHttp } from '/@/utils/http/axios'
import { useGlobSetting } from '/@/hooks/setting'
import { ContentTypeEnum } from '/@/enums/httpEnum'

const globSetting = useGlobSetting() //获取全局变量
const VITE_GLOB_API_URL = import.meta.env.VITE_GLOB_API_URL

enum Api {
  QueryChannelList = '/channel/channel/queryChannelList',
  QueryCreateChannel = '/channel/channel/createChannel',
  QueryUpdateChannel = '/channel/channel/updateChannel',
  QueryChannelDetail = '/channel/channel/queryChannel',
  QueryChannelName = '/channel/channel/queryChannelName',
  QueryDownloadChannel = '/channel/channel/downloadChannel',
  QueryChannelEventList = '/channel/channel/queryChannelEventList',
  CreateChannelActivity = '/channel/channel/createChannelActivity',
  QueryChannelActivity = '/channel/channel/queryChannelActivity',
  CreateChannelEvent = '/channel/channel/createChannelEvent',
  UpdateChannelEvent = '/channel/channel/updateChannelEvent',
  QueryChannelEvent = '/channel/channel/queryChannelEvent',
  QueryRelation = '/channel/channel/queryRelation',

  GetDepartment = '/channel/channel/getDepartment',
  GetClient = '/channel/channel/getClient',
  UpdateEventKey = '/channel/channel/updateEventKey',
  DownloadTemplate = '/channel/channel/downloadTemplate',
  UploadFile = '/channel/channel/uploadFile',
  GetUploadResult = '/channel/channel/getUploadResult',
  QueryRelationByLevel = '/channel/channel/queryRelationByLevel',
  GetEventTypeList = '/channel/channel/getEventTypeList',
  /**
   * @description: 渠道管理1.2 项目活动管理
   */
  CreateProject = '/channel/channel/createProject',
  UpdateProject = '/channel/channel/updateProject',
  QueryProject = '/channel/channel/queryProject',
  QueryProjectList = '/channel/channel/queryProjectList',
  CreateActivity = '/channel/channel/createActivity',
  UpdateActivity = '/channel/channel/updateActivity',
  QueryActivity = '/channel/channel/queryActivity',
  QueryActivityList = '/channel/channel/queryActivityList',
  QueryProjectName = '/channel/channel/queryProjectName',
  QueryProjectActivity = '/channel/channel/queryProjectActivity',
  QueryOperateLog = '/b/content-backend/backend/queryOperateLog',
  QueryChannelAuth = '/channel/channel/queryChannelAuth',
  UpdateCostAmount = '/channel/channel/updateCostAmount',
  UpdateCreateUser = '/channel/channel/updateCreateUser',

  /**
   * @description: 渠道管理1.5
   */
  GetOperationManual = '/channel/channel/getOperationManual',
  GetAppDownloadLink = '/channel/channel/getAppDownloadLink',
  GetMarketingFlag = '/channel/channel/getMarketingFlag',
  /**
   * @description: 渠道管理1.6
   */
  GetProjectType = '/channel/channel/getProjectType',
  GetCostType = '/channel/channel/getCostType',
  GetCityShop = '/channel/channel/queryCityShop',
  GetProjectByWorkId = '/channel/channel/getProjectByWorkId',

  //获取所有Apollo配置  https://jmock.jiduauto.com/project/934/interface/api/74703
  GetApolloData = '/channel/channel/getApolloData',

  QueryGroupByUser = '/channel/channel/queryGroupByUser',
  QueryAllThirdProject = '/channel/channel/queryAllThirdProject',
  // esj远程搜索
  queryChannelESJList = '/channel/channel/queryChannelEventList/v2',
  // ------二维码生成器-----
  PreviewSingleQRCodeApi = '/user-backend/qrcode/previewSingleQRCode',
  CreateQRCodeInfoApi = '/user-backend/qrcode/createQRCodeInfo',
  GetTemplateApi = '/user-backend/qrcode/getTemplate',
  CreateExcelQRCodeTaskApi = '/user-backend/qrcode/createExcelQRCodeTask',
  QueryAllRelationApi = '/channel/channel/queryAllRelation', //https://jmock.jiduauto.com/project/934/interface/api/33243
  QueryQRCodeListApi = '/user-backend/qrcode/pageQRCodeByOperatorCode',
  UpdateQRCodeApi = '/user-backend/qrcode/updateQRCodeInfo', // 编辑小程序二维码回显
  UploadTemplateApi = '/user-backend/uploadFile',
  getPreviewToken = '/b/content-backend/user/backend/getPreviewToken',

  // ---------活码管理---------------
  GetbatchList = '/user-backend/dynamicQrCode/batchList', //分页条件查询活码批次列表
  DynamicQrCodeBatch = '/user-backend/dynamicQrCode/batch', //活码（增删改查）
  GetOnlineStatusEnum = '/user-backend/dynamicQrCode/batch/onlineStatusEnum', //活码获取上架状态选项
  GetApprovalStatusEnum = '/user-backend/dynamicQrCode/batch/approvalStatusEnum', //活码获取审核状态选项
  GetsceneList = '/user-backend/dynamicQrCode/sceneList', //活码业务场景列表查询
  SetSubmitApproval = '/user-backend/dynamicQrCode/batch/submitApproval', // 活码提交审核
  SetWithdrawApproval = '/user-backend/dynamicQrCode/batch/withdrawApproval', // 活码撤回审核
  RoundQrCodeStyle = '/user-backend/dynamicQrCode/roundQrCodeStyle', //查询圆形二维码样式
  DownloadCsv = '/user-backend/dynamicQrCode/batch/download', //下载活码批次csv文件
  BatchRelease = '/user-backend/dynamicQrCode/batch/release', //活码批次上架
  GetuniqueIdList = '/user-backend/dynamicQrCode/batch/qrCodeList', //根据唯一id查询单个二维码详情
}

/**
 * @description: 条件查询渠道列表
 */
export const queryChannelListApi = (params) => {
  return defHttp.post({ url: Api.QueryChannelList, params })
}

/**
 * @description: 新增渠道层级
 */
export const queryCreateChannelApi = (params) => {
  return defHttp.post({ url: Api.QueryCreateChannel, params })
}
/**
 * @description: 修改渠道层级内容
 */
export const queryUpdateChannelApi = (params) => {
  return defHttp.post({ url: Api.QueryUpdateChannel, params })
}
/**
 * @description: 查询渠道详情
 */
export const queryChannelDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryChannelDetail, params })
}

/**
 * @description: 查询渠道名称（一级、二级、渠道资源位
 */
export const queryChannelNameApi = (params) => {
  return defHttp.get({ url: Api.QueryChannelName, params })
}

/**
 * @description: 渠道层级关系下载
 */
export const queryDownloadChannelApi = (params) => {
  return `${globSetting.apiUrl}${Api.QueryDownloadChannel}?downloadType=${params.downloadType}&fileName=${params.fileName}` //globSetting.apiUrl  获取全局域名
}

/**
 * @description: 渠道事件管理列表: https://jmock.jiduauto.com/project/934/interface/api/22739
 */
export const queryChannelEventListApi = (params) => {
  return defHttp.post({ url: Api.QueryChannelEventList, params })
}
/**
 * @description: 创建事件所属活动: https://jmock.jiduauto.com/project/934/interface/api/22819
 */
export const createChannelActivityApi = (params) => {
  return defHttp.post({ url: Api.CreateChannelActivity, params })
}
/**
 * @description: 查询事件所属活动名称（下拉列表）: https://jmock.jiduauto.com/project/934/interface/api/22751
 */
export const queryChannelActivityApi = (params) => {
  return defHttp.get({ url: Api.QueryChannelActivity, params })
}

/**
 * @description: 创建渠道事件: https://jmock.jiduauto.com/project/934/interface/api/22731
 */
export const createChannelEventApi = (params) => {
  return defHttp.post({ url: Api.CreateChannelEvent, params })
}

/**
 * @description: 编辑渠道事件: https://jmock.jiduauto.com/project/934/interface/api/22735
 */
export const updateChannelEventApi = (params) => {
  return defHttp.post({ url: Api.UpdateChannelEvent, params })
}
/**
 * @description: 查询渠道事件详情: https://jmock.jiduauto.com/project/934/interface/api/22743
 */
export const queryChannelEventDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryChannelEvent, params })
}

/**
 * @description: 查询渠道事件详情: https://jmock.jiduauto.com/project/934/interface/api/22743
 */
export const queryRelationApi = (params) => {
  return defHttp.get({ url: Api.QueryRelation, params })
}

/**
 * @description:【渠道事件管理】-5.获取渠道事件“所属部门”: https://jmock.jiduauto.com/project/934/interface/api/37243
 */
export const getDepartmentApi = (params) => {
  return defHttp.get({ url: Api.GetDepartment, params })
}
/**
 * @description:【渠道事件管理】-5.获取渠道事件“所属端”: https://jmock.jiduauto.com/project/934/interface/api/37243
 */
export const getClientApi = (params) => {
  return defHttp.get({ url: Api.GetClient, params })
}
/**
 * @description:【渠道层级管理】-2.下载模板（批量新增使用）: https://jmock.jiduauto.com/project/934/interface/api/37207
 */
export const downloadTemplatelApi = (channelLevel) => {
  return `${globSetting.apiUrl}${Api.DownloadTemplate}?channelLevel=${channelLevel}` //globSetting.apiUrl  获取全局域名
}
/**
 * @description:【渠道层级管理】-2.下载模板（批量新增使用）: https://jmock.jiduauto.com/project/934/interface/api/37207
 */
export const UploadFilelApi = () => {
  return `${globSetting.apiUrl}${Api.UploadFile}` //globSetting.apiUrl  获取全局域名
}
/**
 * @description:【渠道事件管理】-1.渠道密钥（event_source_jidu）修改: https://jmock.jiduauto.com/project/934/interface/api/37167
 */
export const updateEventKeyApi = (params) => {
  return defHttp.post({ url: Api.UpdateEventKey, params })
}
/**
 * @description:【渠道层级管理】-6.获取上传文件处理结果 https://jmock.jiduauto.com/project/934/interface/api/37491
 */
export const getUploadResultApi = (params) => {
  return defHttp.get({ url: Api.GetUploadResult, params })
}
/**
 * @description:-7.级联查询渠道名称（根据层级查询） https://jmock.jiduauto.com/project/934/interface/api/39283
 */
export const queryRelationByLevelApi = (params) => {
  return defHttp.get({ url: Api.QueryRelationByLevel, params })
}
/**
 * @description:.获取渠道事件“所属业务类型”https://jmock.jiduauto.com/project/934/interface/api/43791
 */
export const getEventTypeListApi = (params) => {
  return defHttp.get({ url: Api.GetEventTypeList, params })
}

// 项目活动
/**
 * @description: 新建项目 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const createProjectApi = (params) => {
  return defHttp.post({ url: Api.CreateProject, params })
}
/**
 * @description: 修改项目 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const updateProjectApi = (params) => {
  return defHttp.post({ url: Api.UpdateProject, params })
}
/**
 * @description: 查看项目详情 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const queryProjectApi = (params) => {
  return defHttp.get({ url: Api.QueryProject, params })
}
/**
 * @description: 查询项目列表 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const queryProjectListApi = (params) => {
  return defHttp.post({ url: Api.QueryProjectList, params })
}
/**
 * @description: 新建活动 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const createActivityApi = (params) => {
  return defHttp.post({ url: Api.CreateActivity, params })
}
/**
 * @description: 修改活动 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const updateActivityApi = (params) => {
  return defHttp.post({ url: Api.UpdateActivity, params })
}
/**
 * @description: 修改活动预算 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const updateCostAmountApi = (params) => {
  return defHttp.post({ url: Api.UpdateCostAmount, params })
}
/**
 * @description: 修改项目创建人 https://jmock.jiduauto.com/project/934/interface/api/84947
 */
export const updateCreateUserApi = (params) => {
  return defHttp.post({ url: Api.UpdateCreateUser, params })
}
/**
 * @description: 查看活动详情 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const queryActivityApi = (params) => {
  return defHttp.get({ url: Api.QueryActivity, params })
}
/**
 * @description: 查询活动list ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const queryActivityListApi = (params) => {
  return defHttp.post({ url: Api.QueryActivityList, params })
}
/**
 * @description: 查询项目名称list ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const queryProjectNameApi = (params) => {
  return defHttp.get({ url: Api.QueryProjectName, params })
}
/**
 * @description: 级联查询「项目」-「活动」列表  渠道事件内使用 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const queryProjectActivityApi = (params) => {
  return defHttp.get({ url: Api.QueryProjectActivity, params })
}
/**
 * @description: 查询用户操作日志 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const queryOperateLogApi = (params) => {
  return defHttp.post({ url: Api.QueryOperateLog, params })
}
/**
 * @description: .查询用户权限接口 ”https://jmock.jiduauto.com/project/934/interface/api/48507
 */
export const queryChannelAuthApi = (params) => {
  return defHttp.get({ url: Api.QueryChannelAuth, params })
}
/**
 * @description: .获取操作手册 ”https://jmock.jiduauto.com/project/934/interface/api/69915
 */
export const getOperationManualApi = (params) => {
  return defHttp.get({ url: Api.GetOperationManual, params })
}

/**
 * @description: 2.获取APP下载中间页链接. ”https://jmock.jiduauto.com/project/934/interface/api/69963
 */
export const getAppDownloadLinkApi = (params) => {
  return defHttp.get({ url: Api.GetAppDownloadLink, params })
}
/**
 * @description: 2.获取营销类型. ”https://jmock.jiduauto.com/project/934/interface/api/69963
 */
export const getMarketingFlagApi = (params) => {
  return defHttp.get({ url: Api.GetMarketingFlag, params })
}
/**
 * @description: 2.获取项目类型. ”https://jmock.jiduauto.com/project/934/interface/api/69963
 */
export const getProjectTypeApi = (params) => {
  return defHttp.get({ url: Api.GetProjectType, params })
}
/**
 * @description: 3.获取费用类别. ”https://jmock.jiduauto.com/project/934/interface/api/69963
 */
export const getCostTypeApi = (params) => {
  return defHttp.get({ url: Api.GetCostType, params })
}
/**
 * @description: 3.获取费用类别. ”https://jmock.jiduauto.com/project/934/interface/api/69963
 */
export const getCityShopApi = (params) => {
  return defHttp.post({ url: Api.GetCityShop, params })
}
/**
 * @description: 3.根据OA编号获取关联项目. https://jmock.jiduauto.com/project/934/interface/api/75379
 */
export const getProjectByWorkIdApi = (params) => {
  return defHttp.get({ url: Api.GetProjectByWorkId, params })
}
/**
 * @description: 3..根据用户名查询所属部门. https://jmock.jiduauto.com/project/934/interface/api/83567
 */
export const queryGroupByUserApi = (params) => {
  return defHttp.post({ url: Api.QueryGroupByUser, params })
}
/**
 * @description: 2.获取apollo所有配置. ”https://jmock.jiduauto.com/project/934/interface/api/74703
 */
export const getApolloDataApi = (params) => {
  return defHttp.get({ url: Api.GetApolloData, params })
}
/**
 * @description: 2.查询三级项目级联（包含未审批的三级项目）. https://jmock.jiduauto.com/project/934/interface/api/115211
 */
export const queryAllThirdProjectApi = (params) => {
  return defHttp.get({ url: Api.QueryAllThirdProject, params })
}
/**
 * @description: 2.esj列表远程搜索.
 */
export const queryChannelESJListApi = (params) => {
  return defHttp.post({ url: Api.queryChannelESJList, params })
}

// ----二维码生成器---- https://jmock.jiduauto.com/project/1261/interface/api/cat_8457
/**
 * @description: 单码预览
 */
export const previewSingleQRCodeApi = (params) => {
  return defHttp.post({ url: Api.PreviewSingleQRCodeApi, params })
}

/**
 * @description: 获取文章预览token
 */
export const getPreviewToken = (params) => {
  return defHttp.get({ url: Api.getPreviewToken, params })
}

/**
 * @description: 分页条件查询活码批次列表
 */
export const getCodeBatchListApi = (params = {}) => {
  return defHttp.post({ url: Api.GetbatchList, params })
}

/**
 * @description: 新增活码批次
 */
export const createBatchApi = (params) => {
  return defHttp.put({ url: Api.DynamicQrCodeBatch, params })
}
/**
 * @description: 删除活码批次
 */
export const deleteBatchApi = (params) => {
  return defHttp.delete({ url: `${Api.DynamicQrCodeBatch}/${params}` })
}
/**
 * @description: 编辑查看活码详情
 */
export const updateQrcodeDetailApi = (params) => {
  return defHttp.post({ url: Api.DynamicQrCodeBatch, params })
}
/**
 * @description: 查看活码详情
 */
export const queryAutoQrcodeDetailApi = (params) => {
  return defHttp.get({ url: `${Api.DynamicQrCodeBatch}/${params}` })
}

/**
 * @description: 获取圆形二维码样式
 */
export const roundQrCodeStyleApi = (params = {}) => {
  return defHttp.get({ url: Api.RoundQrCodeStyle, params })
}

/**
 * @description: 获取上架状态选项
 */
export const getOnlineStatusEnumApi = (params = {}) => {
  return defHttp.get({ url: Api.GetOnlineStatusEnum, params })
}

/**
 * @description: 获取审核状态选项
 */
export const getApprovalStatusEnumApi = (params = {}) => {
  return defHttp.get({ url: Api.GetApprovalStatusEnum, params })
}

/**
 * @description: 下载活码批次csv文件
 */
export const downloadCsvApi = (params = {}) => {
  return defHttp.get({ url: `${Api.DownloadCsv}/${params}` })
}

/**
 * @description: 活动批次上架
 */
export const batchReleaseApi = (params = {}) => {
  return defHttp.post({ url: Api.BatchRelease, params })
}

/**
 * @description: 查看活码详情
 */
export const getuniqueIdListApi = (params) => {
  return defHttp.post({ url: Api.GetuniqueIdList, params })
}

/**
 * @description: 活码业务场景列表查询
 */
export const getsceneListApi = (params = {}) => {
  return defHttp.get({ url: Api.GetsceneList, params })
}

/**
 * @description: 活码提交审核
 */
export const setSubmitApprovalApi = (params) => {
  return defHttp.post({ url: Api.SetSubmitApproval, params })
}

/**
 * @description: 活码撤回审核
 */
export const setWithdrawApprovalApi = (params) => {
  return defHttp.post({ url: Api.SetWithdrawApproval, params })
}

/**
 * @description: 单码生成
 */
export const createQRCodeInfoApi = (params) => {
  return defHttp.post({ url: Api.CreateQRCodeInfoApi, params })
}

/**
 * @description: 获取模板
 */
export const getTemplateApi = (params) => {
  return defHttp.get({ url: Api.GetTemplateApi, params })
}

/**
 * @description: 批量生成
 */
export const createExcelQRCodeTaskApi = (params) => {
  return defHttp.post({
    url: Api.CreateExcelQRCodeTaskApi,
    params,
    headers: { 'Content-Type': ContentTypeEnum.FORM_DATA },
  })
}

/**
 * @description: 级联查询渠道名称（四级）
 */
export const queryAllRelationApi = (params) => {
  return defHttp.get({ url: Api.QueryAllRelationApi, params })
}

/**
 * @description: 二维码列表查询
 */
export const queryQRCodeListApi = (params) => {
  return defHttp.post({ url: Api.QueryQRCodeListApi, params })
}
/**
 * @description: // 编辑小程序二维码回显
 */
export const updateQRCodeApi = (params) => {
  return defHttp.post({ url: Api.UpdateQRCodeApi, params })
}
/**
 * @description: 二维码模板上传
 */
export const uploadTemplateApi = () => {
  return `${VITE_GLOB_API_URL}${Api.UploadTemplateApi}`
}
