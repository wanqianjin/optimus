import { defHttp } from '/@/utils/http/axios'

// yapi: https://jmock.jiduauto.com/project/934/interface/api/16800
enum Api {
  // 一级项目
  QueryFirstLevelProjectList = '/channel/channel/firstLevel/project/list',
  createFirstLevelProject = '/channel/channel/firstLevel/project/create',
  updateFirstLevelProject = '/channel/channel/firstLevel/project/update',
  getFirstLevelProjectDetail = '/channel/channel/firstLevel/project/detail',
  changeFirstLevelProject = '/channel/channel/firstLevel/project/change',
  updateFirstLevelProjectCreateUser = '/channel/channel/firstLevel/project/updateCreateUser',
  // 二级项目
  QueryScendLevelProjectList = '/channel/channel/secondLevel/project/list',
  createScendLevelProject = '/channel/channel/secondLevel/project/create',
  updateScendLevelProject = '/channel/channel/secondLevel/project/update',
  getScendLevelProjectDetail = '/channel/channel/secondLevel/project/detail',
  changeSecondLevelProject = '/channel/channel/secondLevel/project/change',
  updateSecondLevelProjectCreateUser = '/channel/channel/secondLevel/project/updateCreateUser',
  // 三级项目
  QueryThirdLevelProjectList = '/channel/channel/thirdLevel/project/list',
  createThirdLevelProject = '/channel/channel/thirdLevel/project/create',
  updateThirdLevelProject = '/channel/channel/thirdLevel/project/update',
  getThirdLevelProjectDetail = '/channel/channel/thirdLevel/project/detail',
  changeThirdLevelProject = '/channel/channel/thirdLevel/project/change',
  updateThirdLevelProjectCostAmount = '/channel/channel/thirdLevel/project/updateCostAmount',

  //提交oa项目
  submitExamine = '/channel/channel/project/examine/submit',
  getConfigInfo = '/channel/channel/project/configInfo',
  queryProjectRelationByLevel = '/channel/channel/queryProjectRelationByLevel',
  queryAssociatedProjectByLevel = '/channel/channel/queryAssociatedProjectByLevel',

  // 项目是否能创建/编辑/提交审批/变更
  checkSecondLevelProjectCapabilities = '/channel/channel/secondLevel/operation/check',
  checkThirdLevelProjectCapabilities = '/channel/channel/thirdLevel/operation/check',

  // 获取权益跳转链接
  getRightsJumpLink = '/user-ares-backend/ares/backend/budget/jumpLink/get',
}

// -------------------一级项目------------------------
/**
 * @description: 条件查询一级项目列表
 */
export const QueryFirstLevelProjectListApi = (params) => {
  return defHttp.post({ url: Api.QueryFirstLevelProjectList, params })
}
/**
 * @description: 创建一级项目
 */
export const createFirstLevelProjectApi = (params) => {
  return defHttp.post({ url: Api.createFirstLevelProject, params })
}
/**
 * @description: 更新一级项目
 */
export const updateFirstLevelProjectApi = (params) => {
  return defHttp.post({ url: Api.updateFirstLevelProject, params })
}
/**
 * @description: 查询一级项目详情
 */
export const getFirstLevelProjectDetailApi = (params) => {
  return defHttp.get({ url: Api.getFirstLevelProjectDetail, params })
}
/**
 * @description: 变更一级项目
 */
export const changeFirstLevelProjectApi = (params) => {
  return defHttp.post({ url: Api.changeFirstLevelProject, timeout: 20 * 1000, params })
}
/**
 * @description: 一级管理员
 */
export const updateFirstLevelProjectCreateUserApi = (params) => {
  return defHttp.post({ url: Api.updateFirstLevelProjectCreateUser, params })
}

// -------------------二级项目------------------------
/**
 * @description: 条件查询三级列表
 */
export const QueryScendLevelProjectListApi = (params) => {
  return defHttp.post({ url: Api.QueryScendLevelProjectList, params })
}
/**
 * @description: 创建二级项目
 */
export const createScendLevelProjectApi = (params) => {
  return defHttp.post({ url: Api.createScendLevelProject, params })
}
/**
 * @description: 更新二级项目
 */
export const updateScendLevelProjectApi = (params) => {
  return defHttp.post({ url: Api.updateScendLevelProject, params })
}
/**
 * @description: 查询二级项目详情
 */
export const getScendLevelProjectDetailApi = (params) => {
  return defHttp.get({ url: Api.getScendLevelProjectDetail, params })
}
/**
 * @description: 变更二级项目
 */
export const changeSecondLevelProjectApi = (params) => {
  return defHttp.post({ url: Api.changeSecondLevelProject, timeout: 20 * 1000, params })
}
/**
 * @description: 二级管理员
 */
export const updateSecondLevelProjectCreateUserApi = (params) => {
  return defHttp.post({ url: Api.updateSecondLevelProjectCreateUser, params })
}

// -------------------三级项目------------------------
/**
 * @description: 条件查询三级列表
 */
export const QueryThirdLevelProjectListApi = (params) => {
  return defHttp.post({ url: Api.QueryThirdLevelProjectList, params })
}
/**
 * @description: 创建三级项目
 */
export const createThirdLevelProjectApi = (params) => {
  return defHttp.post({ url: Api.createThirdLevelProject, params })
}
/**
 * @description: 更新三级项目
 */
export const updateThirdLevelProjectApi = (params) => {
  return defHttp.post({ url: Api.updateThirdLevelProject, params })
}
/**
 * @description: 查询三级项目详情
 */
export const getThirdLevelProjectDetailApi = (params) => {
  return defHttp.get({ url: Api.getThirdLevelProjectDetail, params })
}
/**
 * @description: 变更三级项目
 */
export const changeThirdLevelProjectApi = (params) => {
  return defHttp.post({ url: Api.changeThirdLevelProject, timeout: 20 * 1000, params })
}
/**
 * @description: 三级管理员
 */
export const updateThirdLevelProjectCostAmountApi = (params) => {
  return defHttp.post({ url: Api.updateThirdLevelProjectCostAmount, params })
}
// ---------------------------------------------------------------

/**
 * @description: 提交审核
 */
export const submitExamineApi = (params) => {
  return defHttp.post({ url: Api.submitExamine, timeout: 20 * 1000, params })
}
/**
 * @description: 获取配置
 */
export const getConfigInfoApi = (params) => {
  return defHttp.get({ url: Api.getConfigInfo, params })
}
/**
 * @description: 获取项目树
 */
export const queryProjectRelationByLevelApi = (params) => {
  return defHttp.get({ url: Api.queryProjectRelationByLevel, params, timeout: 20 * 1000 })
}
/**
 * @description: 获取已通过项目树
 */
export const queryAssociatedProjectByLevelApi = (params) => {
  return defHttp.get({ url: Api.queryAssociatedProjectByLevel, params })
}

/**
 * @description: 获取已通过项目树
 */
export const getRightsJumpLinkApi = (params) => {
  return defHttp.get({ url: Api.getRightsJumpLink, params })
}
/**
 * @description:  二级 项目是否能创建/编辑/提交审批/变更
 */
export const checkSecondLevelProjectCapabilitiesApi = (params) => {
  return defHttp.get({ url: Api.checkSecondLevelProjectCapabilities, params })
}
/**
 * @description:  三级 项目是否能创建/编辑/提交审批/变更
 */
export const checkThirdLevelProjectCapabilitiesApi = (params) => {
  return defHttp.get({ url: Api.checkThirdLevelProjectCapabilities, params })
}
