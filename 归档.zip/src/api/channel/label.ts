import { defHttp } from '/@/utils/http/axios'

enum Api {
  QueryLabelListByLevel = '/channel/manage/label/query/by/level',
  QueryLabelListByParentId = '/channel/manage/label/query/by/parentId',
  QueryLabelAndChildren = '/channel/manage/label/query/labelAndChildren',
  CreateGroup = '/channel/manage/label/create/group',
  UpdateGroup = '/channel/manage/label/update/group',
  checkLabelName = '/channel/manage/label/check',
  CreateLabelValue = '/channel/manage/label/create/value',
  updateLabelValue = '/channel/manage/label/update/value',
}

/**
 * @description: 根据层级查询标签
 */
export const queryLabelListByLevelApi = (params) => {
  return defHttp.get({ url: Api.QueryLabelListByLevel, params })
}
/**
 * @description: 根据父级ID查询标签
 */
export const QueryLabelListByParentIdApi = (params) => {
  return defHttp.get({ url: Api.QueryLabelListByParentId, params })
}
/**
 * @description: 查询标签详情及子节点
 */
export const QueryLabelAndChildrenApi = (params) => {
  return defHttp.get({ url: Api.QueryLabelAndChildren, params })
}
/**
 * @description: 创建标签组
 */
export const CreateGroupApi = (params) => {
  return defHttp.post({ url: Api.CreateGroup, params })
}
/**
 * @description: 跟新标签组
 */
export const UpdateGroupApi = (params) => {
  return defHttp.post({ url: Api.UpdateGroup, params })
}
/**
 * @description: 跟新标签组
 */
export const CheckLabelNameApi = (params) => {
  return defHttp.post({ url: Api.checkLabelName, params })
}
/**
 * @description: 创建标签值
 */
export const CreateLabelValueApi = (params) => {
  return defHttp.post({ url: Api.CreateLabelValue, params })
}
/**
 * @description: 更新标签值
 */
export const updateLabelValueApi = (params) => {
  return defHttp.post({ url: Api.updateLabelValue, params })
}
