import { defHttp } from '/@/utils/http/axios'

enum Api {
  QueryAdvertisementList = '/b/content-backend/advertisement/backend/getAdvertisementList',
  DeleteAdvertisement = '/b/content-backend/advertisement/backend/deleteAdvertisement',
  CreateAdvertisement = '/b/content-backend/advertisement/backend/createAdvertisement',
  UpdateAdvertisement = '/b/content-backend/advertisement/backend/updateAdvertisement',
}

/**
 * @description: 获取广告列表
 */
export const queryAdvertisementListApi = (params) => {
  return defHttp.get({ url: Api.QueryAdvertisementList, params })
}
/**
 * @description: 删除广告
 */
export const deleteAdvertisementApi = (params) => {
  return defHttp.post({ url: Api.DeleteAdvertisement, params })
}
/**
 * @description: 创建广告
 */
export const createAdvertisementApi = (params) => {
  return defHttp.post({ url: Api.CreateAdvertisement, params })
}

/**
 * @description: 更新广告
 */
export const updateAdvertisementApi = (params) => {
  return defHttp.post({ url: Api.UpdateAdvertisement, params })
}
