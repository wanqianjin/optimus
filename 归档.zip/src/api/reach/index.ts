import { defHttp } from '/@/utils/http/axios'
import { useGlobSetting } from '/@/hooks/setting'

const globSetting = useGlobSetting() //获取全局变量
// https://jmock.jiduauto.com/project/1078/interface/api/30555 接口文档

enum Api {
  /*   QueryTemplateList = '/message/backend/templateConfig/queryTemplateList',
  GetNotificationTypeInfo = '/message/backend/common/getNotificationTypeInfo',
  GetNotificationSubTypeInfo = '/message/backend/common/getNotificationSubTypeInfo', */
  // 获取微信模版列表   https://jmock.jiduauto.com/project/631/interface/api/15206
  queryTemplateList = '/activity-backend-server/wx/queryTemplateList',
  getTemplateList = '/user-backend/touch/getTemplateList',
  Query5GSmsTemplateList = '/user-backend/touch/querySms5GTemplateList', //获取5G阅信模板列表
  QuerySms5GTemplateDetail = '/user-backend/touch/querySms5GTemplateDetail', //获取5G阅信模板参数列表

  //================================================================
  EnvList = '/user-backend/touch/autoEvent/envList', //获取不同环境列表
  WeChatTemplateList = '/user-backend/wx/queryTemplateList', //获取微信自动触达模板列表
  GetAllGroup = '/user-backend/touch/getAllGroup', //获取用户分群
  GetCDPGroup = '/user-backend/touch/getGroupListWithExpInfo', //人工触达获取cdp分群
  QueryCrowdList = '/user-backend/touch/queryCrowd',
  QueryTaskList = '/user-backend/touch/queryTask',
  QueryTestTaskExecute = '/user-backend/touch/testTaskExecute',
  QueryTouchUser = '/user-backend/touch/queryTouchUser',
  QueryTaskOperate = '/user-backend/touch/taskOperate',
  getManualTaskTypeEnum = '/user-backend/touch/getManualTaskTypeEnum', //获取人工触达通道类型枚举
  getClassificationList = '/user-backend/touch/getClassificationList', //自动人工触达app接全部消息类型
  getAutoTaskTypeEnum = '/user-backend/touch/getAutoTaskTypeEnum', //获取自动触达通道类型枚举
  createMixReachTask = '/user-backend/touch/createTask', //创建轮询触达
  UpdateMixReachTask = '/user-backend/touch/updateTask', //编辑混合触达
  Copytask = '/user-backend/touch/copyTask', //复制任务返回数据
  AutoPollingtask = '/user-backend/touch/createAutoPollingTask', //自动触达创建轮询
  updateAutoPollingtask = '/user-backend/touch/updateAutoPollingTask', //自动触达编辑轮询
  createCarMessageBox = '/user-backend/touch/createAutoVehicleTask', //自动触达创建车机消息
  updateCarMessageBox = '/user-backend/touch/updateAutoVehicleTask', //自动触达编辑车机消息
  getEsjList = '/user-backend/touch/getEsjList', //短信触达获取esj对应事件列表
  generateEsj = '/user-backend/touch/generateShortUrl', //短信触达转换短链接
  CreateSmsManualTask = '/user-backend/touch/createSmsManualTask',
  UpdateSmsManualTask = '/user-backend/touch/updateSmsManualTask',
  CreateWxManualTask = '/user-backend/touch/createWxManualTask',
  CreateTiktokAutoTask = '/user-backend/touch/createDyAutoTask', //抖音自动触达创建
  EditTiktokAutoTask = '/user-backend/touch/editDyAutoTask', //抖音自动触达编辑
  CreateWxAutoTask = '/user-backend/touch/createWxAutoTask', //微信自动触达创建
  EditWxAutoTask = '/user-backend/touch/editWxAutoTask', //微信自动触达编辑
  UpdateWxManualTask = '/user-backend/touch/updateWxManualTask',
  GetSmsMessageType = '/user-backend/touch/querySmsMessageType',
  QuerySignList = '/user-backend/touch/querySign',
  QuerySmsTemplateNameList = '/user-backend/touch/querySmsTemplateName',
  QueryTemplateParam = '/user-backend/touch/queryTemplateParam',
  GetWxMessageType = '/user-backend/touch/queryWxMessageType',
  QueryWeChatTemplateNameList = '/user-backend/touch/queryWeChatTemplateName',
  QueryTaskDetai = '/user-backend/touch/queryTaskDetail', //查询人工触达详情
  QueryTaskDetaiNum = '/user-backend/touch/queryTaskDetailNum', //查询人工触达详情结果
  QueryAutoTaskDetail = '/user-backend/touch/queryAutoTaskDetail',
  QueryAutoTaskDetailNum = '/user-backend/touch/queryAutoTaskDetailNum', //查询自动触达详情结果
  UploadFile = '/user-backend/touchs/uploadFileSmsManualTask',
  stencilMessage = '/user-backend/touchs/stencilMessage',
  fileParamList = '/user-backend/touch/fileParamList',
  createFileSmsManualTask = '/user-backend/touch/createFileSmsManualTask',
  updateFileSmsManualTask = '/user-backend/touch/updateFileSmsManualTask',
  excelErrorDown = '/user-backend/touchs/excelErrorDown',
  DownloadTemplate = '/user-backend/touchs/downFileSmsManualTask',
  QueryTaskFileDetail = '/user-backend/touch/queryTaskFileDetail',
  CreateAutoTask = '/user-backend/touch/createAutoTask',
  UpdateAutoTask = '/user-backend/touch/updateSmsAutoTask',
  QueryCondition = '/user-backend/touch/queryCondition',
  QuerySendHistoryList = '/user-backend/touch/querySendHistory', //自动触达获取表格信息
  QuerytaskStatusList = '/user-backend/touch/queryEnumCode/taskStatus',
  QueryAllTaskStatusList = '/user-backend/touch/queryEnumCode/taskStatusAll',
  queryAllRelationList = '/channel/channel/queryAllRelation', //https://jmock.jiduauto.com/project/934/interface/api/33243
  createPushAutoTask = '/user-backend/touch/createPushAutoTask',
  createPushManualTask = '/user-backend/touch/createPushManualTask',
  updatePushAutoTask = '/user-backend/touch/updatePushAutoTask',
  updatePushManualTask = '/user-backend/touch/updatePushManualTask',
  querySendHistoryDetail = '/user-backend/touch/querySendHistoryDetail',
  getCdpRealtimeTag = '/user-backend/touch/getCdpRealtimeTag',
  ConfirmTouch = '/user-backend/touch/manualConfirm',
  GetConditionTypeList = '/user-backend/touch/getConditionTypeList', // 获取触达条件类型
  GetEnumList = '/user-backend/touch/getEnumList', // 获取活动、任务类型的枚举值
  GetActivityList = '/user-backend/touch/getActivityList', // 获取活动、任务列表
  GetWhiteList = '/user-backend/touch/isValidApproveWhiteListUser', //判断用户是否为审核白名单
  QueryTaskDataList = '/user-backend/touch/taskDataList', //自动触达-任务列表-任务管理同步的任务列表

  // -----URL服务-----
  QueryShortUrlApi = '/user-backend/shortUrl/pageShortUrl',
  CreateShortUrlApi = '/user-backend/shortUrl/createShortUrl',
  UpdateShortUrlApi = '/user-backend/shortUrl/updateShortUrl',
  DeleteShortUrlApi = '/user-backend/shortUrl/deleteShortUrl',
  QueryLongUrlApi = '/user-backend/shortUrl/pageLongUrl',
  CreateLongUrlApi = '/user-backend/shortUrl/createLongUrl',
  UpdateLongUrlApi = '/user-backend/shortUrl/updateLongUrl',
  DeleteLongUrlApi = '/user-backend/shortUrl/deleteLongUrl',
  QueryAllJumpCountApi = '/user-backend/shortUrl/queryAllMiniAppCodeJumpCount',
  QueryUrlByIdApi = '/user-backend/shortUrl/queryUrlById',
  // -------事件管理---------
  QueryListApi = '/user-backend/touch/autoEvent/list', //事件管理列表
  DeleteAutoEventApi = '/user-backend/touch/autoEvent/close', //删除/关闭事件
  QueryBizNoApi = '/user-backend/touch/autoEvent/bizNo', //查询服务名List
  QueryEventDetailApi = '/user-backend/touch/autoEvent/detail', // 查询事件详情
  AddEventApi = '/user-backend/touch/autoEvent/add', //新增事件
  UpdateEventApi = '/user-backend/touch/autoEvent/update', //新增事件
  EnvDetailList = '/user-backend/touch/autoEvent/eventDataList', //事件管理同步的事件列表
  ManageUserList = '/message/backend/user/manageUserList', // 模糊查询新人员数据信息
  // -------风控配置---------
  QueryRiskList = '/user-backend/touch/queryRiskList', //获取风控配置数据列表
  AddRisk = '/user-backend/touch/addRisk', //添加风控配置
  UpdateRisk = '/user-backend/touch/updateRisk', //编辑风控配置
  DeleteRisk = '/user-backend/touch/deleteRisk', //删除风控配置
  QueryRiskById = '/user-backend/touch/queryRiskById', //通过id查询风控配置
  GetRiskMapping = '/user-backend/touch/riskMapping', // 获取风控通道任务枚举
}

//---------------风控配置---------------

/**
 * @description: 查询风控配置数据列表
 */
export const queryRiskListApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryRiskList, params })
}
/**
 * @description: 获取风控通道任务枚举
 */
export const getRiskMappingApi = (params = {}) => {
  return defHttp.get({ url: Api.GetRiskMapping, params })
}
/**
 * @description: 通过id查询风控配置
 */
export const queryRiskByIdApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryRiskById, params })
}
/**
 * @description: 添加风控配置
 */
export const addRiskApi = (params = {}) => {
  return defHttp.post({ url: Api.AddRisk, params })
}
/**
 * @description: 编辑风控配置
 */
export const updateRiskApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateRisk, params })
}
/**
 * @description: 删除风控配置
 */
export const deleteRiskApi = (params) => {
  return defHttp.post({ url: `${Api.DeleteRisk}?id=${params.id}` })
}

//-----------------------------

/**
 * @description: 获取wx内容模板和签名信息
 */
export const GetWeChatTemplateList = (params) => {
  return defHttp.get({ url: Api.WeChatTemplateList, params })
}
/**
 * @description: 获取环境列表
 */
export const queryEnvListApi = (params = {}) => {
  return defHttp.post({ url: Api.EnvList, params })
}
/**
 * @description: 获取事件列表
 */
export const envDetailListApi = (params = {}) => {
  return defHttp.post({ url: Api.EnvDetailList, params })
}
/**
 * @description: 用户信息-模糊查新人员数据信息:https://jmock.jiduauto.com/project/188/interface/api/96111
 */
export const manageUserListApi = (params = {}) => {
  return defHttp.post({ url: Api.ManageUserList, params })
}
/**
 * @description: 获取自动触达任务列表
 */
export const queryTaskDataListApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryTaskDataList, params })
}
/**
 * @description: 获取内容模板和签名名称
 */
/* export const queryTemplateList = (params) => {
  return defHttp.get({ url: Api.QueryTemplateList, params })
} */

/**
 * @description: 获取通道类型枚举信息 通道类型
 */
/* export const getNotificationTypeInfo = (params = {}) => {
  return defHttp.get({ url: Api.GetNotificationTypeInfo, params })
} */
/**
 * @description: 获取消息类型枚举信息 消息类型 依赖于通道类型
 */
/* export const getNotificationSubTypeInfo = (params = {}) => {
  return defHttp.get({ url: Api.GetNotificationSubTypeInfo, params })
} */
/**
 * @description: 获取微信分页模版列表
 */
export const queryTemplateList = (params = {}) => {
  return defHttp.get({ url: Api.queryTemplateList, params })
}
/**
 * @description: 获取微信模版列表
 */
export const getTemplateList = (params = {}) => {
  return defHttp.get({ url: Api.getTemplateList, params })
}

/**
 * @description: 获取5g阅信模版列表
 */
export const query5GSmsTemplateListApi = (params = {}) => {
  return defHttp.post({ url: Api.Query5GSmsTemplateList, params })
}

/**
 * @description: 获取5g阅信模版列表
 */
export const querySms5GTemplateParamsApi = (params = {}) => {
  return defHttp.post({ url: Api.QuerySms5GTemplateDetail, params })
}

// ===============================================================
/**
 * @description: CDP圈选信息 获取有所分组信息
 */

export const getAllGroupApi = (params = {}) => {
  return defHttp.get({ url: Api.GetAllGroup, params })
}
/**
 * @description: 获取CDP圈选信息
 */

export const getCDPGroupApi = (params = {}) => {
  return defHttp.get({ url: Api.GetCDPGroup, params })
}
/**
 * @description: 根据手机号、userId或用户分群查询用户
 */
export const queryCrowdListApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryCrowdList, params })
}
/**
 * @description: 分页查询（手工、自动）触达任务
 */
export const queryTaskListApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryTaskList, params })
}
/**
 * @description: 查询任务触达用户
 */
export const queryTouchUserApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryTouchUser, params })
}
/**
 * @description: 开启或关闭任务
 */
export const queryTaskOperatetApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryTaskOperate, params })
}

export const confirmManualTouch = (params = {}) => {
  return defHttp.post({ url: Api.ConfirmTouch, params })
}

/**
 * @description: 人工触达-获取人工触达通道类型枚举
 */
export const getManualTaskTypeEnumApi = (params = {}) => {
  return defHttp.get({ url: Api.getManualTaskTypeEnum, params })
}
/**
 * @description: 自动人工触达-app接全部消息类型
 */
export const getClassificationListApi = (params = {}) => {
  return defHttp.get({ url: Api.getClassificationList, params })
}
/**
 * @description: 自动触达-获取自动触达通道类型枚举
 */
export const getAutoTaskTypeEnumApi = (params = {}) => {
  return defHttp.get({ url: Api.getAutoTaskTypeEnum, params })
}
/**
 * @description: 人工触达-创建混合触达任务
 */
export const createMixReachTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.createMixReachTask, params })
}
/**
 * @description: 人工触达-编辑混合触达任务
 */
export const updateMixReachTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateMixReachTask, params })
}
/**
 * @description: 复制触达任务
 */
export const copyTaskApi = (params = {}) => {
  return defHttp.get({ url: Api.Copytask, params })
}
/**
 * @description: 自动触达-创建轮询触达任务
 */
export const CreatAutoPollingtask = (params = {}) => {
  return defHttp.post({ url: Api.AutoPollingtask, params })
}
/**
 * @description: 自动触达-编辑轮询触达任务
 */
export const UpdateAutoPollingtask = (params = {}) => {
  return defHttp.post({ url: Api.updateAutoPollingtask, params })
}
/**
 * @description: 自动触达-创建车机消息
 */
export const createCarMessage = (params = {}) => {
  return defHttp.post({ url: Api.createCarMessageBox, params })
}
/**
 * @description: 自动触达-编辑车机消息
 */
export const updateCarMessage = (params = {}) => {
  return defHttp.post({ url: Api.updateCarMessageBox, params })
}
/**
 * @description: 短信触达-获取esj对应事件列表
 */
export const getEsjListApi = (params = {}) => {
  return defHttp.get({ url: Api.getEsjList, params })
}
/**
 * @description: 短信触达-获取esj转换短链接
 */
export const generateEsjApi = (params = {}) => {
  return defHttp.post({ url: Api.generateEsj, params })
}
/**
 * @description: 人工触达-创建短信触达任务
 */
export const createSmsManualTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateSmsManualTask, params })
}
/**
 * @description: 人工触达-编辑短信触达任务
 */
export const updateSmsManualTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateSmsManualTask, params })
}
/**
 * @description: 查询短信消息类型
 */
export const getSmsMessageTypeApi = (params = {}) => {
  return defHttp.get({ url: Api.GetSmsMessageType, params })
}
/**
 * @description: 查询短信签名名称
 */
export const querySignListApi = (params = {}) => {
  return defHttp.get({ url: Api.QuerySignList, params })
}
/**
 * @description: 查询短信模板名称
 */
export const querySmsTemplateNameListApi = (params = {}) => {
  return defHttp.get({ url: Api.QuerySmsTemplateNameList, params })
}
/**
 * @description: 查询短信模板变量参数
 */
export const queryTemplateParamApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryTemplateParam, params })
}

/**
 * @description: 查询微信消息类型
 */
export const getWxMessageTypeApi = (params = {}) => {
  return defHttp.get({ url: Api.GetWxMessageType, params })
}
/**
 * @description: 查询微信信模板名称
 */
export const queryWeChatTemplateNameListApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryWeChatTemplateNameList, params })
}
/**
 * @description: 人工触达-创建微信触达任务
 */
export const createWxManualTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateWxManualTask, params })
}
/**
 * @description: 自动触达-创建抖音触达任务
 */
export const createTiktokAutoTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateTiktokAutoTask, params })
}
/**
 * @description: 人工触达-编辑抖音触达任务
 */
export const editTiktokAutoTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.EditTiktokAutoTask, params })
}
/**
 * @description: 自动触达-创建微信触达任务
 */
export const createWxAutoTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateWxAutoTask, params })
}
/**
 * @description: 人工触达-编辑微信触达任务
 */
export const updateWxManualTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateWxManualTask, params })
}
/**
 * @description: 自动触达-编辑微信触达任务
 */
export const editWxAutoTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.EditWxAutoTask, params })
}

/**
 * @description: 查询人工触达详情
 */
export const queryTaskDetailApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryTaskDetai, params })
}

/**
 * @description: 查询人工触达详情
 */
export const queryTaskDetailNumApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryTaskDetaiNum, params })
}
/**
 * @description: 判断用户是否为审核白名单
 */
export const getWhiteList = (params = {}) => {
  return defHttp.get({ url: Api.GetWhiteList, params })
}

/*
 * @description: --人工触达测试任务
 */
export const queryTestTaskExecuteApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryTestTaskExecute, params })
}
/**
 * @description: 查询自动触达详情
 */
export const queryAutoTaskDetailApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryAutoTaskDetail, params })
}
/**
 * @description: 查询自动触达详情
 */
export const queryAutoTaskDetailNumApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryAutoTaskDetailNum, params })
}
/**
 * @description: 查询多用户任务详情
 */
export const queryTaskFileDetailApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryTaskFileDetail, params })
}

/**
 * @description: 自动触达-创建触达任务
 */
export const createAutoTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateAutoTask, params })
}
/**
 * @description: 自动触达-编辑触达任务
 */
export const updateAutoTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateAutoTask, params })
}
/**
 * @description: 自动触达-查询触达条件
 */
export const queryConditionApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryCondition, params })
}
/**
 * @description: 自动触达-查询触达任务触达人群列表
 */
export const querySendHistoryListApi = (params) => {
  return defHttp.post({ url: Api.QuerySendHistoryList, params })
}
/**
 * @description: 自动触达-任务状态枚举
 */
export const querytaskStatusListApi = (params = {}) => {
  return defHttp.get({ url: Api.QuerytaskStatusList, params })
}
/**
 * @description: 变量触达-任务状态枚举
 */
export const queryAllTaskStatusListApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryAllTaskStatusList, params })
}
/**
 * @description: 关联渠道
 */
export const queryAllRelationListApi = (params = {}) => {
  return defHttp.get({ url: Api.queryAllRelationList, params })
}

/**
 * @description: 文件上传
 */
export const UploadFilelApi = () => {
  return `${globSetting.apiUrl}${Api.UploadFile}` //globSetting.apiUrl  获取全局域名
}

/**
 * @description: 模版下载
 */
export const downloadTemplatelApi = (templateId) => {
  return `${globSetting.apiUrl}${Api.DownloadTemplate}?templateId=${templateId}` //globSetting.apiUrl  获取全局域名
}

/**
 * @description: 文件解析
 */
export const stencilMessageApi = (params) => {
  return defHttp.get({ url: Api.stencilMessage, params })
}

/**
 * @description: 文件解析列表
 */
export const fileParamListApi = async (params) => {
  params.phone = params.phone ? +params.phone : undefined
  params.userId = params.userId || undefined
  const res = await defHttp.post({ url: Api.fileParamList, params })
  res.list = res.records
  res.count = res.total
  return res
}

/**
 * @description: 失败名单下载
 */
export const excelErrorDownApi = (fileId) => {
  return `${globSetting.apiUrl}${Api.excelErrorDown}?fileId=${fileId}` //globSetting.apiUrl  获取全局域名
}

/**
 * @description: 人工触达-创建文件触达任务
 */
export const createFileSmsManualTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.createFileSmsManualTask, params })
}
/**
 * @description: 人工触达-编辑文件触达任务
 */
export const updateFileSmsManualTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.updateFileSmsManualTask, params })
}

/**
 * @description: 自动触达-创建PUSH触达
 */
export const createPushAutoTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.createPushAutoTask, params })
}
/**
 * @description: 人工触达-创建PUSH触达
 */
export const createPushManualTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.createPushManualTask, params })
}
/**
 * @description: 自动触达-编辑PUSH触达
 */
export const updatePushAutoTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.updatePushAutoTask, params })
}
/**
 * @description: 人工触达-编辑PUSH触达
 */
export const updatePushManualTaskApi = (params = {}) => {
  return defHttp.post({ url: Api.updatePushManualTask, params })
}
/**
 * @description: 查看结果详情
 */
export const querySendHistoryDetailApi = (params = {}) => {
  return defHttp.get({ url: Api.querySendHistoryDetail, params })
}
/**
 * @description: 查看结果详情
 */
export const getCdpRealtimeTagApi = (params = {}) => {
  return defHttp.get({ url: Api.getCdpRealtimeTag, params })
}

// -----URL服务-----

/**
 * @description: 查询短链接
 */
export const queryShortUrlApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryShortUrlApi, params })
}

/**
 * @description: 创建短链接
 */
export const createShortUrlApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateShortUrlApi, params })
}

/**
 * @description: 修改短链接
 */
export const updateShortUrlApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateShortUrlApi, params })
}

/**
 * @description: 删除短链接
 */
export const deleteShortUrlApi = (params = {}) => {
  return defHttp.post({ url: Api.DeleteShortUrlApi, params })
}

/**
 * @description: 查询长链接
 */
export const queryLongUrlApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryLongUrlApi, params })
}

/**
 * @description: 创建长链接
 */
export const createLongUrlApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateLongUrlApi, params })
}

/**
 * @description: 修改长链接
 */
export const updateLongUrlApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateLongUrlApi, params })
}

/**
 * @description: 删除长链接
 */
export const deleteLongUrlApi = (params = {}) => {
  return defHttp.post({ url: Api.DeleteLongUrlApi, params })
}

/**
 * @description: 查询微信短链生成次数
 */
export const queryAllJumpCountApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryAllJumpCountApi, params })
}

/**
 * @description: 查询短链或者长链接详情
 */
export const queryUrlByIdApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryUrlByIdApi, params })
}

// ----------事件管理--------
/**
 * @description: 事件管理列表
 */
export const queryListApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryListApi, params })
}
/**
 * @description: 删除/关闭事件
 */
export const deleteAutoEventApi = (params = {}) => {
  return defHttp.post({ url: Api.DeleteAutoEventApi, params })
}
/**
 * @description: 查询服务名List
 */
export const queryBizNoListApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryBizNoApi, params })
}
/**
 * @description: 查询事件详情
 */
export const queryEventDetailApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryEventDetailApi, params })
}
/**
 * @description: 新增事件
 */
export const addEventApi = (params = {}) => {
  return defHttp.post({ url: Api.AddEventApi, params })
}
/**
 * @description: 新增事件
 */
export const updateEventApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateEventApi, params })
}
