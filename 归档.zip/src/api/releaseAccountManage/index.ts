import { defHttp } from '/@/utils/http/axios'
import { useGlobSetting } from '/@/hooks/setting'
const globSetting = useGlobSetting() //获取全局变量

enum Api {
  getDeliveryAccountList = '/user-reserve-backend/activity/delivery/account/list',
  createDeliveryAccount = '/user-reserve-backend/activity/delivery/account/create',
  getDeliveryAccountDetail = '/user-reserve-backend/activity/delivery/account/detail',
  updateDeliveryAccount = '/user-reserve-backend/activity/delivery/account/update',
  updateDeliveryAccountEditPermission = '/user-reserve-backend/activity/delivery/account/editPermission/update',
  updateDeliveryAccountStatus = '/user-reserve-backend/activity/delivery/account/status/update',
  deliveryAccountListDownload = '/user-reserve-backend/activity/delivery/account/download',
  getDeliveryAccountConfig = '/user-reserve-backend/activity/delivery/account/config',

  // 投放平台管理
  getPlatformList = '/user-reserve-backend/ad/platform/screenConfig',
  createConfig = '/user-reserve-backend/ad/platform/createConfig',
  editConfig = '/user-reserve-backend/ad/platform/editConfig',
  exportConfig = '/user-reserve-backend/ad/platform/exportConfig',
}

/**
 * @description: 账号信息列表 https://jmock.jiduauto.com/project/110/interface/api/102243
 */
export const getDeliveryAccountListApi = (params) => {
  return defHttp.post({ url: Api.getDeliveryAccountList, params })
}
/**
 * @description: 新增投放账号 https://jmock.jiduauto.com/project/110/interface/api/102243
 */
export const createDeliveryAccountApi = (params) => {
  return defHttp.post({ url: Api.createDeliveryAccount, params })
}
/**
 * @description: 查看账号信息 https://jmock.jiduauto.com/project/110/interface/api/102243
 */
export const getDeliveryAccountDetailApi = (params) => {
  return defHttp.get({ url: Api.getDeliveryAccountDetail, params })
}
/**
 * @description: 编辑投放账号信息 https://jmock.jiduauto.com/project/110/interface/api/102243
 */
export const updateDeliveryAccountApi = (params) => {
  return defHttp.post({ url: Api.updateDeliveryAccount, params })
}
/**
 * @description: 更新编辑权限 https://jmock.jiduauto.com/project/110/interface/api/102243
 */
export const updateDeliveryAccountEditPermissionApi = (params) => {
  return defHttp.post({ url: Api.updateDeliveryAccountEditPermission, params })
}
/**
 * @description: 更新账号状态 https://jmock.jiduauto.com/project/110/interface/api/102243
 */
export const updateDeliveryAccountStatusApi = (params) => {
  return defHttp.post({ url: Api.updateDeliveryAccountStatus, params })
}
/**
 * @description: 下载账户列表信息 https://jmock.jiduauto.com/project/110/interface/api/102243
 */
export const deliveryAccountListDownloadApi = () => {
  return `${globSetting.apiUrl}${Api.deliveryAccountListDownload}` //globSetting.apiUrl  获取全局域名
}
/**
 * @description: 配置相关信息 https://jmock.jiduauto.com/project/110/interface/api/102243
 */
export const getDeliveryAccountConfigApi = (params) => {
  return defHttp.get({ url: Api.getDeliveryAccountConfig, params })
}

// ---------------投放平台管理-------------------

/**
 * @description: 投放平台配置-筛选 https://jmock.jiduauto.com/project/2461/interface/api/144199
 */
export const getPlatformListApi = (params) => {
  return defHttp.get({ url: Api.getPlatformList, params })
}
/**
 * @description: 投放平台配置-创建https://jmock.jiduauto.com/project/2461/interface/api/144187
 */
export const createConfigApi = (params) => {
  return defHttp.post({ url: Api.createConfig, params })
}
/**
 * @description: 投放平台配置-编辑https://jmock.jiduauto.com/project/2461/interface/api/144187
 */
export const editConfigApi = (params) => {
  return defHttp.post({ url: Api.editConfig, params })
}
/**
 * @description: 投放平台配置-编辑https://jmock.jiduauto.com/project/2461/interface/api/144187
 */
export const exportConfig = (params = {}) => {
  return defHttp.get(
    {
      url: Api.exportConfig,
      params,
      responseType: 'blob',
    },
    { isTransformResponse: false },
  )
}
