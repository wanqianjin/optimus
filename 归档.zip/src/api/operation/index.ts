import { defHttp } from '/@/utils/http/axios'

enum Api {
  QueryContentList = '/b/content-backend/backend/queryContentList',
  QueryArticleList = '/b/content-backend/backend/queryArticleList',
  UpdateContent = '/b/content-backend/backend/updateContent',
  CreateContent = '/b/content-backend/backend/createContent',
  ShelveContent = '/b/content-backend/backend/shelveContent',
  QueryAuthorList = '/b/content-backend/backend/queryAuthorList',
  DeleteArticle = '/b/content-backend/backend/deleteArticle',
  QueryAllAuthorList = '/b/content-backend/backend/queryAllAuthorList',
  QueryAllVestList = '/b/content-backend/backend/queryAllVestList',
  CreateArticle = '/b/content-backend/backend/createArticle',
  UpdateArticle = '/b/content-backend/backend/updateArticle',
  CreateAuthor = '/b/content-backend/backend/createAuthor',
  UpdateAuthor = '/b/content-backend/backend/updateAuthor',
  QueryCommentList = '/b/content-backend/backend/queryCommentList',
  UpdateComment = '/b/content-backend/backend/updateComment',
  ReplyComment = '/b/content-backend/backend/replyComment',

  CreateSubject = '/b/content-backend/backend/createSubject',
  QuerySubjectList = '/b/content-backend/backend/querySubjectList',
  UpdateSubject = '/b/content-backend/backend/updateSubject',
  UpdateSubjectSequence = '/b/content-backend/backend/updateSubjectSequence',
  UpdateSubjectStatus = '/b/content-backend/backend/updateSubjectVisible',
  QuerySubjectDetail = '/b/content-backend/backend/subjectDetail',
  QueryArticle = '/b/content-backend/backend/subject/queryArticle',
  QueryFeedArticle = '/b/content-backend/backend/feed/queryArticle',
  DeleteSubject = '/b/content-backend/backend/deleteSubject',
  QuerySubjectTypes = '/b/content-backend/backend/querySubjectTabNameList',
  UpdateSubjectTypes = '/b/content-backend/backend/updateSubjectTab',
  // CreateSubjectType = '/b/content-backend/backend/createSubjectTab',
  QuerySubjectTabList = '/b/content-backend/backend/subjectTabList',
  QuerySubjectNameList = '/b/content-backend/backend/querySubjectNameList',

  CreatePictures = '/b/content-backend/backend/createPictures',
  QueryArticleDetail = '/b/content-backend/backend/queryArticleDetail',
  UpdatePictures = '/b/content-backend/backend/updatePictures',

  CreateVideo = '/b/content-backend/backend/createVideo',
  UpdateVideo = '/b/content-backend/backend/updateVideo',

  QueryContentDetail = '/b/content-backend/backend/queryContentDetail',
  QueryCDPTagList = '/b/content-backend/backend/queryCDPTagList',

  GetTabsList = '/mastersite/configContent/backend/tab/info/apollo',

  // 图库管理
  QueryPictureStoreList = '/b/content-backend/backend/queryPictureStoreList',
  CreatePictureStore = '/b/content-backend/backend/createPictureStore',
  UpdatePictureStore = '/b/content-backend/backend/updatePictureStore',
  QueryPictureCollectionName = '/b/content-backend/backend/queryPictureCollectionName',
  DeletePictureStore = '/b/content-backend/backend/deletePictureStore',
  QueryPictureStore = '/b/content-backend/backend/queryPictureStore',

  // 投票管理
  QueryVoteManageList = '/b/content-backend/vote/queryList',
  QueryVoteDetail = '/b/content-backend/vote/detail',
  QuertVoteByArticle = '/b/content-backend/vote/queryByKeyword',
  CreateVote = '/b/content-backend/vote/create',
  UpdateVote = '/b/content-backend/vote/update',
  UpdateVoteStatus = '/b/content-backend/vote/updateStatus',

  // ======落地页管理======  https://jmock.jiduauto.com/project/110/interface/api/29779
  QueryAllRelation = '/channel/channel/queryAllRelation', //https://jmock.jiduauto.com/project/934/interface/api/33243
  QueryModelEditionList = '/user-reserve-backend/getRawModelEditionList',
  QueryReservePageInfoList = '/user-reserve-backend/queryReservePageInfoList',
  QueryPreviewReservePage = '/user-reserve-backend/previewReservePage',
  QueryCopyReservePage = '/user-reserve-backend/copyReservePage',
  QueryDownReservePage = '/user-reserve-backend/downReservePage',
  QueryReleaseReservePage = '/user-reserve-backend/releaseReservePage',
  QueryReservePageInfo = '/user-reserve-backend/queryReservePageInfo',
  CreateReservePageInfo = '/user-reserve-backend/createReservePageInfo',
  QueryEditReservePageInfo = '/user-reserve-backend/editReservePageInfo',
  QueryReservePageView = '/user-reserve-backend/queryReservePageView',
  CreateReservePageView = '/user-reserve-backend/createReservePageView',
  QueryEditReservePageView = '/user-reserve-backend/editReservePageView',
  QueryDownloadEventLinks = '/user-reserve-backend/downloadEventLinks',
  DeleteReservePage = '/user-reserve-backend/deleteReservePage',

  // UGC管理
  getArticleList = '/b/content-backend/ugc/articleList',
  // 获取话题下列表
  getTopicArticleList = '/b/content-backend/topic/ugcList',
  operateArticle = '/b/content-backend/ugc/articleOperate',

  // 话题管理
  queryTopic = '/b/content-backend/topic/queryTopic',
  queryAllTopic = '/b/content-backend/topic/queryAllTopic',
  updateTopic = '/b/content-backend/topic/updateTopic',
  createTopic = '/b/content-backend/topic/createTopic',

  // 话题下ugc管理
  getArticleListFromTopic = '/b/content-backend/topic/ugcList',
  editArticleFromTopic = '/b/content-backend/topic/updateArticleSequence',

  // 审核管理
  auditContentList = '/b/content-backend/audit/auditContentList',
  auditContentDetail = '/b/content-backend/audit/auditContentDetail',
  auditOper = '/b/content-backend/audit/updateAuditContent',
  queryOperateLog = '/b/content-backend/audit/auditOperationLog',
  QueryFromApollo = '/user-reserve-backend/queryReserveFrontConfig',

  scheduledPublishContent = '/b/content-backend/backend/scheduledPublishContent',
  deleteContent = '/b/content-backend/backend/deleteContent',
  publishArticle = '/b/content-backend/backend/publishArticle',
  summaryOcr = '/b/content-backend/backend/ocr',

  // 用户管理
  querySilentUser = '/b/content-backend/backend/querySilentUser',
  silenceUser = '/b/content-backend/backend/silenceUser',
  createSilent = '/b/content-backend/backend/createSilentUser',
  silentOperateLog = '/b/content-backend/backend/silentOperationList',
}

/**
 * @description: 获取apollo配置 tab信息   https://jmock.jiduauto.com/project/403/interface/api/39847
 */
export const getTabsListApi = (params) => {
  return defHttp.get({ url: Api.GetTabsList, params })
}

/**
 * @description: 获取内容列表
 */
export const queryContentListApi = (params) => {
  return defHttp.get({ url: Api.QueryContentList, params })
}

/**
 * @description: 获取文章列表
 */
export const queryArticleListApi = (params) => {
  return defHttp.get({ url: Api.QueryArticleList, params })
}

/**
 * @description: 创建内容
 */
export const createContentApi = (params) => {
  return defHttp.post({ url: Api.CreateContent, params })
}

/**
 * @description: 更新内容状态
 */
export async function updateContentApi(params) {
  return defHttp.post({ url: Api.UpdateContent, params })
}

/**
 * @description: 更新上架状态
 */
export async function shelveContentApi(params) {
  return defHttp.post({ url: Api.ShelveContent, params })
}

/**
 * @description: 获取作者账号列表
 */
export async function queryAuthorListApi(params) {
  return defHttp.get({ url: Api.QueryAuthorList, params })
}

/**
 * @description: 删除文章
 */
export async function deleteArticleApi(params) {
  return defHttp.post({ url: Api.DeleteArticle, params })
}

/**
 * @description: 一次性获取所有作者列表
 */
export async function queryAllAuthorListApi(params) {
  return defHttp.get({ url: Api.QueryAllAuthorList, params })
}

/**
 * @description: 一次性获取所有作者列表,新接口，评论回复用
 */
export async function queryAllVestListApi(params) {
  return defHttp.get({ url: Api.QueryAllVestList, params })
}

/**
 * @description: 发布文章(创建文章)
 */
export async function createArticleApi(params) {
  return defHttp.post({ url: Api.CreateArticle, params })
}

/**
 * @description: 更新文章
 */
export async function updateArticleApi(params) {
  return defHttp.post({ url: Api.UpdateArticle, params })
}

/**
 * @description: 创建作者
 */
export async function createAuthorApi(params) {
  return defHttp.post({ url: Api.CreateAuthor, params })
}

/**
 * @description: 更新作者信息
 */
export async function updateAuthorApi(params) {
  return defHttp.post({ url: Api.UpdateAuthor, params })
}

/**
 * @description: 获取评论列表
 */
export async function queryCommentListApi(params) {
  return defHttp.get({ url: Api.QueryCommentList, params })
}

/**
 * @description: 更新评论显示隐藏
 */
export async function updateCommentApi(params) {
  return defHttp.post({ url: Api.UpdateComment, params })
}

/**
 * @description: 回复评论
 */
export async function replyCommentApi(params) {
  return defHttp.post({ url: Api.ReplyComment, params })
}

/**
 * @description: 创建专题
 */
export async function createSubject(params) {
  return defHttp.post({ url: Api.CreateSubject, params }, { isTransformResponse: false })
}

/**
 * @description: 查询专题列表
 */
export async function querySubjectList(params) {
  return defHttp.post({ url: Api.QuerySubjectList, params })
}

/**
 * @description: 下拉查询专题列表
 */
export async function querySubjectNameList(params) {
  return defHttp.get({ url: Api.QuerySubjectNameList, params })
}

/**
 * @description: 更新专题
 */
export async function updateSubject(params) {
  return defHttp.post({ url: Api.UpdateSubject, params }, { isTransformResponse: false })
}

/**
 * @description: 更新专题排序
 */
export async function updateSubjectSequence(params) {
  return defHttp.post({ url: Api.UpdateSubjectSequence, params }, { isTransformResponse: false })
}

/**
 * @description: 专题上下架
 */
export async function updateSubjectStatus(params) {
  return defHttp.post({ url: Api.UpdateSubjectStatus, params }, { isTransformResponse: false })
}

/**
 * @description: 查询专题详情
 */
export async function querySubjectDetail(params) {
  return defHttp.get({ url: Api.QuerySubjectDetail, params })
}

/**
 * @description: 视频查询下拉专题分类
 */
export async function querySubjectTypes(params) {
  return defHttp.get({ url: Api.QuerySubjectTypes, params })
}

/**
 * @description: 查询专题分类详情
 */
export async function querySubjectTabList(params) {
  return defHttp.get({ url: Api.QuerySubjectTabList, params })
}

/**
 * @description: 创建&&更新专题分类详情
 */
export async function updateSubjectTypes(params) {
  return defHttp.post({ url: Api.UpdateSubjectTypes, params }, { isTransformResponse: false })
}

// /**
//  * @description: 创建专题分类详情
//  */
// export async function createSubjectTypes(params) {
//   return defHttp.post({ url: Api.CreateSubjectType, params })
// }

/**
 * @description: 专题查询文章
 */
export async function queryArticle(params) {
  return defHttp.get({ url: Api.QueryArticle, params }, { isTransformResponse: false })
}

/**
 * @description: feed查询文章
 */
export async function queryFeedArticle(params) {
  return defHttp.get({ url: Api.QueryFeedArticle, params }, { isTransformResponse: false })
}

/**
 * @description: 删除专题
 */
export async function deleteSubject(params) {
  return defHttp.post({ url: Api.DeleteSubject, params }, { isTransformResponse: false })
}

/**
 * @description: 创建图集 https://jmock.jiduauto.com/project/146/interface/api/29259
 */
export async function createPicturesApi(params) {
  return defHttp.post({ url: Api.CreatePictures, params })
}
/**
 * @description: 查看文章详情 https://jmock.jiduauto.com/project/146/interface/api/1003
 */
export async function queryArticleDetailApi(params) {
  return defHttp.get({ url: Api.QueryArticleDetail, params })
}

/**
 * @description: 编辑图集 https://jmock.jiduauto.com/project/146/interface/api/29287
 */
export async function updatePicturesApi(params) {
  return defHttp.post({ url: Api.UpdatePictures, params })
}

/**
 * @description: 创建视频 https://jmock.jiduauto.com/project/146/interface/api/29579
 */
export async function createVideoApi(params) {
  return defHttp.post({ url: Api.CreateVideo, params })
}

/**
 * @description: 编辑视频 https://jmock.jiduauto.com/project/146/interface/api/29283
 */
export async function updateVideoApi(params) {
  return defHttp.post({ url: Api.UpdateVideo, params })
}

/**
 * @description: 查询内容详情 https://jmock.jiduauto.com/project/146/interface/api/30995
 */
export async function queryContentDetailApi(params) {
  return defHttp.get({ url: Api.QueryContentDetail, params })
}

/**
 * @description: 查询cdp标签列表
 */
export async function queryCDPTagListApi() {
  return defHttp.get({ url: Api.QueryCDPTagList })
}

// ======图库管理========
/**
 * @description: 获取图库列表 https://jmock.jiduauto.com/project/146/interface/api/34111
 */
export const queryPictureStoreListApi = (params) => {
  return defHttp.get({ url: Api.QueryPictureStoreList, params })
}
/**
 * @description: 创建图库 https://jmock.jiduauto.com/project/146/interface/api/34071
 */
export const createPictureStoreApi = (params) => {
  return defHttp.post({ url: Api.CreatePictureStore, params })
}
/**
 * @description: 编辑图库（包含状态上下架） https://jmock.jiduauto.com/project/146/interface/api/34071
 */
export const updatePictureStoreApi = (params) => {
  return defHttp.post({ url: Api.UpdatePictureStore, params })
}
/**
 * @description: 图集查询接口 https://jmock.jiduauto.com/project/146/interface/api/34415
 */
export const queryPictureCollectionNameApi = (params) => {
  return defHttp.get({ url: Api.QueryPictureCollectionName, params })
}
/**
 * @description: 删除图集 https://jmock.jiduauto.com/project/146/interface/api/34423
 */
export const deletePictureStoreApi = (params) => {
  return defHttp.post({ url: Api.DeletePictureStore, params })
}
/**
 * @description: 查询图集详情 https://jmock.jiduauto.com/project/146/interface/api/34423
 */
export const queryPictureStoreApi = (params) => {
  return defHttp.get({ url: Api.QueryPictureStore, params })
}
// ====落地页管理==== https://jmock.jiduauto.com/project/110/interface/api/29779
/**
 * @description: 级联查询渠道名称（四级）
 */
export const queryAllRelationApi = (params) => {
  return defHttp.get({ url: Api.QueryAllRelation, params, timeout: 15000 })
}
/**
 * @description: 车型版本列表
 */
export const queryModelEditionListApi = (params) => {
  return defHttp.get({ url: Api.QueryModelEditionList, params })
}

/**
 * @description: 查询留资页列表
 */
export const queryReservePageInfoListApi = (params) => {
  return defHttp.post({ url: Api.QueryReservePageInfoList, params })
}

/**
 * @description: 预览页面
 */
export const queryPreviewReservePageApi = (params) => {
  return defHttp.get({ url: Api.QueryPreviewReservePage, params })
}
/**
 * @description: 复制页面
 */
export const QueryCopyReservePageApi = (params) => {
  return defHttp.post({ url: Api.QueryCopyReservePage, params })
}

/**
 * @description: 页面下线
 */
export const QueryDownReservePageApi = (params) => {
  return defHttp.post({ url: Api.QueryDownReservePage, params })
}
/**
 * @description: 页面发布
 */
export const QueryReleaseReservePageApi = (params) => {
  return defHttp.post({ url: Api.QueryReleaseReservePage, params })
}
/**
 * @description: 获取表单信息
 */
export const queryReservePageInfoApi = (params) => {
  return defHttp.get({ url: Api.QueryReservePageInfo, params })
}
/**
 * @description: 新建落地页基础信息
 */
export const createReservePageInfoApi = (params) => {
  return defHttp.post({ url: Api.CreateReservePageInfo, params })
}
/**
 * @description: 编辑落地页基础信息
 */
export const queryEditReservePageInfoApi = (params) => {
  return defHttp.post({ url: Api.QueryEditReservePageInfo, params })
}

/**
 * @description: 获取编辑视图页面
 */
export const queryReservePageViewApi = (params) => {
  return defHttp.get({ url: Api.QueryReservePageView, params })
}
/**
 * @description: 新建落地页页面视图
 */
export const createReservePageViewApi = (params) => {
  return defHttp.post({ url: Api.CreateReservePageView, params })
}
/**
 * @description: 编辑落地页页面视图
 */
export const queryEditReservePageViewApi = (params) => {
  return defHttp.post({ url: Api.QueryEditReservePageView, params })
}
/**
 * @description: 下载渠道事件链接
 */
export const queryDownloadEventLinksApi = (params) => {
  return defHttp.get({ url: Api.QueryDownloadEventLinks, params })
}
/**
 * @description: 获取apollo 兜底图
 */
export const queryFromApolloApi = (params) => {
  return defHttp.get({ url: Api.QueryFromApollo, params })
}
/**
 * @description: 删除落地页
 */
export const deleteReservePageApi = (params) => {
  return defHttp.post({ url: Api.DeleteReservePage, params })
}

/**
 * @description: 投票列表查询
 */
export const queryVoteListApi = async (params) => {
  return defHttp.post({ url: Api.QueryVoteManageList, params })
}

export const queryVoteByArticleApi = async (params) => {
  return defHttp.get({ url: Api.QuertVoteByArticle, params })
}

export const queryVoteDetailApi = async (params) => {
  return defHttp.get({ url: Api.QueryVoteDetail, params })
}

export const createVoteApi = async (params) => {
  return defHttp.post({ url: Api.CreateVote, params })
}

export const editVoteApi = async (params) => {
  return defHttp.post({ url: Api.UpdateVote, params })
}
export const updateVoteStatusApi = async (params) => {
  return defHttp.post({ url: Api.UpdateVoteStatus, params })
}

// UGC管理
export const getArticleList = async (params) => {
  return defHttp.post({ url: Api.getArticleList, params })
}
export const getTopicArticleList = async (params) => {
  return defHttp.post({ url: Api.getTopicArticleList, params })
}
export const operateArticle = async (params) => {
  return defHttp.post({ url: Api.operateArticle, params })
}

// 审核管理
export const auditContentList = async (params) => {
  return defHttp.post({ url: Api.auditContentList, params })
}
export const auditContentDetail = async (params) => {
  return defHttp.get({ url: Api.auditContentDetail, params })
}
export const auditOper = async (params) => {
  return defHttp.post({ url: Api.auditOper, params })
}
export const queryOperateLog = async (params) => {
  return defHttp.post({ url: Api.queryOperateLog, params })
}

// 话题管理
export const createTopic = async (params) => {
  return defHttp.post({ url: Api.createTopic, params })
}
export const queryTopic = async (params) => {
  return defHttp.get({ url: Api.queryTopic, params })
}
export const updateTopic = async (params) => {
  return defHttp.post({ url: Api.updateTopic, params })
}
export const queryAllTopic = async (params) => {
  return defHttp.get({ url: Api.queryAllTopic, params })
}
export const getArticleListFromTopic = async (params) => {
  return defHttp.get({ url: Api.getArticleListFromTopic, params })
}
export const editArticleFromTopic = async (params) => {
  return defHttp.post({ url: Api.editArticleFromTopic, params })
}

// feed列表
export const scheduledPublishContent = async (params) => {
  return defHttp.post({ url: Api.scheduledPublishContent, params })
}
export const deleteContent = async (params) => {
  return defHttp.post({ url: Api.deleteContent, params })
}
export const publishArticle = async (params) => {
  return defHttp.post({ url: Api.publishArticle, params })
}

// PGC内容
export const summaryOcr = async (params) => {
  return defHttp.post({ url: Api.summaryOcr, params })
}

// 禁言用户列表查询
export const querySilentUser = async (params) => {
  return defHttp.post({ url: Api.querySilentUser, params })
}

// 禁言/解封用户
export const silenceUser = async (params) => {
  return defHttp.post({ url: Api.silenceUser, params })
}

// 新增禁言用户
export const createSilent = async (params) => {
  return defHttp.post({ url: Api.createSilent, params })
}

// 查看操作日志
export const silentOperateLog = async (params) => {
  return defHttp.get({ url: Api.silentOperateLog, params })
}
