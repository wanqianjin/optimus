import { defHttp } from '/@/utils/http/axios'
// import axios from 'axios'

enum Api {
  GetLabelPageList = '/b/content-backend/label/backend/getLabelPageList',
  CreateLabel = '/b/content-backend/label/backend/createLabel',
  GetAllLabel = '/b/content-backend/label/backend/getAllLabel',
  DeleteLabel = '/b/content-backend/label/backend/deleteLabel',
}

/**
 * @description: 获取标签列表
 */
export const getLabelPageListApi = (params = {}) => {
  return defHttp.get({ url: Api.GetLabelPageList, params })
}

/**
 * @description: 创建标签
 */
export const createLabelApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateLabel, params })
}

/**
 * @description: 获取所有标签枚举-用于下拉列表
 */
export const GetAllTagApi = (params = {}) => {
  return defHttp.get({ url: Api.GetAllLabel, params })
}

/**
 * @description: 获取所有标签枚举-用于下拉列表
 */
export const deleteTagApi = (params = {}) => {
  return defHttp.post({ url: Api.DeleteLabel, params })
}
