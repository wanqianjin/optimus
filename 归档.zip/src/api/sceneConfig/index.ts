import { defHttp } from '/@/utils/http/axios'
import { useGlobSetting } from '/@/hooks/setting'
import dayjs from 'dayjs'
import { message } from '@jidu/robot-ui'
import { ContentTypeEnum } from '/@/enums/httpEnum'

const VITE_GLOB_API_URL = import.meta.env.VITE_GLOB_API_URL
const globSetting = useGlobSetting()

enum Api {
  QueryPlanList = '/b/scene-engine-backend/behavior-tree/releasePlan/v3/pagingQuery',
  QueryCarListOptions = '/b/scene-engine-backend/behavior-tree/carType/list',
  QueryByCondition = '/b/scene-engine-backend/behavior-tree/tree/queryByCondition',
  QueryReleasePlan = '/b/scene-engine-backend/behavior-tree/releasePlan/get/',
  QueryAdvancedByPlanId = '/b/scene-engine-backend/behavior-tree/tree/queryAdvancedByPlanId',
  OnlineReleasePlan = '/b/scene-engine-backend/behavior-tree/releasePlan/online/',
  QueryGrayRelease = '/b/scene-engine-backend/behavior-tree/grayRelease/get/',
  CheckGrayRelease = '/b/scene-engine-backend/behavior-tree/grayRelease/check',
  PublishGrayRelease = '/b/scene-engine-backend/behavior-tree/grayRelease/executeGrayRelease',
  GrayRollback = '/b/scene-engine-backend/behavior-tree/grayRelease/executeRollback',
  GrayFullRelease = '/b/scene-engine-backend/behavior-tree/grayRelease/executeFullRelease',
  CreatePlan = '/b/scene-engine-backend/behavior-tree/releasePlan/create',
  UpdatePlan = '/b/scene-engine-backend/behavior-tree/releasePlan/update',
  QueryBasalByPlanId = '/b/scene-engine-backend/behavior-tree/tree/queryBasalByPlanId',
  QuerySceneList = '/b/scene-engine-backend/behavior-tree/scene/list',
  QuerySceneDetail = '/b/scene-engine-backend/behavior-tree/scene/get/',
  UploadCheckFile = '/b/scene-engine-backend/behavior-tree/scene/uploadCheckFile',
  UploadSceneFile = '/b/scene-engine-backend/behavior-tree/scene/uploadSceneFile',
  getAllPlanBrief = '/b/scene-engine-backend/behavior-tree/manager/getAllPlanBrief',
  pagingQueryCommandLog = '/b/scene-engine-backend/behavior-tree/manager/pagingQueryCommandLog',
  exportSceneMd5 = '/b/scene-engine-backend/behavior-tree/releasePlan/exportSceneMd5',
  queryAndCompare = '/b/scene-engine-backend/behavior-tree/releasePlan/queryAndCompare',
  getReleasePlanStats = '/b/scene-engine-backend/behavior-tree/releasePlan/stats',
  syncReleasePlan = '/b/scene-engine-backend/behavior-tree/releasePlan/sync',
  queryVehicleSceneList = '/b/scene-engine-backend/behavior-tree/vehicleScene/list',
  releaseVehicleScene = '/b/scene-engine-backend/behavior-tree/vehicleScene/release',
  getVehicleScene = '/b/scene-engine-backend/behavior-tree/vehicleScene/get',
}

/**
 * @description: 获取发布场景列表: https://jmock.jiduauto.com/project/1717/interface/api/65931
 */
export const queryPlanListApi = (params) => {
  return defHttp.post({ url: Api.QueryPlanList, params })
}

/**
 * @description: 查询车型: https://jmock.jiduauto.com/project/1717/interface/api/65935
 */
export const queryCarListOptionsApi = () => {
  return defHttp.get({ url: Api.QueryCarListOptions })
}

/**
 * @description: 查询基准发布计划和场景-按车型或发布计划: https://jmock.jiduauto.com/project/1717/interface/api/65947
 */
export const queryByConditionApi = (params) => {
  return defHttp.get({ url: Api.QueryByCondition, params })
}

/**
 * @description: 查询发布计划详情: https://jmock.jiduauto.com/project/1717/interface/api/65983
 */
export const queryReleasePlanApi = (params) => {
  return defHttp.get({ url: Api.QueryReleasePlan, params })
}

/**
 * @description: 查询发布计划关联的场景-包含版本变更信息: https://jmock.jiduauto.com/project/1717/interface/api/65943
 */
export const queryAdvancedByPlanIdApi = (params) => {
  return defHttp.get({ url: Api.QueryAdvancedByPlanId, params })
}

/**
 * @description: 上线发布计划: https://jmock.jiduauto.com/project/1717/interface/api/65959
 */
export const onlineReleasePlanApi = (params) => {
  return defHttp.post({ url: Api.OnlineReleasePlan, params })
}

/**
 * @description: 查看灰度详情: https://jmock.jiduauto.com/project/1717/interface/api/65963
 */
export const queryGrayReleaseApi = (params) => {
  return defHttp.get({ url: Api.QueryGrayRelease, params })
}

/**
 * @description: 校验灰度信息: https://jmock.jiduauto.com/project/1717/interface/api/65967
 */
export const checkGrayReleaseApi = (params) => {
  return defHttp.post({ url: Api.CheckGrayRelease, params })
}

/**
 * @description: 执行灰度发布: https://jmock.jiduauto.com/project/1717/interface/api/65971
 */
export const publishGrayReleaseApi = (params) => {
  return defHttp.post({ url: Api.PublishGrayRelease, params })
}

/**
 * @description: 执行回滚发布: https://jmock.jiduauto.com/project/1717/interface/api/65979
 */
export const grayRollbackApi = (params) => {
  return defHttp.post({ url: Api.GrayRollback, params })
}

/**
 * @description: 执行全量发布: https://jmock.jiduauto.com/project/1717/interface/api/65975
 */
export const grayFullReleaseApi = (params) => {
  return defHttp.post({ url: Api.GrayFullRelease, params })
}

/* @description: 创建发布计划: https://jmock.jiduauto.com/project/1717/interface/api/65951
 */
export const createPlanApi = (params) => {
  return defHttp.post({ url: Api.CreatePlan, params })
}

/**
 * @description: 更新发布计划: https://jmock.jiduauto.com/project/1717/interface/api/65955
 */
export const updatePlanApi = (params) => {
  return defHttp.post({ url: Api.UpdatePlan, params })
}

/**
 * @description: 查询发布计划关联的场景-普通查询: https://jmock.jiduauto.com/project/1717/interface/api/65939
 */
export const queryBasalByPlanIdApi = (params) => {
  return defHttp.get({ url: Api.QueryBasalByPlanId, params })
}

/**
 * @description: 查询场景库-场景列表: https://jmock.jiduauto.com/project/1717/interface/api/74859
 */
export const querySceneListApi = (params) => {
  return defHttp.get({ url: Api.QuerySceneList, params })
}

/**
 * @description: 查询场景库-场景详情: https://jmock.jiduauto.com/project/1717/interface/api/74863
 */
export const querySceneDetailApi = (params) => {
  return defHttp.get({ url: `${Api.QuerySceneDetail}${params}` })
}

/**
 * @description: 查询场景库-上传校验文件: https://jmock.jiduauto.com/project/1717/interface/api/74867
 */
export const uploadCheckFileApi = () => {
  return `${VITE_GLOB_API_URL}${Api.UploadCheckFile}`
}

/**
 * @description: 查询场景库-上传场景文件及信息校验: https://jmock.jiduauto.com/project/1717/interface/api/74871
 */
export const uploadSceneFileApi = () => {
  return `${VITE_GLOB_API_URL}${Api.UploadSceneFile}`
}

/**
 * @description: 查询所有发布计划的名称和: https://jmock.jiduauto.com/project/1717/interface/api/95203
 */
export const getAllPlanBrief = (params) => {
  return defHttp.get({ url: Api.getAllPlanBrief, params })
}

/**
 * @description: 分页查询指令历史: https://jmock.jiduauto.com/project/1717/interface/api/95203
 */
export const pagingQueryCommandLog = (params) => {
  const { dateBegin, dateEnd } = params
  const diffDay = dayjs(dateEnd).diff(dateBegin, 'day')
  if (diffDay > 30) {
    message.error('范围不能超过30天')
    return
  }
  return defHttp.post({ url: Api.pagingQueryCommandLog, params })
}

/**
 * @description: 导出指定发布计划的场景 MD5: https://jmock.jiduauto.com/project/1717/interface/api/95355
 */
export const exportSceneMd5 = (params) => {
  return `${globSetting.apiUrl}${Api.exportSceneMd5}?planId=${params.planId}`
}

/**
 * @description: 上传场景MD5信息并与指定车型最新全量版本比较:https://jmock.jiduauto.com/project/1717/interface/api/95359
 */
export const queryAndCompare = () => {
  return `${VITE_GLOB_API_URL}${Api.queryAndCompare}`
}

/**
 * @description: 场景化服务配置后台接口:https://jmock.jiduauto.com/project/1717/interface/api/100187
 */
export const getReleasePlanStats = (params) => {
  return defHttp.get({ url: Api.getReleasePlanStats, params })
}

/**
 * @description: 同步发布计划:https://jmock.jiduauto.com/project/1717/interface/api/111263
 */
export const syncReleasePlanApi = (params) => {
  return defHttp.post(
    {
      url: Api.syncReleasePlan,
      params: params,
      headers: { 'Content-Type': ContentTypeEnum.FORM_DATA },
    },
    { isTransformResponse: false },
  )
}

/**
 * @description: 查询指定车型的所有交互配置:https://jmock.jiduauto.com/project/1717/interface/api/102555
 */
export const queryVehicleSceneList = (params) => {
  return defHttp.get({ url: Api.queryVehicleSceneList, params })
}

/**
 * @description: 上线发布交互配置:https://jmock.jiduauto.com/project/1717/interface/api/102563
 */
export const releaseVehicleScene = (params) => {
  return defHttp.post({ url: Api.releaseVehicleScene, params })
}

/**
 * @description: 查询交互配置详情:https://jmock.jiduauto.com/project/1717/interface/api/102571
 */
export const getVehicleScene = (params) => {
  return defHttp.get({ url: Api.getVehicleScene, params })
}
