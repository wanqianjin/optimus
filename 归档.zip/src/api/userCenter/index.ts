import { defHttp } from '/@/utils/http/axios'
// import { ContentTypeEnum } from '/@/enums/httpEnum'
// import axios from 'axios'

enum Api {
  // 用户列表
  registerCount = '/user-c-server/userc/basic/register/count',
  incrCount = '/user-c-server/userc/basic/incr/count',
  onlineCount = '/user-c-server/userc/basic/online/count',
  BasicUserList = '/user-c-server/userc/basic/userlist',
  batchByTemplate = '/user-c-server/userc/basic/userlist/batch/byTemplate',
  exportBatch = '/user-c-server/userc/basic/tel/export/batch',
  acquireBatch = '/user-c-server/userc/basic/tel/acquire/batch',
  acquireByUserId = '/user-c-server/userc/basic/tel/acquire/byUserId',
  downFileTemplateQueryBatch = '/user-c-server/userc/basic/user/downFileTemplateQueryBatch',
  parseByTemplate = '/user-c-server/userc/basic/userlist/parse/byTemplate',
  // 用户详情
  detailByUserId = '/user-c-server/userc/basic/user/detail/byUserId',
  unbildByUserId = '/user-c-server/userc/basic/sns/unbind/byUserId',
  offlineByUserId = '/user-c-server/userc/basic/offline/byUserId',
  modifyTelBind = '/user-c-server/userc/basic/tel/bind',
  reset = '/user-c-server/userc/basic/nick/reset',
  resetAvatar = '/user-c-server/userc/basic/avatar/reset',
  // 黑名单管理
  blacklistAcquire = '/user-c-server/userc/blacklist/acquire',
  blacklistAdd = '/user-c-server/userc/blacklist/add',
  blacklistDel = '/user-c-server/userc/blacklist/del',
  downFileTemplateBlackBatch = '/user-c-server/userc/blacklist/user/downFileTemplateBlackBatch',
  addBtachByTemplate = '/user-c-server/userc/blacklist/addBtach/byTemplate',
  parseBatchByTemplate = '/user-c-server/userc/blacklist/parseBatch/byTemplate',
  blacklistAddBatch = '/user-c-server/userc/blacklist/addBatch',
  // 虚拟账号管理
  virtualUserList = '/user-c-server/userc/virtual/userlist',
  virtualUserAdd = '/user-c-server/userc/virtual/user/add',
  virtualDel = '/user-c-server/userc/virtual/del',
  delValidate = '/user-c-server/userc/virtual/del/validate',
  telAndUserId = '/user-c-server/userc/basic/export/batch/telAndUserId',

  exportUserId = '/user-c-server/userc/basic/export/batch/telAndUserId',
  parseUserId = '/user-c-server/userc/basic/parse/batch/telAndUserId',
}

/**
 * @description: 重置昵称
 */
export const reset = (params = {}) => {
  return defHttp.post({ url: Api.reset, params })
}

/**
 * @description: 重置头像
 */
export const resetAvatar = (params = {}) => {
  return defHttp.post({ url: Api.resetAvatar, params })
}

/**
 * @description: 查询注册总用户数
 */
export const registerCountApi = (params = {}) => {
  return defHttp.get({ url: Api.registerCount, params })
}
/**
 * @description: 查询今日新增用户数
 */
export const incrCountApi = (params = {}) => {
  return defHttp.get({ url: Api.incrCount, params })
}
/**
 * @description: 查询登录在线用户数
 */
export const onlineCountApi = (params = {}) => {
  return defHttp.get({ url: Api.onlineCount, params })
}
/**
 * @description: 根据条件查询用户列表
 */
export const BasicUserListApi = (params = {}) => {
  return defHttp.post({ url: Api.BasicUserList, params })
}
/**
 * @description: 上传excel，批量查询用户信息
 */
export const batchByTemplateApi = (params = {}) => {
  return defHttp.post({ url: Api.batchByTemplate, params })
}
/**
 * @description: 批量导出uid和tel到excel
 */
export const exportBatchApi = (params = {}) => {
  return defHttp.post(
    {
      url: Api.exportBatch,
      params,
      responseType: 'blob',
    },
    { isTransformResponse: false },
  )
}
/**
 * @description: 批量获取uid和tel
 */
export const acquireBatchApi = (params = {}) => {
  return defHttp.post({ url: Api.acquireBatch, params })
}

/**
 * @description: 通过userId获取手机号
 */
export const acquireByUserIdApi = (params = {}) => {
  return defHttp.get({ url: Api.acquireByUserId, params })
}

/**
 * @description: 通过userId获取手机号
 */
export const downFileTemplateQueryBatchApi = (params = {}) => {
  return defHttp.get(
    {
      url: Api.downFileTemplateQueryBatch,
      params,
      responseType: 'blob',
    },
    { isTransformResponse: false },
  )
}

/**
 * @description: 上传解析批量搜索excel
 */
export const parseByTemplateApi = (params = {}) => {
  return defHttp.post({
    url: Api.parseByTemplate,
    params,
  })
}

/**
 * @description: 通过用户id查询用户详细信息
 */
export const detailByUserIdApi = (params = {}) => {
  return defHttp.get({ url: Api.detailByUserId, params })
}
/**
 * @description: 解除绑定三方账号
 */
export const unbildByUserId = (params = {}) => {
  return defHttp.post({ url: Api.unbildByUserId, params })
}

/**
 * @description: 解除绑定三方账号
 */
export const offlineByUserIdApi = (params = {}) => {
  return defHttp.post({ url: Api.offlineByUserId, params })
}
/**
 * @description: 修改手机号
 */
export const modifyTelBindApi = (params = {}) => {
  return defHttp.post({ url: Api.modifyTelBind, params })
}

/**
 * @description: 黑名单管理列表
 */
export const blacklistAcquireApi = (params = {}) => {
  return defHttp.get({ url: Api.blacklistAcquire, params })
}

/**
 * @description: 黑名单添加
 */
export const blacklistAddApi = (params = {}) => {
  return defHttp.post({ url: Api.blacklistAdd, params })
}
/**
 * @description: 黑名单删除
 */
export const blacklistDelApi = (params = {}) => {
  return defHttp.post({ url: Api.blacklistDel, params })
}

/**
 * @description: 下载批量黑名单模板
 */
export const downFileTemplateBlackBatchApi = (params = {}) => {
  return defHttp.get(
    { url: Api.downFileTemplateBlackBatch, params, responseType: 'blob' },
    { isTransformResponse: false },
  )
}
/**
 * @description: 批量添加黑名单
 */
// export const addBtachByTemplateApi = (params = {}) => {
//   const formData = new FormData()
//   formData.append('file', params.file)
//   formData.append('reason', params.reason)
//   return defHttp.post({
//     url: Api.addBtachByTemplate,
//     params: formData,
//     headers: { 'Content-Type': ContentTypeEnum.FORM_DATA },
//   })
// }

/**
 * @description: 批量解析黑名单excel
 */
export const parseBatchByTemplateApi = (params = {}) => {
  return defHttp.post({ url: Api.parseBatchByTemplate, params })
}

/**
 * @description: 执行批量添加黑名单动作
 */
export const blacklistAddBatchApi = (params = {}) => {
  return defHttp.post({ url: Api.blacklistAddBatch, params })
}

/**
 * @description: 查询虚拟用户列表
 */
export const virtualUserListApi = (params = {}) => {
  return defHttp.post({ url: Api.virtualUserList, params })
}

/**
 * @description: 使用虚拟手机号添加虚拟用户
 */
export const virtualUserAddApi = (params = {}) => {
  return defHttp.post({ url: Api.virtualUserAdd, params })
}

/**
 * @description: 删除虚拟用户
 */
export const virtualDelApi = (params = {}) => {
  return defHttp.post({ url: Api.virtualDel, params })
}

/**
 * @description: 删除虚拟用户前校验
 */
export const delValidateApi = (params = {}) => {
  return defHttp.post({ url: Api.delValidate, params })
}

// 解析数据
export const parseUserIdApi = (params = {}) => {
  return defHttp.post({ url: Api.parseUserId, params })
}

/**
 * @description: 导出数据
 */
// export const exportUserIdApi = (params = {}) => {
//   return defHttp.post({ url: Api.exportUserId, params, responseType: 'blob' })
// }

/**
 * @description: 导出数据
 */
export const exportUserIdApi = () => {
  return `/api${Api.exportUserId}`
}
