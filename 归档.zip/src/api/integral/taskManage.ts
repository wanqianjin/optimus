import { defHttp } from '/@/utils/http/axios'

enum Api {
  GetTaskList = '/user-task-backend/task/backend/taskList',
  UserDetailList = '/user-task-backend/taskDetail/recordPage',
  userLogPageList = '/user-task-backend/taskDetail/logPage',
  EventList = '/user-task-backend/task/backend/eventList',
  TaskDelete = '/user-task-backend/task/backend/delete',
  TaskStop = '/user-task-backend/task/backend/taskStop',
  TaskInfo = '/user-task-backend/task/backend/taskInfo',
  TemporaryStore = '/user-task-backend/task/backend/store',
  TaskSave = '/user-task-backend/task/backend/save',
  GetCdpGroups = '/user-task-backend/task/backend/cdpGroupList',
  CheckBlack = '/user-task-backend/blackList/check',
  SaveBlack = '/user-task-backend/blackList/save',
  GetBlack = '/user-task-backend/blackList/page',
  GetCost = '/channel/project/getProjectWithItemDetailById',
  GetProjectByName = '/channel/channel/queryPrivilegedProjectRelation',
  GetAchieveTypeList = '/user-ares-backend/ares/backend/achievement/list/all',
  GetTouchEvent = '/user-task-backend/task/backend/queryTaskConditionList',
  GetSceneList = '/user-task-backend/task/backend/getTaskSceneList',
}

/**
 * @description: 获取任务列表:https://jmock.jiduauto.com/project/1456/interface/api/48287
 */

export const getTaskListApi = (params) => {
  return defHttp.get({ url: Api.GetTaskList, params })
}

/**
 * @description: 用户明细: https://jmock.jiduauto.com/project/1456/interface/api/105279
 */
export const userDetailListApi = (params) => {
  return defHttp.get({ url: Api.UserDetailList, params })
}

/**
 * @description: 单个用户完成任务明细列表: https://jmock.jiduauto.com/project/1456/interface/api/105307
 */
export const userLogPageListApi = (params) => {
  return defHttp.get({ url: Api.userLogPageList, params })
}

export const checkBlackApi = (params) => {
  return defHttp.post({ url: Api.CheckBlack, params })
}

export const saveBlackApi = (params) => {
  return defHttp.post({ url: Api.SaveBlack, params })
}

export const getBlackApi = (params) => {
  return defHttp.get({ url: Api.GetBlack, params })
}
/**
 * @description: 获取事件枚举: https://jmock.jiduauto.com/project/1456/interface/api/48291
 */
export const eventListApi = (params) => {
  return defHttp.get({ url: Api.EventList, params })
}

/**
 * @description: 删除任务: https://jmock.jiduauto.com/project/1456/interface/api/48371
 */
export const taskDeleteApi = (params) => {
  return defHttp.post({ url: Api.TaskDelete, params })
}

/**
 * @description: 终止任务: https://jmock.jiduauto.com/project/1456/interface/api/48375
 */
export const taskStopApi = (params) => {
  return defHttp.post({ url: Api.TaskStop, params })
}

/**
 * @description: 任务详情信息: https://jmock.jiduauto.com/project/1456/interface/api/48295
 */
export const taskInfoApi = (params) => {
  return defHttp.get({ url: Api.TaskInfo, params })
}

/**
 * @description: 暂时存储: https://jmock.jiduauto.com/project/1456/interface/api/48391
 */
export const temporaryStoreApi = (params) => {
  return defHttp.post({ url: Api.TemporaryStore, params })
}

/**
 * @description: 保存任务: https://jmock.jiduauto.com/project/1456/interface/api/48331
 */
export const taskSaveApi = (params) => {
  return defHttp.post({ url: Api.TaskSave, params })
}

/**
 * @description: 获取CDP人群包列表: https://jmock.jiduauto.com/project/1456/interface/api/55599
 */
export const getCdpGroupsApi = (params) => {
  return defHttp.get({ url: Api.GetCdpGroups, params })
}

export const getCostByProjectApi = (params) => {
  return defHttp.get({ url: Api.GetCost, params })
}

export const getProjectByNameApi = (params) => {
  return defHttp.get({ url: Api.GetProjectByName, params })
}

/**
 * @description: 获取成就类型列表 https://jmock.jiduauto.com/project/607/interface/api/123639
 * @return {*}
 */
export const getAchieveTypeListApi = () => {
  return defHttp.post({ url: Api.GetAchieveTypeList })
}

export const getTouchEventApi = () => {
  return defHttp.get({ url: Api.GetTouchEvent })
}

export const getSceneListApi = () => {
  return defHttp.get({ url: Api.GetSceneList })
}
