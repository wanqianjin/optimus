import { defHttp } from '/@/utils/http/axios'
import { ContentTypeEnum } from '/@/enums/httpEnum'
enum Api {
  GetBatchGrantList = '/user-credits-backend/creditsBatchTask/info',
  UserDetailList = '/user-credits-backend/creditsBatchTask/userInfo',
  TaskStop = '/user-credits-backend/terminateBatchCreditTask',
  getBatchDetail = '/user-credits-backend/creditsBatch/get',
  checkRepeat = '/user-credits-backend/creditsBatchTask/checkRepeat',
  createWorkOrder = '/user-credits-backend/creditsBatchTask/createWorkOrder',
  getHumanUser = '/user-credits-backend/creditsBatchTask/humanUser',
  uploadFile = '/user-credits-backend/creditsBatchTask/uploadFile',
  GetIntegalBatch = '/user-credits-backend/creditsBatch/get',
  GetBatchGrantDetail = '/user-credits-backend/creditsBatchTask/detail',
  GetBelongCompany = '/user-credits-backend/creditsBatchTask/belongCompany',
}

/**
 * @description: 获取批量发放任务列表:https://jmock.jiduauto.com/project/56/interface/api/65515
 */

export const getBatchGrantListApi = (params) => {
  return defHttp.get({ url: Api.GetBatchGrantList, params })
}

/**
 * @description: 用户明细: https://jmock.jiduauto.com/project/56/interface/api/66031
 */
export const userDetailListApi = (params) => {
  return defHttp.get({ url: Api.UserDetailList, params })
}

/**
 * @description: 终止任务: https://jmock.jiduauto.com/project/56/interface/api/29703
 */
export const taskStopApi = (params) => {
  return defHttp.post({ url: Api.TaskStop, params })
}

/**
 * @description: 查询积分批次详情: https://jmock.jiduauto.com/project/56/interface/api/34427
 */
export const getBatchDetailApi = (params) => {
  return defHttp.get({ url: Api.getBatchDetail, params })
}

/**
 * @description: 查询防重校验: https://jmock.jiduauto.com/project/56/interface/api/66043
 */
export const getCheckRepeatApi = (params) => {
  return defHttp.get({ url: Api.checkRepeat, params })
}
/**
 * @description: 提交批量申请工单: https://jmock.jiduauto.com/project/56/interface/api/65507
 */
export const CreateWorkOrderApi = (params, isTransformResponse = true) => {
  return defHttp.post(
    { url: Api.createWorkOrder, params },
    { isTransformResponse: isTransformResponse },
  )
}
/**
 * @description: 获取人力列表: https://jmock.jiduauto.com/project/56/interface/api/65507
 */
export const GetHumanUserApi = (params) => {
  return defHttp.get({ url: Api.getHumanUser, params })
}
/**
 * @description: 获取人力列表: https://jmock.jiduauto.com/project/56/interface/api/65507
 */
export const GetIntegalBatchApi = (params) => {
  return defHttp.get({ url: Api.GetIntegalBatch, params })
}
/**
 * @description: 上传文件: https://jmock.jiduauto.com/project/56/interface/api/65507
 */
export const UploadFileApi = (params) => {
  return defHttp.post(
    {
      url: Api.uploadFile,
      params,
      timeout: 60 * 1000,
      headers: { 'Content-Type': ContentTypeEnum.FORM_DATA },
    },
    {
      errorMessageMode: 'none',
    },
  )
}

/**
 * @description: 获取任务详情:
 */
export const GetBatchGrantDetailApi = (params) => {
  return defHttp.get({ url: Api.GetBatchGrantDetail, params })
}
/**
 * @description: 获取所属公司:
 */
export const GetBelongCompanyApi = (params) => {
  return defHttp.get({ url: Api.GetBelongCompany, params })
}
