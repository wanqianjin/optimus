import { defHttp } from '/@/utils/http/axios'

enum Api {
  QueryIntegralDetail = '/credits/operate/creditRecords',
  QuerytaskList = '/credits/operate/taskList',
  QuerytaskDetail = '/credits/operate/task',
  EditTask = '/credits/operate/editTask',
  QueryCredits = '/credits/operate/singleUserCredit',
  ModifyCredit = '/credits/operate/modifyUserCredit',
  BatchCredit = '/credits/operate/batchCredit',
  queryIssuanceRecord = '/user-credits-backend/creditsBatch/page/issuance/record',
  appendBatch = '/user-credits-backend/creditsBatch/append',
  // 批次管理
  CreateBatch = '/credits/operate/batchId/create',
  CreateBatchScore = '/user-credits-backend/creditsBatch/create',
  UpdateBatchScore = '/user-credits-backend/creditsBatch/update',

  QueryBatchList = '/user-credits-backend/creditsBatch/page/V2',
  GetFullGroupTree = '/user-credits-backend/creditsBatch/getFullGroupTree',
  QueryOrganizationList = '/credits/operate/batchId/organization/byLevel',
  QueryOrganizationChildrenList = '/credits/operate/batchId/organization/byParentId',
  QueryBatchGrantRecord = '/user-credits-backend/creditsRecord/page',
  QueryBatchInfo = '/user-credits-backend/creditsBatch/get',

  QueryProject = '/channel/channel/queryProjectRelationByLevel',
  TerminateBatchCreditTask = '/user-credits-backend/terminateBatchCreditTask',
  TaskCanTerminate = '/user-credits-backend/taskCanTerminate',

  // 获取结算单列表
  getSettlementList = '/user-credits-backend/merchantCredits/settle/getSettlementList',
  settlementAudit = '/user-credits-backend/merchantCredits/settle/settlementAudit',
  settlementPayment = '/user-credits-backend/merchantCredits/settle/settlementPayment',
  exportOrdersBySettlementId = '/user-credits-backend/merchantCredits/settle/exportOrdersBySettlementId',

  // 标签管理标签树
  getLabelTree = '/channel/label/query/tree',
  getLabelTreeNoAuth = '/channel/label/query/tree/noAuth',
  getLabelDetail = '/channel/channel/label/query/forSubjectId',
  // 积分批次打标
  relativeLabel = '/user-credits-backend/creditsBatch/relative/label',

  // 扣减场景
  getSceneRefundList = '/credits/operate/staff/leave/remark',
  setRefund = '/credits/operate/staff/leave',
}

/**
 * @description: 获取积分详情
 */
export const queryIntegralDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryIntegralDetail, params })
}

/**
 * @description: 获取任务列表
 */
export const querytaskListApi = (params) => {
  return defHttp.get({ url: Api.QuerytaskList, params })
}

/**
 * @description: 查询单个用户积分信息
 */
export async function queryCreditsApi(params) {
  return defHttp.get({ url: Api.QueryCredits, params })
}

/**
 * @description: 查询单个用户积分信息
 */
export async function modifyCreditApi(params) {
  return defHttp.post({ url: Api.ModifyCredit, params })
}
/**
 * @description: 获取任务详情
 */
export async function querytaskDetailApi(params) {
  return defHttp.get({ url: Api.QuerytaskDetail, params })
}
/**
 * @description: 编辑任务
 */
export async function editTaskApi(params) {
  return defHttp.post({ url: Api.EditTask, params })
}
/**
 * @description: 编辑任务
 */
export async function BatchCredit(params) {
  return defHttp.post({ url: Api.BatchCredit, params })
}

export async function queryIssuanceRecord(params) {
  return defHttp.post({ url: Api.queryIssuanceRecord, params })
}

export async function appendBatch(params) {
  return defHttp.post({ url: Api.appendBatch, params })
}

// 批次管理
/**
 * @description: 查询批次号列表
 */
export async function queryBatchList(params) {
  return defHttp.post({
    url: Api.QueryBatchList,
    params,
  })
}
/**
 * @description: 创建批次号
 */
export async function createBatch(params) {
  return defHttp.post({ url: Api.CreateBatch, params })
}

/**
 * @description: 查询部门级联树：https://jmock.jiduauto.com/project/56/interface/api/35615
 */
export async function getFullGroupTreeApi(params) {
  return defHttp.get({ url: Api.GetFullGroupTree, params })
}
/**
 * @description: 查询部门信息
 */
export async function queryOrganizationList(params) {
  return defHttp.get({ url: Api.QueryOrganizationList, params })
}
/**
 * @description: 查询二级部门信息
 */
export async function queryOrganizationChildrenList(params) {
  return defHttp.get({ url: Api.QueryOrganizationChildrenList, params })
}

/**
 * @description: 根据批次ID查询批次发放记录
 */
export async function queryBatchGrantRecord(params) {
  return defHttp.post({ url: Api.QueryBatchGrantRecord, params })
}

export async function createScoreBatch(params) {
  return defHttp.post({ url: Api.CreateBatchScore, params })
}

export async function updateScoreBatch(params) {
  return defHttp.post({ url: Api.UpdateBatchScore, params })
}

/**
 * @description: 根据批次ID查询批次详情
 */
export async function queryBatchInfo(params) {
  return defHttp.get({ url: Api.QueryBatchInfo, params })
}

/**
 * @description: 终止批次任务
 */
export async function terminateBatchCreditTaskApi(params) {
  return defHttp.post({ url: Api.TerminateBatchCreditTask, params })
}

/**
 * @description: 查询批次任务是否已停止
 */
export async function taskCanTerminateApi(params) {
  return defHttp.get({ url: Api.TaskCanTerminate, params }, { isTransformResponse: false })
}

/**
 * @description: 获取结算单列表
 */
export async function getSettlementList(params) {
  return defHttp.get({ url: Api.getSettlementList, params })
}

/**
 * @description: 结算单审核
 */
export async function settlementAudit(params) {
  return defHttp.post({ url: Api.settlementAudit, params })
}

/**
 * @description: 结算单打款
 */
export async function settlementPayment(params) {
  return defHttp.post({ url: Api.settlementPayment, params })
}

/**
 * @description: 结算单导出
 */
export async function exportOrdersBySettlementId(params) {
  return defHttp.get(
    { url: Api.exportOrdersBySettlementId, params, responseType: 'blob' },
    { isTransformResponse: false },
  )
}

export async function queryProjectTree(params) {
  return defHttp.get({ url: Api.QueryProject, params })
}
// 获取标签树
export async function getLabelTreeApi(params) {
  return defHttp.get({ url: Api.getLabelTree, params })
}
// 积分批次打标
export async function relativeLabelApi(params) {
  return defHttp.post({ url: Api.relativeLabel, params })
}

// 获取标签树 (无权限控制) 列表筛选条件使用
export async function getLabelTreeNoAuthApi(params) {
  return defHttp.get({ url: Api.getLabelTreeNoAuth, params })
}

export async function getSceneRefundList() {
  return defHttp.get({ url: Api.getSceneRefundList })
}

export async function setRefundApi(params) {
  return defHttp.post({ url: Api.setRefund, params })
}
