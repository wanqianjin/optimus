import { message } from '@jidu/robot-ui'

const jsonRectify = (jsonStr) => {
  let res = {}
  try {
    res = JSON.parse(
      jsonStr.replace(/\n/g, '\\n').replace(/\t/g, '\\t').replace(/\r/g, '\\r'),
      // .replace(/\\/g, '\\\\'),
    )
  } catch (error) {
    message.error('json解析失败')
  }
  return res
}

/* 
  纯map结构转成数组结构
 */
const map2Array = (configValue, isArray = false) => {
  const res: Array<any> = []
  Object.entries(configValue).forEach(([name, val]: Array<any>) => {
    res.push({
      key: isArray ? null : name,
      type: val.type,
      value:
        val.type === 'array' || val.type === 'object'
          ? map2Array(val.value, val.type === 'array')
          : val.value,
      comment: val.description,
    })
  })
  return res
}

/* 
  数组结构转纯map结构
 */
const array2Map = (configValue, isArray = false) => {
  const map = {}
  for (let i = 0; i < configValue.length; i++) {
    const val = configValue[i]
    map[isArray ? i : val.key] = {
      type: val.type,
      description: val.comment,
      value:
        val.type === 'array' || val.type === 'object'
          ? array2Map(val.value, val.type === 'array')
          : val.value,
    }
  }
  return map
}

export const transDetail = (res) => {
  const initVal = {
    key: 'root',
    type: 'object',
    value: [],
    comment: '',
  }
  res.oldValue = res.configValue
    ? map2Array(
        jsonRectify(res.configValue),
        // decodeURIComponent(JSON.parse(decodeURIComponent(res.draftConfigValue))),
      )
    : [initVal]
  res.value = res.draftConfigValue
    ? map2Array(
        jsonRectify(res.draftConfigValue),
        // decodeURIComponent(JSON.parse(decodeURIComponent(res.draftConfigValue))),
      )
    : [initVal]
  Reflect.deleteProperty(res, 'configValue')
  Reflect.deleteProperty(res, 'draftConfigValue')
  return res
}

export const transSave = (res) => {
  const tranVal = array2Map(res.configValue)
  res.configValue = JSON.stringify(tranVal)
  return res
}
