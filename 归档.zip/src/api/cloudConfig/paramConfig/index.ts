import { defHttp } from '/@/utils/http/axios'
import * as model from './model'
import * as trans from './trans'
import { useGlobSetting } from '/@/hooks/setting'
const globSetting = useGlobSetting() //获取全局变量

export enum ApiPath {
  createConfig = '/b/content-backend/backend/createConfig/new',
  queryConfigList = '/b/content-backend/backend/queryConfigList/new',
  queryConfigDetail = '/b/content-backend/backend/queryConfigDetail/new',
  saveConfig = '/b/content-backend/backend/saveConfig/new',
  publishConfig = '/b/content-backend/backend/publishConfig/new',
  uploadConfigFile = '/b/content-backend/backend/uploadConfigFile/new',
  downloadConfigFile = '/b/content-backend/backend/downloadConfigFile',
  queryGroupList = '/b/content-backend/backend/queryGroupList/new',
}

/**
 * @description: 创建配置
 */
export const createConfig = (params: model.ConfigAdd) => {
  return defHttp.post({ url: ApiPath.createConfig, params })
}

/**
 * @description: 查询配置列表
 */
export const queryConfigList = async (params: { keyId: number }) => {
  const res = await defHttp.get<model.ConfigList>({ url: ApiPath.queryConfigList, params })
  return res.configList
}

/**
 * @description:查询配置详情
 */
export const queryConfigDetail = async (params: { configId: number }) => {
  const res: model.ConfigDetail = await defHttp.get({ url: ApiPath.queryConfigDetail, params })
  return trans.transDetail(res)
}

/**
 * @description: 保存配置
 */
export const saveConfig = (params: model.ConfigSave) => {
  const transParam = trans.transSave(params)
  return defHttp.post({ url: ApiPath.saveConfig, params: transParam })
}

/**
 * @description: 发布配置
 */
export const publishConfig = (params: model.ConfigPublish) => {
  const transParam = trans.transSave(params)
  return defHttp.post({ url: ApiPath.publishConfig, params: transParam })
}

/**
 * @description: 配置文件上传接口
 */
export const uploadConfigFile = () => {
  return `${globSetting.apiUrl}${ApiPath.uploadConfigFile}` //globSetting.apiUrl  获取全局域名
}

/**
 * @description: 配置文件下载接口
 */
export const downloadConfigFile = (configId) => {
  return `${globSetting.apiUrl}${ApiPath.downloadConfigFile}?configId=${configId}` //globSetting.apiUrl  获取全局域名
}

/**
 * @description: 查询配置列表
 */
export const queryGroupList = async (params = {}) => {
  const res = await defHttp.get<model.ConfigList>({ url: ApiPath.queryGroupList, params })
  return res
}
