export interface ConfigAdd {
  name: string
  valueType: number
  description: string
}

export interface ConfigList {
  configList: ConfigItem[]
  count: number
}

export interface ConfigItem {
  configId: string
  keyName: string
  valueType: number
  draftAppVersion: string
  status: number
  operator: string
  updateTime: string
  description: string
}

export interface ConfigDetail {
  keyName: string
  description: string
  configValue: {
    [key: string]: {
      name: string
      type: string
      value: any
      description: string
    }
  }
  draftConfigValue: {
    [key: string]: {
      name: string
      type: string
      value: any
      description: string
    }
  }
  draftConfigVersion: number
  configVersion: number
  draftAppVersion: string
  appVersion: string
}

export interface ConfigSave {
  configId: string
  name: string
  description: string
  appVersion: string
  configValue: string
  draftConfigVersion: number
  keyId: string
}
export interface ConfigPublish {
  configId: string
  appVersion: string
  configValue: string
  draftConfigVersion: number
  keyId: string
  configVersion: string
}
