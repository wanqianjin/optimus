export interface ServiceConfList {
  keyConfigureList: ServiceConfItem[]
  totalCount: number
}
export interface ServiceConfItem {
  [ServiceConfItemKeys.keyId]: string
  [ServiceConfItemKeys.keyName]: string
  [ServiceConfItemKeys.description]: string
  [ServiceConfItemKeys.serviceType]: number
  [ServiceConfItemKeys.operator]: string
  [ServiceConfItemKeys.updateTime]: string
}

export enum ServiceConfItemKeys {
  keyId = 'keyId',
  keyName = 'keyName',
  description = 'description',
  serviceType = 'serviceType',
  operator = 'operator',
  updateTime = 'updateTime',
}

export interface ServiceConfAdd {
  keyName: string
  description: string
  serviceType: number | null
}

export interface ServiceConfUpdate extends ServiceConfAdd {
  keyId: string
}
