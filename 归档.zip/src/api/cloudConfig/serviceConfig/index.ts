import { defHttp } from '/@/utils/http/axios'
import * as model from './model'

export enum ApiPath {
  createServiceConfigure = '/b/content-backend/backend/createKeyConfig/new',
  queryServiceConfigure = '/b/content-backend/backend/queryKeyConfigList/new',
  updateServiceConfigure = '/b/content-backend/backend/updateKeyConfig/new',
  queryServiceConfigureDetail = '/b/content-backend/backend/queryKeyConfigDetail/new',
  getDomainOptions = '/b/content-backend/backend/query/config/serviceTypeList',
}

/**
 * @description: 创建服务配置
 */
export const createServiceConfigure = (params: model.ServiceConfAdd) => {
  return defHttp.post({ url: ApiPath.createServiceConfigure, params })
}

/**
 * @description: 查询服务配置
 */
export const queryServiceConfigure = async (params) => {
  const res = await defHttp.post<model.ServiceConfList>({
    url: ApiPath.queryServiceConfigure,
    params,
  })
  return { list: res.keyConfigureList, count: res.totalCount }
}

/**
 * @description: 查询服务配置详情
 */
export const queryServiceConfigureDetail = (params) => {
  return defHttp.post<{ keyConfigure: model.ServiceConfUpdate }>({
    url: ApiPath.queryServiceConfigureDetail,
    params,
  })
}

/**
 * @description: 更新服务配置
 */
export const updateServiceConfigure = (params: model.ServiceConfUpdate) => {
  return defHttp.post({ url: ApiPath.updateServiceConfigure, params })
}

/**
 * @description: 域控枚举
 */
export const getDomainOptions = (params) => {
  return defHttp.get({ url: ApiPath.getDomainOptions, params })
}
