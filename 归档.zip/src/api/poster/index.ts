import { defHttp } from '/@/utils/http/axios'

// https://jmock.jiduauto.com/project/146/interface/api/cat_18597 海报接口文档
enum Api {
  posterCreate = '/b/content-backend/backend/poster/meta/create',
  posterUpdate = '/b/content-backend/backend/poster/meta/update',
  posterDetail = '/b/content-backend/backend/poster/meta/detail',
  posterImageView = '/b/content-backend/backend/poster/meta/view',
  posterCopy = '/b/content-backend/backend/poster/meta/copy',
  posterConfig = '/b/content-backend/backend/poster/meta/config/list',
  posterTemplate = '/b/content-backend/backend/poster/meta/template/list',
  posterList = '/b/content-backend/backend/poster/meta/list',
  PosterStatus = '/b/content-backend/backend/poster/meta/onlinestatus',
  submitAudit = '/b/content-backend/backend/poster/meta/submitAudit',
  withDrawAudit = '/b/content-backend/backend/poster/meta/withDrawAudit',
  queryCDPTagList = '/b/content-backend/backend/queryPosterCDPTagList',
  getContentTypeList = '/b/content-backend/backend/poster/contentType/list',
  deletePoster = '/b/content-backend/backend/poster/meta/delete',
  batchSubmitAudit = '/b/content-backend/backend/poster/meta/batchSubmitAudit',
  posterSort = '/b/content-backend/backend/poster/meta/sort',
  batchCreate = '/b/content-backend/backend/poster/meta/batchCreate',

  // 海报模版
  templateList = '/b/content-backend/backend/poster/template/list',
  createTemplate = '/b/content-backend/backend/poster/template/create',
  updateTemplate = '/b/content-backend/backend/poster/template/update',
  onlinestatus = '/b/content-backend/backend/poster/template/onlinestatus',
  templateDetail = '/b/content-backend/backend/poster/template/detail',
  basedata = '/b/content-backend/backend/poster/template/basedata',

  // 海报业务线
  getUseBizList = '/b/content-backend/backend/poster/biz/list',
  createUseBiz = '/b/content-backend/backend/poster/biz/create',
  updateUseBiz = '/b/content-backend/backend/poster/biz/update',
  deleteUseBiz = '/b/content-backend/backend/poster/biz/delete',

  // 海报内容分类
  getContentTypeDataList = '/b/content-backend/backend/poster/content/type/list',
  createContentType = '/b/content-backend/backend/poster/content/type/create',
  updateContentType = '/b/content-backend/backend/poster/content/type/update',
  deleteContentType = '/b/content-backend/backend/poster/content/type/delete',

  // 数据源管理
  getDataSourceList = '/b/content-backend/backend/poster/dataSource/item/list',
  createDataSource = '/b/content-backend/backend/poster/dataSource/item/create',
  updateDataSource = '/b/content-backend/backend/poster/dataSource/item/update',
  deleteDataSource = '/b/content-backend/backend/poster/dataSource/item/delete',
  detailDataSource = '/b/content-backend/backend/poster/dataSource/item/detail',
  getDataSourceTypeEnum = '/b/content-backend/backend/poster/dataSource/item/type/list',

  // 数据源组管理
  getDataSourceGroupList = '/b/content-backend/backend/poster/dataSource/group/list',
  createDataSourceGroup = '/b/content-backend/backend/poster/dataSource/group/create',
  updateDataSourceGroup = '/b/content-backend/backend/poster/dataSource/group/update',
  deleteDataSourceGroup = '/b/content-backend/backend/poster/dataSource/group/delete',
  detailDataSourceGroup = '/b/content-backend/backend/poster/dataSource/group/detail',
  searchDataSourceGroup = '/b/content-backend/backend/poster/dataSource/relative/search',
  setDataSourceGroupStatus = '/b/content-backend/backend/poster/dataSource/group/onlineStatus',
  getOtherenv = '/b/content-backend/backend/poster/dataSource/get/otherenv',
  syncOtherenv = '/b/content-backend/backend/poster/dataSource/sync/otherenv',

  // 映射管理
  getMappingList = '/b/content-backend/backend/poster/dataSource/mapping/list',
  createMapping = '/b/content-backend/backend/poster/dataSource/mapping/create',
  updateMapping = '/b/content-backend/backend/poster/dataSource/mapping/update',
  deleteMapping = '/b/content-backend/backend/poster/dataSource/mapping/delete',
  detailMapping = '/b/content-backend/backend/poster/dataSource/mapping/detail',
  getRelativeData = '/b/content-backend/backend/poster/dataSource/mapping/relativeData',
  mappingPreview = '/b/content-backend/backend/poster/dataSource/mapping/preview',

  // 快捷海报管理
  getScenePosterList = '/b/content-backend/backend/poster/scene/list',
  createScenePoster = '/b/content-backend/backend/poster/scene/create',
  updateScenePoster = '/b/content-backend/backend/poster/scene/update',
  detailScenePoster = '/b/content-backend/backend/poster/scene/detail',
  sceneTemplateList = '/b/content-backend/backend/poster/scene/template/list',
  mappingRelativeData = '/b/content-backend/backend/poster/scene/mapping/relativeData',
  getScenePosterBasedata = '/b/content-backend/backend/poster/scene/basedata',
  previewScenePoster = '/b/content-backend/backend/poster/scene/preview',
}

// 海报列表获取
export const queryPosterList = (params) => {
  return new Promise((resolve) => {
    defHttp.post({ url: Api.posterList, params }).then((res) => {
      resolve({
        count: res.total,
        list: res.list,
      })
    })
  })
}

// 海报上下架
export const setPosterStatus = (params) => {
  return defHttp.post({ url: Api.PosterStatus, params })
}

// 海报数据创建
export const posterCreate = (params) => {
  return defHttp.post({ url: Api.posterCreate, params })
}

// 海报数据更新
export const posterUpdate = (params) => {
  return defHttp.post({ url: Api.posterUpdate, params })
}

// 海报数据详情
export const posterDetail = (params) => {
  return defHttp.get({ url: Api.posterDetail, params })
}

// 海报图片展示（预览和下载
export const posterImageView = (params) => {
  return defHttp.post({ url: Api.posterImageView, params })
}

// 海报复制
export const posterCopy = (params) => {
  return defHttp.post({ url: Api.posterCopy, params })
}

// 海报数据配置list
export const posterConfig = (params) => {
  return defHttp.get({ url: Api.posterConfig, params })
}

// 海报数据模板列表
export const posterTemplate = (params) => {
  return defHttp.get({ url: Api.posterTemplate, params })
}

// 提交审核
export const submitAudit = (params) => {
  return defHttp.post({ url: Api.submitAudit, params })
}

// 撤销审核
export const withDrawAudit = (params) => {
  return defHttp.post({ url: Api.withDrawAudit, params })
}

// cdp标签列表
export const queryCDPTagList = (params) => {
  return defHttp.get({ url: Api.queryCDPTagList, params })
}

// 海报内容分类列表
export const getContentTypeList = (params) => {
  return defHttp.get({ url: Api.getContentTypeList, params })
}

// 获取海报模版列表
export const templateList = (params) => {
  return new Promise((resolve) => {
    defHttp.post({ url: Api.templateList, params }).then((res) => {
      resolve({
        count: res.total,
        list: res.list,
      })
    })
  })
}

// 创建海报模版
export const createTemplate = (params) => {
  return defHttp.post({ url: Api.createTemplate, params })
}

// 更新海报模版
export const updateTemplate = (params) => {
  return defHttp.post({ url: Api.updateTemplate, params })
}

// 更新海报模版状态
export const updateTemplateStatus = (params) => {
  return defHttp.post({ url: Api.onlinestatus, params })
}

// 海报模版详情
export const templateDetail = (params) => {
  return defHttp.get({ url: Api.templateDetail, params })
}

// 获取海报模版基础数据
export const basedata = (params) => {
  return defHttp.get({ url: Api.basedata, params })
}

// 海报模板-从其他环境获取海报模版
export const getOtherenv = (params) => {
  return defHttp.get({ url: Api.getOtherenv, params })
}

// 海报模板同步到其他环境
export const syncOtherenv = (params) => {
  return defHttp.post({ url: Api.syncOtherenv, params })
}

// 业务线列表
export const getUseBizList = (params) => {
  return new Promise((resolve) => {
    defHttp.post({ url: Api.getUseBizList, params }).then((res) => {
      resolve({
        count: res.total,
        list: res.list,
      })
    })
  })
}

// 业务线创建
export const createUseBiz = (params) => {
  return defHttp.post({ url: Api.createUseBiz, params })
}

// 业务线更新
export const updateUseBiz = (params) => {
  return defHttp.post({ url: Api.updateUseBiz, params })
}

// 业务线删除
export const deleteUseBiz = (params) => {
  return defHttp.post({ url: Api.deleteUseBiz, params })
}

// 删除海报
export const deletePoster = (params) => {
  return defHttp.post({ url: Api.deletePoster, params })
}

// 海报数据批量提交审核
export const batchSubmitAudit = (params) => {
  return defHttp.post({ url: Api.batchSubmitAudit, params })
}

// 海报数据排序
export const posterSort = (params) => {
  return defHttp.post({ url: Api.posterSort, params })
}

// 海报数据批量创建
export const batchCreate = (params) => {
  return defHttp.post({ url: Api.batchCreate, params })
}

// 内容分类列表
export const getContentTypeDataList = (params) => {
  return new Promise((resolve) => {
    defHttp.post({ url: Api.getContentTypeDataList, params }).then((res) => {
      resolve({
        count: res.total,
        list: res.list,
      })
    })
  })
}

// 内容分类创建
export const createContentType = (params) => {
  return defHttp.post({ url: Api.createContentType, params })
}

// 内容分类更新
export const updateContentType = (params) => {
  return defHttp.post({ url: Api.updateContentType, params })
}

// 内容分类删除
export const deleteContentType = (params) => {
  return defHttp.post({ url: Api.deleteContentType, params })
}

// 数据源列表
export const getDataSourceList = (params) => {
  return new Promise((resolve) => {
    defHttp.post({ url: Api.getDataSourceList, params }).then((res) => {
      resolve({
        count: res.total,
        list: res.list,
      })
    })
  })
}

// 数据源新增
export const createDataSource = (params) => {
  return defHttp.post({ url: Api.createDataSource, params })
}

// 数据源更新
export const updateDataSource = (params) => {
  return defHttp.post({ url: Api.updateDataSource, params })
}

// 数据源删除
export const deleteDataSource = (params) => {
  return defHttp.post({ url: Api.deleteDataSource, params })
}

// 数据源详情
export const detailDataSource = (params) => {
  return defHttp.get({ url: Api.detailDataSource, params })
}

// 海报数据源枚举列表
export const getDataSourceTypeEnum = (params) => {
  return defHttp.get({ url: Api.getDataSourceTypeEnum, params })
}

// 数据源组列表
export const getDataSourceGroupList = (params) => {
  return new Promise((resolve) => {
    defHttp.post({ url: Api.getDataSourceGroupList, params }).then((res) => {
      resolve({
        count: res.total,
        list: res.list,
      })
    })
  })
}

// 数据源组新增
export const createDataSourceGroup = (params) => {
  return defHttp.post({ url: Api.createDataSourceGroup, params })
}

// 数据源组更新
export const updateDataSourceGroup = (params) => {
  return defHttp.post({ url: Api.updateDataSourceGroup, params })
}

// 数据源组删除
export const deleteDataSourceGroup = (params) => {
  return defHttp.post({ url: Api.deleteDataSourceGroup, params })
}

// 数据源组详情
export const detailDataSourceGroup = (params) => {
  return defHttp.get({ url: Api.detailDataSourceGroup, params })
}

// 搜索数据源组
export const searchDataSourceGroup = (params) => {
  return defHttp.post({ url: Api.searchDataSourceGroup, params })
}

// 数据源组状态设置
export const setDataSourceGroupStatus = (params) => {
  return defHttp.post({ url: Api.setDataSourceGroupStatus, params })
}

// 映射列表
export const getMappingList = (params) => {
  return new Promise((resolve) => {
    defHttp.post({ url: Api.getMappingList, params }).then((res) => {
      resolve({
        count: res.total,
        list: res.list,
      })
    })
  })
}

// 映射创建
export const createMapping = (params) => {
  return defHttp.post({ url: Api.createMapping, params })
}

// 映射更新
export const updateMapping = (params) => {
  return defHttp.post({ url: Api.updateMapping, params })
}

// 映射删除
export const deleteMapping = (params) => {
  return defHttp.post({ url: Api.deleteMapping, params })
}

// 映射详情
export const detailMapping = (params) => {
  return defHttp.get({ url: Api.detailMapping, params })
}

// 获取相关数据
export const getRelativeData = (params) => {
  return defHttp.post({ url: Api.getRelativeData, params })
}

//映射预览
export const mappingPreview = (params) => {
  return defHttp.post({ url: Api.mappingPreview, params })
}

// 快捷海报列表
export const getScenePosterList = (params) => {
  return new Promise((resolve) => {
    defHttp.post({ url: Api.getScenePosterList, params }).then((res) => {
      resolve({
        count: res.total,
        list: res.list,
      })
    })
  })
}

// 快捷海报详情
export const detailScenePoster = (params) => {
  return defHttp.get({ url: Api.detailScenePoster, params })
}

// 快捷海报创建
export const createScenePoster = (params) => {
  return defHttp.post({ url: Api.createScenePoster, params })
}

// 快捷海报更新
export const updateScenePoster = (params) => {
  return defHttp.post({ url: Api.updateScenePoster, params })
}

// 获取海报模版列表
export const sceneTemplateList = (params) => {
  // return [
  //   {
  //     templateId: 'templateId1',
  //     templateName: 'templateName1',
  //     uiUrl: 'https://static.jiduapp.cn/common/logo.png',
  //   },
  //   {
  //     templateId: 'templateId2',
  //     templateName: 'templateName2',
  //     uiUrl: 'https://static.jiduapp.cn/optimus/user-upload/751f6ec8c1.png',
  //   },
  // ]
  return defHttp.get({ url: Api.sceneTemplateList, params })
}

// 根据模版id获取需要配置元素列表
export const mappingRelativeData = (params) => {
  return defHttp.post({ url: Api.mappingRelativeData, params })
}

// 获取快捷海报基础数据
export const getScenePosterBasedata = (params) => {
  return defHttp.get({ url: Api.getScenePosterBasedata, params })
}

// 快捷海报预览
export const previewScenePoster = (params) => {
  return defHttp.post({ url: Api.previewScenePoster, params })
}
