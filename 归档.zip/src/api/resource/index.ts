import { defHttp } from '/@/utils/http/axios'

enum Api {
  GetResourcePositionList = '/b/content-backend/resourcePosition/backend/getResourcePositionList',
  CreateResourcePosition = '/b/content-backend/resourcePosition/backend/createResourcePosition',
  UpdateResourcePosition = '/b/content-backend/resourcePosition/backend/updateResourcePosition',
  DeleteResourcePosition = '/b/content-backend/resourcePosition/backend/deleteResourcePosition',
  GetResourcePositionDetail = '/b/content-backend/resourcePosition/backend/getResourcePositionDetail',
  GetEnums = '/b/content-backend/resourcePosition/backend/getEnums',
  UpdateUnifyKey = '/b/content-backend/resourcePosition/backend/updateUnifyKey',

  GetOmContentList = '/b/content-backend/omContent/backend/getOmContentList',
  OnlineOrOfflineOmContent = '/b/content-backend/omContent/backend/onlineOrOfflineOmContent',
  UpdateOmContentOrderNumber = '/b/content-backend/omContent/backend/updateOmContentOrderNumber',
  GetOmContentDetail = '/b/content-backend/omContent/backend/getOmContentDetail',
  UpdateOmContent = '/b/content-backend/omContent/backend/updateOmContent',
  CreateOmContent = '/b/content-backend/omContent/backend/createOmContent',
  DeleteOmContent = '/b/content-backend/omContent/backend/deleteOmContent',
  GetResourcePositionForOmContent = '/b/content-backend/resourcePosition/backend/getResourcePositionForOmContent',

  GetVersionChannelList = '/b/content-backend/clientManager/getChannelList',
  GetUserLabelList = '/b/content-backend/omContent/backend/getUserLabelList',
  GetChannelEventSearch = '/channel/event/search',
  GetSearchChannelInfos = '/channel/getSearchChannelInfos',
}

/**
 * @description: 新增资源位
 */
export const createResourcePositionApi = (params) => {
  return defHttp.post({ url: Api.CreateResourcePosition, params })
}
/**
 * @description: 获取资源位列表
 */
export const getResourcePositionListApi = (params) => {
  return defHttp.get({ url: Api.GetResourcePositionList, params })
}

/**
 * @description:  删除资源位列表
 */
export const deleteResourcePositiontApi = (params) => {
  return defHttp.post({ url: Api.DeleteResourcePosition, params })
}

/**
 * @description:  获取资源位详情信息
 */
export const getResourcePositionDetailApi = (params) => {
  return defHttp.get({ url: Api.GetResourcePositionDetail, params })
}
/**
 * @description:  更新资源位
 */
export const updateResourcePositionApi = (params) => {
  return defHttp.post({ url: Api.UpdateResourcePosition, params })
}
/**
 * @description:  获取资源位枚举信息
 */
export const getEnumsApi = (params) => {
  return defHttp.get({ url: Api.GetEnums, params })
}

/**
 * @description: 投放内容列表
 */
export const getOmContentListApi = (params) => {
  return defHttp.get({ url: Api.GetOmContentList, params })
}
/**
 * @description: 上下架投放内容
 */
export const onlineOrOfflineOmContentApi = (params) => {
  return defHttp.post({ url: Api.OnlineOrOfflineOmContent, params })
}
/**
 * @description: 更新投放序号
 */
export const updateOmContentOrderNumberApi = (params) => {
  return defHttp.post({ url: Api.UpdateOmContentOrderNumber, params })
}
/**
 * @description: 获取投放内容详情
 */
export const getOmContentDetailApi = (params) => {
  return defHttp.get({ url: Api.GetOmContentDetail, params })
}

/**
 * @description: 更新投放内容
 */
export const updateOmContentApi = (params) => {
  return defHttp.post({ url: Api.UpdateOmContent, params })
}
/**
 * @description: 新增投放内容
 */
export const createOmContentApi = (params) => {
  return defHttp.post({ url: Api.CreateOmContent, params })
}
/**
 * @description: 删除投放内容
 */
export const deleteOmContentApi = (params) => {
  return defHttp.post({ url: Api.DeleteOmContent, params })
}

/**
 * @description: 级联检索资源位
 */
export const getResourcePositionForOmContentApi = (params) => {
  return defHttp.get({ url: Api.GetResourcePositionForOmContent, params })
}

/**
 * @description: 搜索neirogn
 */
export const GetVersionChannelList = async (params) => {
  return await defHttp.get({ url: Api.GetVersionChannelList, params })
}
/**
 * @description: 获取用户标签列表
 */
export const getUserLabelListApi = async (params) => {
  return await defHttp.get({ url: Api.GetUserLabelList, params })
}
/**
 * @description: 更新资源位密钥
 */
export const updateUnifyKeyApi = async (params) => {
  return await defHttp.post({ url: Api.UpdateUnifyKey, params })
}

/**
 * @description: 搜索渠道esj列表
 */
export const GetChannelEventSearch = async (params) => {
  return await defHttp.get({ url: Api.GetChannelEventSearch, params })
}

/**
 * @description: 搜索渠道esj列表批量
 */
export const GetSearchChannelInfos = async (params) => {
  return await defHttp.post({ url: Api.GetSearchChannelInfos, params })
}
