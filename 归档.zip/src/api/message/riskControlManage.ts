import { defHttp } from '/@/utils/http/axios'
// 风控管理
enum Api {
  // 黑白名单tab-短信/邮件 /message
  queryMessageBlackAndWhiteList = '/message/backend/riskConfig/name/queryList',
  deleteMessageBlackAndWhite = '/message/backend/riskConfig/name/del',
  createMessageBlackAndWhite = '/message/backend/riskConfig/name/create',
  updateMessageBlackAndWhite = '/message/backend/riskConfig/name/update',
  getMessageBlackAndWhiteDetail = '/message/backend/riskConfig/name/byId',
  getRiskNameRiskTypeInfo = '/message/backend/common/getRiskNameRiskTypeInfo',
  getRiskNameBizTypeInfo = '/message/backend/common/getRiskNameBizTypeInfo',

  // 黑白名单tab-PUSH /user-push-server
  queryPushBlackAndWhiteList = '/user-push-server/backend/riskConfig/name/queryList',
  createPushBlackAndWhite = '/user-push-server/backend/riskConfig/name/create',
  updatePushBlackAndWhite = '/user-push-server/backend/riskConfig/name/update',
  deletePushBlackAndWhite = '/user-push-server/backend/riskConfig/name/del',
  getPushBlackAndWhiteDetail = '/user-push-server/backend/riskConfig/name/byId',
  getPushAppTypeInfo = '/user-push-server/backend/common/getAppTypeInfo',
  getPushRiskNameRiskTypeInfo = '/user-push-server/backend/common/getRiskNameRiskTypeInfo',
  getPushNotificationTypeInfo = '/user-push-server/backend/common/getNotificationTypeInfo',

  //  敏感词 短信/邮件
  querySensitiveWordList = '/message/backend/riskConfig/sensitive/word/queryList',
  createSensitiveWord = '/message/backend/riskConfig/sensitive/word/create',
  updateSensitiveWord = '/message/backend/riskConfig/sensitive/word/update',
  deleteSensitiveWord = '/message/backend/riskConfig/sensitive/word/del',
  getSensitiveWordDetail = '/message/backend/riskConfig/sensitive/word/byId',
  getNotificationTypeInfo = '/message/backend/common/getNotificationTypeInfo',
  getNotificationSubTypeInfo = '/message/backend/common/getNotificationSubTypeInfo',
  //  敏感词 Push
  queryPushSensitiveWordList = '/user-push-server/backend/riskConfig/sensitive/word/queryList',
  createPushSensitiveWord = '/user-push-server/backend/riskConfig/sensitive/word/create',
  updatePushSensitiveWord = '/user-push-server/backend/riskConfig/sensitive/word/update',
  deletePushSensitiveWord = '/user-push-server/backend/riskConfig/sensitive/word/del',
  getPushSensitiveWordDetail = '/user-push-server/backend/riskConfig/sensitive/word/byId',
  getPushNotificationSubTypeInfo = '/user-push-server/backend/common/getNotificationSubTypeInfo',

  // 告警拦截 阈值 （短信/邮件）
  queryLimitList = '/message/backend/riskConfig/biz/user/limit/queryList',
  createLimit = '/message/backend/riskConfig/biz/user/limit/create',
  updateLimit = '/message/backend/riskConfig/biz/user/limit/update',
  deleteLimit = '/message/backend/riskConfig/biz/user/limit/del',
  getLimitDetail = '/message/backend/riskConfig/biz/user/limit/byId',
  getRiskBizLimitTypeInfo = '/message/backend/common/getRiskBizLimitTypeInfo',
  queryEnumBizConfig = '/message/backend/bizConfig/queryEnumBizConfig',
  // 敏感词白名单 （短信/邮件）

  querySensitiveWordWhiteList = '/message/backend/riskConfig/word/template/white/queryList',
  createWhiteList = '/message/backend/riskConfig/word/template/white/create',
  createBatchWhiteList = '/message/backend/riskConfig/word/template/white/batchCreate',
  deleteWhiteList = '/message/backend/riskConfig/word/template/white/del',
  queryListByWord = '/message/backend/riskConfig/word/template/white/queryListByWord',
  searchSensitiveWordTemplateList = '/message/backend/templateConfig/searchTemplateList',
  getSensitiveWordsList = '/message/backend/riskConfig/getSensitiveWords',
}
// --------------------黑白名单 短信/邮件 -----------------
/**
 * @description: 根据条件查询黑白名单列表（短信/邮件）
 */
export const queryMessageBlackAndWhiteListApi = (params) => {
  return defHttp.get({ url: Api.queryMessageBlackAndWhiteList, params })
}
/**
 * @description: 创建黑白名单列表（短信/邮件）
 */
export const createMessageBlackAndWhiteApi = (params) => {
  return defHttp.post({ url: Api.createMessageBlackAndWhite, params })
}
/**
 * @description: 编辑黑白名单列表（短信/邮件）
 */
export const updateMessageBlackAndWhiteApi = (params) => {
  return defHttp.post({ url: Api.updateMessageBlackAndWhite, params })
}
/**
 * @description: 根据id获取当前黑白名单详细数据（短信/邮件）
 */
export const getMessageBlackAndWhiteDetailApi = (params) => {
  return defHttp.post({ url: Api.getMessageBlackAndWhiteDetail, params })
}
/**
 * @description: 删除黑白名单列表（短信/邮件）
 */
export const deleteMessageBlackAndWhiteApi = (params) => {
  return defHttp.post({ url: Api.deleteMessageBlackAndWhite, params })
}
/**
 * @description: 获取黑白名单枚举类别（短信/邮件）
 */
export const getRiskNameRiskTypeInfoApi = (params) => {
  return defHttp.get({ url: Api.getRiskNameRiskTypeInfo, params })
}
/**
 * @description: 获取黑白名单所属通道子类型（短信/邮件）
 */
export const getRiskNameBizTypeInfoApi = (params) => {
  return defHttp.get({ url: Api.getRiskNameBizTypeInfo, params })
}
// ------------------------------ 黑白名单push-----------------------------------------------
/**
 * @description: 根据条件查询黑白名单列表（PUSH）
 */
export const queryPushBlackAndWhiteListApi = (params) => {
  return defHttp.get({ url: Api.queryPushBlackAndWhiteList, params })
}
/**
 * @description: 创建黑白名单（push）
 */
export const createPushBlackAndWhiteApi = (params) => {
  return defHttp.post({ url: Api.createPushBlackAndWhite, params })
}
/**
 * @description: 编辑黑白名单（push）
 */
export const updatePushBlackAndWhiteApi = (params) => {
  return defHttp.post({ url: Api.updatePushBlackAndWhite, params })
}
/**
 * @description: 删除黑白名单（push）
 */
export const deletePushBlackAndWhiteApi = (params) => {
  return defHttp.post({ url: Api.deletePushBlackAndWhite, params })
}
/**
 * @description: 根据id获取当前黑白名单详细数据（push）
 */
export const getPushBlackAndWhiteDetailApi = (params) => {
  return defHttp.post({ url: Api.getPushBlackAndWhiteDetail, params })
}
/**
 * @description: push端类型枚举（Push）
 */
export const getAppTypeInfoApi = (params) => {
  return defHttp.get({ url: Api.getPushAppTypeInfo, params })
}
/**
 * @description: 获取黑白名单枚举类别（Push）
 */
export const getPushRiskNameRiskTypeInfoApi = (params) => {
  return defHttp.get({ url: Api.getPushRiskNameRiskTypeInfo, params })
}
/**
 * @description: 获取通道类型(消息类型)（Push）
 */
export const getPushNotificationTypeInfoApi = (params) => {
  return defHttp.get({ url: Api.getPushNotificationTypeInfo, params })
}
// ------------------敏感词  短信/邮件------------------------
/**
 * @description: 条件查询敏感词列表（短信/邮件）
 */
export const querySensitiveWordListApi = (params) => {
  return defHttp.get({ url: Api.querySensitiveWordList, params })
}

/**
 * @description: 创建敏感词（短信/邮件）
 */
export const createSensitiveWordApi = (params) => {
  return defHttp.post({ url: Api.createSensitiveWord, params })
}
/**
 * @description: 编辑敏感词（短信/邮件）
 */
export const updateSensitiveWordApi = (params) => {
  return defHttp.post({ url: Api.updateSensitiveWord, params })
}
/**
 * @description: 删除敏感词（短信/邮件）
 */
export const deleteSensitiveWordApi = (params) => {
  return defHttp.post({ url: Api.deleteSensitiveWord, params })
}
/**
 * @description: 获取敏感词详情（短信/邮件）
 */
export const getSensitiveWordDetailApi = (params) => {
  return defHttp.post({ url: Api.getSensitiveWordDetail, params })
}
/**
 * @description: 获取通道类型枚举信息 通道类型(消息类型)
 */
export const getNotificationTypeInfoApi = (params = {}) => {
  return defHttp.get({ url: Api.getNotificationTypeInfo, params })
}

/**
 * @description: 获取消息类型枚举信息 消息类型 依赖于通道类型
 */
export const getNotificationSubTypeInfoApi = (params = {}) => {
  return defHttp.get({ url: Api.getNotificationSubTypeInfo, params })
}
// ------------------敏感词  Push----------------------------
/**
 * @description: 条件查询敏感词列表
 */
export const queryPushSensitiveWordListApi = (params) => {
  return defHttp.get({ url: Api.queryPushSensitiveWordList, params })
}
/**
 * @description: 创建敏感词（push）
 */
export const createPushSensitiveWordApi = (params) => {
  return defHttp.post({ url: Api.createPushSensitiveWord, params })
}
/**
 * @description: 编辑敏感词（push）
 */
export const updatePushSensitiveWordApi = (params) => {
  return defHttp.post({ url: Api.updatePushSensitiveWord, params })
}
/**
 * @description: 删除敏感词（push）
 */
export const deletePushSensitiveWordApi = (params) => {
  return defHttp.post({ url: Api.deletePushSensitiveWord, params })
}
/**
 * @description: 获取敏感词详情（push）
 */
export const getPushSensitiveWordDetailApi = (params) => {
  return defHttp.post({ url: Api.getPushSensitiveWordDetail, params })
}
/**
 * @description: 获取消息类型枚举信息 消息类型 依赖于通道类型
 */
export const getPushNotificationSubTypeInfoApi = (params = {}) => {
  return defHttp.get({ url: Api.getPushNotificationSubTypeInfo, params })
}
// -------------- 告警拦截（阈值）  短信/邮件--------------------------
/**
 * @description:根据条件查询阈值限制配置列表
 */
export const queryLimitListApi = (params = {}) => {
  return defHttp.get({ url: Api.queryLimitList, params })
}
/**
 * @description: 阈值限制配置
 */
export const createLimitApi = (params = {}) => {
  return defHttp.post({ url: Api.createLimit, params })
}
/**
 * @description: 编辑阈值限制配置
 */
export const updateLimitApi = (params = {}) => {
  return defHttp.post({ url: Api.updateLimit, params })
}
/**
 * @description: 删除阈值限制配置
 */
export const deleteLimitApi = (params = {}) => {
  return defHttp.post({ url: Api.deleteLimit, params })
}
/**
 * @description: 阈值限制配置详情
 */
export const getLimitDetailApi = (params = {}) => {
  return defHttp.post({ url: Api.getLimitDetail, params })
}
/**
 * @description: 阈值所属维度
 */
export const getRiskBizLimitTypeInfoApi = (params = {}) => {
  return defHttp.get({ url: Api.getRiskBizLimitTypeInfo, params })
}
/**
 * @description: 阈值 业务线
 */
export const queryEnumBizConfigApi = (params = {}) => {
  return defHttp.get({ url: Api.queryEnumBizConfig, params })
}
// -------------------敏感词白名单----------
/**
 * @description: 列表
 */
export const querySensitiveWordWhiteListApi = (params = {}) => {
  return defHttp.get({ url: Api.querySensitiveWordWhiteList, params })
}
/**
 * @description: 创建
 */
export const createWhiteListApi = (params = {}) => {
  return defHttp.post({ url: Api.createWhiteList, params })
}
/**
 * @description: 批量创建
 */
export const createBatchWhiteListApi = (params = {}) => {
  return defHttp.post({ url: Api.createBatchWhiteList, params })
}
/**
 * @description: 删除
 */
export const deleteWhiteListApi = (params = {}) => {
  return defHttp.post({ url: Api.deleteWhiteList, params })
}
/**
 * @description: 根据敏感词，查询敏感词模板白名单
 */
export const queryListByWordApi = (params = {}) => {
  return defHttp.get({ url: Api.queryListByWord, params })
}
/**
 * @description: 全量敏感词感词模板白名单
 */
export const querySensitiveWordTemplateListApi = (params = {}) => {
  return defHttp.get({ url: Api.searchSensitiveWordTemplateList, params })
}
/**
 * @description: 敏感词列表下拉框使用
 */
export const getSensitiveWordsListApi = (params = {}) => {
  return defHttp.get({ url: Api.getSensitiveWordsList, params })
}
