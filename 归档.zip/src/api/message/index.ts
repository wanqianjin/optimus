import { defHttp } from '/@/utils/http/axios'

enum Api {
  QueryAppEnmu = '/message/backend/common/getAppTypeInfo', //push渠道枚举
  QueryTemplateList = '/message/backend/templateConfig/queryTemplateList',
  QueryNotification = '/message/backend/notification/queryNotification',
  QueryWechatTemplateList = '/message/backend/templateConfig/wechatTemplateList',
  CreateTemplateConfig = '/message/backend/templateConfig/createTemplateConfig',
  QueryTemplateDetail = '/message/backend/templateConfig/getTemplateDetail', //查询邮件模板信息
  UpdateTemplateConfig = '/message/backend/templateConfig/updateTemplateConfig', //编辑邮件模板信息
  UpdateTemplateConfigBiz = '/message/backend/templateConfig/updateTemplateConfigBiz', //关联业务线
  GetSignatureTypeInfo = '/message/backend/common/getSignatureTypeInfo',
  GetTemplateTypeInfo = '/message/backend/common/getTemplateTypeInfo',
  GetSmsTypeInfo = '/message/backend/common/getSmsTypeInfo',
  GetNotificationTypeInfo = '/message/backend/common/getNotificationTypeInfo',
  GetNotificationSubTypeInfo = '/message/backend/common/getNotificationSubTypeInfo',
  GetCountryTypeInfo = '/message/backend/common/getCountryTypeInfo',
  GetChannelInfo = '/message/backend/common/getChannelInfo',
  UpdateTemplateConfigStatus = '/message/backend/templateConfig/updateTemplateConfigStatus',
  QueryBizConfigList = '/message/backend/bizConfig/queryBizConfigList',
  SendSmsMessage = '/message/backend/message/sendSmsMessage',
  SendEmailMessage = '/message/backend/message/sendMessage',
  QuerybizMailAddress = '/message/backend/bizMailAddress/queryList',
  downLoadMessage = '/message/backend/bizNotificationConfig/exportData', // 消息管理导出信息
  // 微信 联动前的
  QueryWechatChannelEnum = '/message/backend/templateConfig/wechatChannelEnum',
  // 微信 联动后的
  QueryWechatEnum = '/message/backend/templateConfig/enum',
  DeleteWechatTemplate = '/message/backend/templateConfig/deleteWechatTemplate',
  // app push
  SendPushMessage = '/activity-backend-server/push/pushMessage',
  // 获取微信模版列表
  getTemplateList = '/activity-backend-server/wx/getTemplateList',
  // 发送模版消息
  sendTemplateMessage = '/activity-backend-server/wx/sendTemplateMessage',
  // 发送车机消息
  vehicleSendMessage = '/activity-backend-server/vehicle/sendMessage',
  // 发送站内信消息
  sendBoxMessage = '/activity-backend-server/sale/sendBoxMessage',
  // 消息分类映射关系
  classificationRelation = '/activity-backend-server/sale/classificationRelation',
  // 消息紧急度映射关系
  msgScoreRelation = '/activity-backend-server/sale/msgScoreRelation',
  // 发送app站内信
  SendAppMessage = '/user-backend/messageBox/sendAppMessage',
  // 查看分类
  QueryClassifications = '/user-backend/messageBox/queryClassifications',
  // 通道类型枚举
  GetRootClassification = '/user-backend/messageBox/getRootClassification',
  // 消息类型枚举
  GetMessageClassification = '/user-backend/messageBox/app/classificationRelation',
  // 添加分类
  AddClassification = '/user-backend/messageBox/addClassification',
  // 更新分类
  UpdateClassification = '/user-backend/messageBox/updateClassification',
  // 模糊查询新人员数据信息
  ManageUserList = '/message/backend/user/manageUserList',
  // 创建业务线
  CreateBizConfig = '/message/backend/bizConfig/createBizConfig',
  // 更新业务线
  UpdateBizConfig = '/message/backend/bizConfig/updateBizConfig',

  RedDotList = '/user-backend/touch/redDot/list', //红点列表
  QueryPositionList = '/user-backend/touch/redDot/queryPosition', //获取新增规则页面位置ID列表
  AddredDot = '/user-backend/touch/redDot/add', //新增红点规则
  QueryRedDotDetail = '/user-backend/touch/redDot/detail', //查询规则详情
  UpdateRedDot = '/user-backend/touch/redDot/update', //编辑红点规则
  CloseRedDot = '/user-backend/touch/redDot/close', //关闭红点规则
  EffectiveRedDot = '/user-backend/touch/redDot/effective', //红点规则生效
  // 消息管理
  QueryNotificationConfigList = '/message/backend/bizNotificationConfig/queryBizConfigList',
  CreateBizNotificationConfig = '/message/backend/bizNotificationConfig/createBizNotificationConfig',
  UpdateBizNotificationConfig = '/message/backend/bizNotificationConfig/updateBizNotificationConfig',
  GetBizNotificationConfigDetail = '/message/backend/bizNotificationConfig/getBizNotificationConfigDetail',
  GetSearchTemplateList = '/message/backend/templateConfig/searchTemplateList',
  SearchSendIdentification = '/message/backend/sendIdentification/searchSendIdentification',

  // 所属业务线枚举
  QueryEnumBizConfig = '/message/backend/bizConfig/queryEnumBizConfig',

  QuerySendIdentificationList = '/message/backend/sendIdentification/querySendIdentificationList',
  //创建发送标识
  CreateBizMailAddress = '/message/backend/sendIdentification/createSendIdentification',
  //发送标识-获取邮件域名列表
  GetMailDomainName = '/message/backend/messageExt/getMailDomainName',
  // 创建飞书标识
  CreateFeishuConfig = '/message/backend/feishu/config/create',
  // 飞书标识列表
  GetFeishuList = '/message/backend/feishu/config/queryList',
  deleteFeishuConfig = '/message/backend/feishu/config/del',
}

/**
 * @description: 获取内容模板和签名信息
 */
export const queryTemplateList = (params) => {
  return defHttp.post({ url: Api.QueryTemplateList, params })
}

/**
 * @description: 获取消息列表
 */
export const queryNotification = (params) => {
  return defHttp.post({ url: Api.QueryNotification, params })
}
/**
 * @description: 获取push渠道枚举值
 */
export const queryAppEnmuList = (params = {}) => {
  return defHttp.get({ url: Api.QueryAppEnmu, params })
}
/**
 * @description: 微信模板列表
 */
export const queryWechatTemplateList = (params) => {
  return defHttp.get({ url: Api.QueryWechatTemplateList, params })
}

/**
 * @description: 创建短信内容模板 创建短信签名模板 创建app推送模板
 */
export const createTemplateConfig = (params) => {
  return defHttp.post({ url: Api.CreateTemplateConfig, params })
}

/**
 * @description: 查询app推送模板详情
 */
export const queryTemplateDetail = (params) => {
  return defHttp.post({ url: Api.QueryTemplateDetail, params })
}

/**
 * @description: 编辑app推送模板
 */
export const updateTemplateConfig = (params) => {
  return defHttp.post({ url: Api.UpdateTemplateConfig, params })
}

/**
 * @description: 编辑app推送模板
 */
export const updateTemplateConfigBizApi = (params) => {
  return defHttp.post({ url: Api.UpdateTemplateConfigBiz, params })
}

/**
 * @description: 获取签名类型枚举信息 签名类型
 */
export const getSignatureTypeInfo = (params = {}) => {
  return defHttp.get({ url: Api.GetSignatureTypeInfo, params })
}

/**
 * @description: 获取模板类型枚举信息 模板类型
 */
export const getTemplateTypeInfo = (params = {}) => {
  return defHttp.get({ url: Api.GetTemplateTypeInfo, params })
}

/**
 * @description: 获取短信类型枚举信息 短信类型
 */
export const getSmsTypeInfo = (params = {}) => {
  return defHttp.get({ url: Api.GetSmsTypeInfo, params })
}

/**
 * @description: 获取通道类型枚举信息 通道类型
 */
export const getNotificationTypeInfo = (params = {}) => {
  return defHttp.get({ url: Api.GetNotificationTypeInfo, params })
}

/**
 * @description: 获取消息类型枚举信息 消息类型 依赖于通道类型
 */
export const getNotificationSubTypeInfo = (params = {}) => {
  return defHttp.get({ url: Api.GetNotificationSubTypeInfo, params })
}

/**
 * @description: 获取使用范围枚举信息 使用范围
 */
export const getCountryTypeInfo = (params = {}) => {
  return defHttp.get({ url: Api.GetCountryTypeInfo, params })
}

/**
 * @description: 获取通道名称枚举信息 通道名称
 */
export const getChannelInfo = (params = {}) => {
  return defHttp.get({ url: Api.GetChannelInfo, params })
}

/**
 * @description: 更新短信签名和内容模板状态
 */
export const updateTemplateConfigStatus = (params = {}) => {
  return defHttp.post({ url: Api.UpdateTemplateConfigStatus, params })
}

/**
 * @description: 获取业务线列表:https://jmock.jiduauto.com/project/188/interface/api/2959
 */
export const queryBizConfigList = (params = {}) => {
  return defHttp.post({ url: Api.QueryBizConfigList, params })
}

/**
 * @description: 发送短信接口
 */
export const sendSmsMessage = (params = {}) => {
  return defHttp.post({ url: Api.SendSmsMessage, params })
}

/**
 * @description: 发送邮件接口
 */
export const sendEmailMessage = (params = {}) => {
  return defHttp.post({ url: Api.SendEmailMessage, params })
}

/**
 * @description: 获取邮件发信地址列表
 */
export const querybizMailAddress = (params = {}) => {
  return defHttp.get({ url: Api.QuerybizMailAddress, params })
}
/**
 * @description: 消息管理导出信息
 */
export const downLoadMessageApi = (params = {}) => {
  return defHttp.post({ url: Api.downLoadMessage, params })
}
/**
 * @description: 微信-模板列表相关枚举 联动前
 */
export const queryWechatChannelEnum = (params = {}) => {
  return defHttp.get({ url: Api.QueryWechatChannelEnum, params })
}

/**
 * @description: 微信-模板列表相关枚举 联动后
 */
export const queryWechatEnum = (params = {}) => {
  return defHttp.get({ url: Api.QueryWechatEnum, params })
}

/**
 * @description: 微信-删除模板
 */
export const deleteWechatTemplate = (params = {}) => {
  return defHttp.post({ url: Api.DeleteWechatTemplate, params })
}

/**
 * @description: push接口
 */
export const sendPushMessage = (params = {}) => {
  return defHttp.post({ url: Api.SendPushMessage, params })
}

/**
 * @description: 获取微信模版列表
 */
export const getTemplateList = (params = {}) => {
  return defHttp.get({ url: Api.getTemplateList, params })
}

/**
 * @description: 发送微信模版
 */
export const sendTemplateMessage = (params = {}) => {
  return defHttp.post({ url: Api.sendTemplateMessage, params })
}

/**
 * @description: 发送车机模版消息
 */
export const vehicleSendMessage = (params = {}) => {
  return defHttp.post({ url: Api.vehicleSendMessage, params })
}

/**
 * @description: 发送站内信消息
 */
export const sendBoxMessage = (params = {}) => {
  return defHttp.post({ url: Api.sendBoxMessage, params })
}

/**
 * @description: 消息分类映射关系
 */
export const classificationRelation = (params = {}) => {
  return defHttp.get({ url: Api.classificationRelation, params })
}
/**
 * @description: 消息紧急度映射关系
 */
export const msgScoreRelation = (params = {}) => {
  return defHttp.get({ url: Api.msgScoreRelation, params })
}

/**
 * @description: app站内信发送接口: https://jmock.jiduauto.com/project/188/interface/api/29247
 */
export const sendAppMessageApi = (params = {}) => {
  return defHttp.post({ url: Api.SendAppMessage, params })
}

/**
 * @description: 查看分类接口: https://jmock.jiduauto.com/project/188/interface/api/29227
 */
export const queryClassificationsApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryClassifications, params })
}

/**
 * @description: 通道类型枚举: https://jmock.jiduauto.com/project/188/interface/api/31187
 */
export const getRootClassificationApi = (params = {}) => {
  return defHttp.get({ url: Api.GetRootClassification, params })
}

/**
 * @description: 消息类型枚举: https://jmock.jiduauto.com/project/188/interface/api/29255
 */
export const getMessageClassificationApi = (params = {}) => {
  return defHttp.get({ url: Api.GetMessageClassification, params })
}

/**
 * @description: 添加分类: https://jmock.jiduauto.com/project/188/interface/api/29223
 */
export const addClassificatioApi = (params = {}) => {
  return defHttp.post({ url: Api.AddClassification, params })
}

/**
 * @description: 更新分类: https://jmock.jiduauto.com/project/188/interface/api/29235
 */
export const updateClassificationApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateClassification, params })
}

/**
 * @description: 用户信息-模糊查新人员数据信息:https://jmock.jiduauto.com/project/188/interface/api/96111
 */
export const manageUserListApi = (params = {}) => {
  return defHttp.post({ url: Api.ManageUserList, params })
}

/**
 * @description: 业务线-创建业务线信息:https://jmock.jiduauto.com/project/188/interface/api/2947
 */
export const createBizConfigApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateBizConfig, params })
}

/**
 * @description: 业务线-更新业务线信息:https://jmock.jiduauto.com/project/188/interface/api/95907
 */
export const updateBizConfigApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateBizConfig, params })
}
/**
 * @description: 红点列表搜索
 */
export const redDotListApi = (params = {}) => {
  return defHttp.post({ url: Api.RedDotList, params })
}
/**
 * @description: 新增红点规则获取页面位置ID List
 */
export const queryPositionListApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryPositionList, params })
}
/**
 * @description: 新增红点规则
 */
export const addredDotApi = (params = {}) => {
  return defHttp.post({ url: Api.AddredDot, params })
}
/**
 * @description: 查询红点规则
 */
export const queryRedDotDetailApi = (params = {}) => {
  return defHttp.post({ url: Api.QueryRedDotDetail, params })
}
/**
 * @description: 编辑红点规则
 */
export const updateRedDotApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateRedDot, params })
}
/**
 * @description: 关闭红点规则
 */
export const closeRedDotApi = (params = {}) => {
  return defHttp.post({ url: Api.CloseRedDot, params })
}
/**
 * @description: 红点规则生效
 */
export const effectiveRedDotApi = (params = {}) => {
  return defHttp.post({ url: Api.EffectiveRedDot, params })
}
// 消息管理-列表：https://jmock.jiduauto.com/project/188/interface/api/2989
export const queryNotificationConfigListApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryNotificationConfigList, params })
}
// 消息管理-创建：https://jmock.jiduauto.com/project/188/interface/api/2989
export const createBizNotificationConfigApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateBizNotificationConfig, params })
}
// 消息管理-更新：https://jmock.jiduauto.com/project/188/interface/api/2989
export const updateBizNotificationConfigApi = (params = {}) => {
  return defHttp.post({ url: Api.UpdateBizNotificationConfig, params })
}
// 消息管理-详情://https://jmock.jiduauto.com/project/188/interface/api/96511
export const GetBizNotificationConfigDetailApi = (params = {}) => {
  return defHttp.post({ url: Api.GetBizNotificationConfigDetail, params })
}
//消息管理-查询模板https://jmock.jiduauto.com/project/188/interface/api/2989
export const getSearchTemplateListApi = (params = {}) => {
  return defHttp.get({ url: Api.GetSearchTemplateList, params })
}
// 消息管理-查询签名https://jmock.jiduauto.com/project/188/interface/api/2989
export const searchSendIdentificationApi = (params = {}) => {
  return defHttp.get({ url: Api.SearchSendIdentification, params })
}

// 发送标识-所属业务线枚举：https://jmock.jiduauto.com/project/188/interface/api/96375
export const queryEnumBizConfigApi = (params = {}) => {
  return defHttp.get({ url: Api.QueryEnumBizConfig, params })
}
// 发送标识-发送标识列表：https://https://jmock.jiduauto.com/project/188/interface/api/95911
export const querySendIdentificationListApi = (params = {}) => {
  return defHttp.get({ url: Api.QuerySendIdentificationList, params })
}
// 发送标识-创建发送标识：https://jmock.jiduauto.com/project/188/interface/api/7987
export const createBizMailAddressApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateBizMailAddress, params })
}

export const getMailDomainNameApi = (params = {}) => {
  return defHttp.get({ url: Api.GetMailDomainName, params })
}
// 发送标识-创建飞书发送标识：https://jmock.jiduauto.com/project/188/interface/api/101263
export const createFeishuConfigApi = (params = {}) => {
  return defHttp.post({ url: Api.CreateFeishuConfig, params })
}
// 飞书应用配置列表：https://jmock.jiduauto.com/project/188/interface/api/101271
export const getFeishuListApi = (params = {}) => {
  return defHttp.get({ url: Api.GetFeishuList, params })
}
// 飞书应用配置列表：https://jmock.jiduauto.com/project/188/interface/api/101271
export const deleteFeishuConfigApi = (params = {}) => {
  return defHttp.post({ url: Api.deleteFeishuConfig, params })
}
