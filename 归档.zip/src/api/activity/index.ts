import { defHttp } from '/@/utils/http/axios'

enum Api {
  // -----广告活动-----
  CreateAdActivity = '/activity/advertisement/backend/create',
  QueryActivityList = '/activity/advertisement/backend/queryList',
  UpdateSpace = '/activity/advertisement/backend/updateSpace',
  GetActivityDetail = '/activity/advertisement/backend/queryDetail',
  UpdateAdvertisement = '/activity/advertisement/backend/update',
  DeleteAdActivity = '/activity/advertisement/backend/delete',
  QueryAdActivityDetail = '/activity/advertisement/backend/queryDetail',
  QueryComment = '/activity/advertisement/backend/queryComment',
  UpdateComment = '/activity/advertisement/backend/updateComment',
  GetPKStatistics = '/activity/advertisement/backend/statistics',
  GetStatisticsDetail = '/activity/advertisement/backend/statisticsDetail',
  ReplyComment = '/activity/advertisement/backend/replyComment',

  // ---------列表活动-------
  CreateListEvent = '/activity/activity/backend/create',
  QuerylistEvent = '/activity/activity/backend/queryList',
  UpdateListEventSpace = '/activity/activity/backend/updateSequence',
  UpdateListEvent = '/activity/activity/backend/update',
  QueryListEventDetail = '/activity/activity/backend/queryDetail',
  DeletelistEvent = '/activity/activity/backend/delete',
  GetListEventPKStatistics = '/activity/activity/backend/statistics',
  QueryListEventComment = '/activity/activity/backend/queryComment',
  UpdateListEventComment = '/activity/activity/backend/updateComment',
  GetListEventStatisticsDetail = '/activity/activity/backend/statisticsDetail',
  ReplyEventComment = '/activity/activity/backend/replyComment',
}

/**
 * @description: 获取广告活动列表
 */
export const queryActivityListApi = (params) => {
  return defHttp.get({ url: Api.QueryActivityList, params })
}
/**
 * @description: 更新广告活动-广告位
 */
export const updateSpaceApi = (params) => {
  return defHttp.post({ url: Api.UpdateSpace, params })
}

/**
 * @description: 查询广告活动详情
 */
export const getActivityDetailApi = (params) => {
  return defHttp.get({ url: Api.GetActivityDetail, params })
}

/**
 * @description: 创建广告活动信息
 */
export const createAdActivityApi = (params) => {
  return defHttp.post({ url: Api.CreateAdActivity, params })
}
/**
 * @description: 更新广告活动信息
 */
export const updateAdActivityApi = (params) => {
  return defHttp.post({ url: Api.UpdateAdvertisement, params })
}

/**
 * @description: 删除广告活动
 */
export const deleteAdActivityApi = (params) => {
  return defHttp.post({ url: Api.DeleteAdActivity, params })
}
/**
 * @description: 广告活动-回复评论
 */
export async function replyCommentApi(params) {
  return defHttp.post({ url: Api.ReplyComment, params })
}
/**
 * @description: 查询广告活动详情信息
 */
export const queryAdActivityDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryAdActivityDetail, params })
}

/**
 * @description: 查询广告活动评论列表
 */
export const queryCommentApi = (params) => {
  return defHttp.get({ url: Api.QueryComment, params })
}

/**
 * @description: 更新评论状态
 */
export const updateActivityCommentApi = (params) => {
  return defHttp.post({ url: Api.UpdateComment, params })
}

/**
 * @description: 获取话题数据统计
 */
export const getPKStatisticsApi = (params) => {
  return defHttp.get({ url: Api.GetPKStatistics, params })
}
/**
 * @description: 获取列表活动数据详细信息
 */
export const getStatisticsDetailApi = (params) => {
  return defHttp.get({ url: Api.GetStatisticsDetail, params })
}

/**
 * @description: 获取数据详细信息
 */
export const getListEventStatisticsDetailApi = (params) => {
  return defHttp.get({ url: Api.GetListEventStatisticsDetail, params })
}
/**
 * @description: 列表活动-回复评论
 */
export async function replyEventCommentApi(params) {
  return defHttp.post({ url: Api.ReplyEventComment, params })
}
/**
 * @description: 创建列表活动信息
 */
export const createListEventApi = (params) => {
  return defHttp.post({ url: Api.CreateListEvent, params })
}
/**
 * @description: 获取列表活动列表
 */
export const querylistEventApi = (params) => {
  return defHttp.get({ url: Api.QuerylistEvent, params })
}

/**
 * @description: 更新列表活动信息
 */
export const updateListEventApi = (params) => {
  return defHttp.post({ url: Api.UpdateListEvent, params })
}
/**
 * @description:  查询列表活动详情信息
 */
export const queryListEventDetailApi = (params) => {
  return defHttp.get({ url: Api.QueryListEventDetail, params })
}

/**
 * @description:  删除活动
 */
export const deletelistEventApi = (params) => {
  return defHttp.post({ url: Api.DeletelistEvent, params })
}
/**
 * @description: 获取列表活动话题数据统计
 */
export const getListEventPKStatisticsApi = (params) => {
  return defHttp.get({ url: Api.GetListEventPKStatistics, params })
}
/**
 * @description: 查询列表活动评论列表
 */
export const queryListEventCommentApi = (params) => {
  return defHttp.get({ url: Api.QueryListEventComment, params })
}
/**
 * @description: 更新列表活动评论状态
 */
export const updateListEventCommentApi = (params) => {
  return defHttp.post({ url: Api.UpdateListEventComment, params })
}
/**
 * @description: 更新列表活动-排序
 */
export const updateListEventSpaceApi = (params) => {
  return defHttp.post({ url: Api.UpdateListEventSpace, params })
}
