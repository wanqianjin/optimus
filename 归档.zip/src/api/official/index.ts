import { defHttp } from '/@/utils/http/axios'
import { ContentTypeEnum } from '/@/enums/httpEnum'
enum Api {
  QueryKeyWordReplyList = '/user-wx-mp-server/wx/reply/msg/page',
  Imgupload = '/user-wx-mp-server/wx/material/upload',
  QueryPublishRecordList = '/user-wx-mp-server/wx/mp/publish/getPublishRecordList',
  QueryCreatreply = '/user-wx-mp-server/wx/reply/msg/create',
  QueryUpdateReply = '/user-wx-mp-server/wx/reply/msg/update',
  QueryFollowReplyInfo = '/user-wx-mp-server/wx/reply/msg/selectSubInfo',
  QueryGroupNameInfo = '/user-wx-mp-server/wx/reply/msg/selectInfoByGroupName',
  DeleteGroupApi = '/user-wx-mp-server/wx/reply/msg/deleteGroup',

  // ---------自定义菜单-------
  CreateMenu = '/user-wx-mp-server/wx/menu/conf/create',
  GetMenuContentList = '/user-wx-mp-server/wx/menu/conf/select',
  GetPublishRecordList = '/user-wx-mp-server/wx/mp/publish/getPublishRecordList',
  queryMiniProgram = '/user-wx-mp-server/wx/menu/conf/selectMiniMapping',
}

/**
 * @description: 获取关键词回复列表
 */
export const queryKeyWordReplyListApi = (params) => {
  return defHttp.post({ url: Api.QueryKeyWordReplyList, params })
}
/**
 * @description: 上传素材文件
 */
export const imguploadApi = (params) => {
  return defHttp.post({ url: Api.Imgupload, params })
}
/**
 * @description: 获取已发布图文消息
 */
export const queryPublishRecordListApi = (params) => {
  return defHttp.post({ url: Api.QueryPublishRecordList, params })
}
/**
 * @description: 创建自动回复
 */
export const queryCreatReplyApi = (params) => {
  return defHttp.post({ url: Api.QueryCreatreply, params })
}

/**
 * @description: 自动回复的修改
 */
export const queryUpdateReplyApi = (params) => {
  return defHttp.post({ url: Api.QueryUpdateReply, params })
}

/**
 * @description: 查询被关注回复
 */
export const queryFollowReplyInfoApi = (params) => {
  return defHttp.get({ url: Api.QueryFollowReplyInfo, params })
}

/**
 * @description: 查询规则名称信息
 */
export const queryGroupNameInfoApi = (params) => {
  return defHttp.get({ url: Api.QueryGroupNameInfo, params })
}
/**
 * @description: 删除规则
 */
export const deleteGroupApi = (params) => {
  return defHttp.post({
    url: Api.DeleteGroupApi,
    params,
    headers: { 'Content-Type': ContentTypeEnum.FORM_URLENCODED },
  })
}

/**
 * @description: 保存菜单相关列表
 */
export const createMenuApi = (params) => {
  return defHttp.post({ url: Api.CreateMenu, params })
}

/**
 * @description: 获取菜单相关列表
 */
export const getMenuContentListApi = (params) => {
  return defHttp.get({ url: Api.GetMenuContentList, params })
}

/**
 * @description: 获取图文消息列表
 */
export const getPublishRecordListApi = (params) => {
  return defHttp.post({ url: Api.GetPublishRecordList, params })
}

/**
 * @description: 获取小程序
 */
export const queryMiniProgramApi = () => {
  return defHttp.get({ url: Api.queryMiniProgram })
}
