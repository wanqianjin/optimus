import { defHttp } from '/@/utils/http/axios'
// import axios from 'axios'

enum Api {
  ModuleInfoList = '/comment/backend/moduleInfoList',
  QueryCommentList = '/comment/backend/queryComment',
  CommentContext = '/comment/backend/commentContext',
  StickOnTop = '/comment/backend/stickOnTop', // 置顶
  StickOnTopReplace = '/comment/backend/stickOnTop/withReplace', // 置顶替换
  HideComment = '/comment/backend/hideComment', // 隐藏
  ReplyComment = '/comment/backend/replyComment', // 回复评论
  CommentContent = '/comment/backend/commentContent', //发布评论
  RevertComment = '/comment/backend/normalComment', // 恢复评论
  PackageCommentCount = '/comment/backend/likePlus', // 包装评论数量
  ShieldComment = '/comment/backend/shieldComment', // 单向屏蔽/解除屏蔽
}

/**
 * @description: 搜索条件
 */
export const ModuleInfoList = (params = {}) => {
  return defHttp.get({ url: Api.ModuleInfoList, params })
}

/**
 * @description: 获取评论列表
 */
export const queryCommentList = (params) => {
  return defHttp.post({ url: Api.QueryCommentList, params })
}

/**
 * @description: 评论上下文
 */
export const queryCommentContext = (params) => {
  return defHttp.post({ url: Api.CommentContext, params })
}

/**
 * @description: 更新置顶模板状态
 */
export const updateCommentConfigStick = (params = {}) => {
  return defHttp.post(
    { url: Api.StickOnTop, params },
    {
      errorMessageMode: 'none',
      isTransformResponse: false,
    },
  )
}

/**
 * @description: 更新置顶并替换
 */
export const updateCommentConfigStickReplace = (params = {}) => {
  return defHttp.post({ url: Api.StickOnTopReplace, params })
}

/**
 * @description: 更新隐藏显示模板状态
 */
export const updateCommentConfigStatus = (params = {}) => {
  return defHttp.post({ url: Api.HideComment, params })
}

/**
 * @description: 回复评论
 */
export const ReplyComment = (params = {}) => {
  return defHttp.post({ url: Api.ReplyComment, params })
}

/**
 * @description: 发布评论
 */
export const CommentContent = (params = {}) => {
  return defHttp.post({ url: Api.CommentContent, params })
}

/**
 * @description: 恢复审核未通过的评论
 */
export const RevertComment = (params = {}) => {
  return defHttp.post({ url: Api.RevertComment, params })
}

/**
 * @description: 包装评论点赞数
 */
export const PackageCommentCount = (params = {}) => {
  return defHttp.post({ url: Api.PackageCommentCount, params })
}

/**
 * @description: 单向屏蔽/解除屏蔽
 */
export const ShieldComment = (params = {}) => {
  return defHttp.post({ url: Api.ShieldComment, params })
}
