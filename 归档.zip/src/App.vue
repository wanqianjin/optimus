<template>
  <ConfigProvider :locale="getAntdLocale">
    <AppProvider>
      <RouterView />
    </AppProvider>
  </ConfigProvider>
</template>

<script lang="ts" setup>
import { ConfigProvider } from '@jidu/robot-ui'
import { AppProvider } from '/@/components/Application'
import { useTitle } from '/@/hooks/web/useTitle'
import { useLocale } from '/@/locales/useLocale'
import { setPerformance } from '/@/utils/track'

import 'dayjs/locale/zh-cn'
import { onMounted } from 'vue'
// support Multi-language
const { getAntdLocale } = useLocale()

// Listening to page changes and dynamically changing site titles
useTitle()

onMounted(() => {
  if (window.performance) {
    const performance = window.performance || window.webkitPerformance
    if (performance.timing && performance.timing.navigationStart) {
      const navigationStart = performance.timing.navigationStart
      const endTime = Date.now()
      setTimeout(() => {
        setPerformance(
          'pageLoad',
          {
            startTime: navigationStart,
            endTime: endTime,
          },
          '',
        )
      }, 3000)
      // 页面加载时长
    }
  }
})
</script>
