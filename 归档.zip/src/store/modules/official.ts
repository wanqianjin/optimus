import { defineStore } from 'pinia'
import { store } from '/@/store'

export const useOfficialDataStore = defineStore({
  id: 'official',
  state: () => ({
    //菜单项数据
    menuData: [
      {
        id: 0,
        name: '添加菜单',
        $body: [],
        data: {},
      },
    ],
    //当前选中的菜单项
    selected: {
      id: '',
      subId: '',
      name: '',
      data: {},
    },
  }),
  getters: {
    getMenuData() {
      return this.menuData
    },
    getCurrSelect() {
      return this.selected
    },
  },
  actions: {
    setMenuData(params) {
      console.log('asd', params)
      this.menuData = params
    },
    setCurrSelect(params) {
      this.selected = params
    },
  },
})

export function useOfficialStoreWithOut() {
  return useOfficialDataStore(store)
}
