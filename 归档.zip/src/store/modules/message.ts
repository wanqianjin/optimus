import { defineStore } from 'pinia'
import { store } from '/@/store'
import {
  queryWechatEnum,
  getNotificationTypeInfo,
  getNotificationSubTypeInfo,
  queryWechatChannelEnum,
  queryBizConfigList,
  classificationRelation,
  msgScoreRelation,
  manageUserListApi,
  getMailDomainNameApi,
  queryEnumBizConfigApi,
  getChannelInfo,
  getSearchTemplateListApi,
  searchSendIdentificationApi,
  queryAppEnmuList,
} from '/@/api/message'

interface UserState {
  gradeList: []
}

function transferArray(item, labelName = 'desc', valueName = 'code', keyCode = 'desc') {
  return (
    item && item.map((v) => ({ label: v[labelName], value: v[valueName] + '', key: v[keyCode] }))
  )
}

export const useMessageDataStore = defineStore({
  id: 'message-formwork-center',
  state: (): UserState => ({
    wechatChannel: [],
    messageType: [],
    wechatTemplateType: [],
    templateStatus: [],
    channelName: [],
    // 短信通道类型
    shortMessageChannel: [],
    // 短信消息类型
    shortMessageNotificationSubTypeInfo: [],
    // 发送应用
    bizConfigList: [],
    // 获取消息分类映射关系
    classificationRelation: [],
    // 获取消息紧急度映射关系
    msgScoreRelation: [],
    contactsOptions: [],
    mailDomainName: [],
    enumBizConfig: [],
    //通道名称
    notificationType: [],
    searchTemplateList: [],
    sendIdentification: [],
    pushEnmuList: [],
  }),
  getters: {
    getWechatChannel() {
      return this.wechatChannel
    },
    getMessageType() {
      return this.messageType
    },
    getWechatTemplateType() {
      return this.wechatTemplateType
    },
    getTemplateStatus() {
      return this.templateStatus
    },
    getChannelName() {
      return this.channelName
    },
    getShortMessageChannel() {
      return this.shortMessageChannel
    },
    getShortMessageNotificationSubTypeInfo() {
      return this.shortMessageNotificationSubTypeInfo
    },
    // 发送应用
    getBizConfigList() {
      return this.bizConfigList
    },
    // 消息分类
    getClassificationRelation() {
      return this.classificationRelation
    },
    // 消息紧急程度
    getMsgScoreRelation() {
      return this.msgScoreRelation
    },
    // 联系人
    getContactsOptions() {
      return this.contactsOptions
    },
    //发送标识- 邮箱域名
    getMailDomainName() {
      return this.mailDomainName
    },
    //获取业务线枚举
    getEnumBizConfig() {
      return this.enumBizConfig
    },
    //获取通道名称枚举
    getNotificationType() {
      return this.notificationType
    },
    //获取模板枚举
    getSearchTemplateList() {
      return this.searchTemplateList
    },
    //获取签名枚举
    getSendIdentification() {
      return this.sendIdentification
    },
    getPushEnmuList() {
      return this.pushEnmuList
    },
  },
  actions: {
    setPushEnmuList(options) {
      this.pushEnmuList = options
    },
    setWechatChannel(options) {
      this.wechatChannel = options
    },
    setMessageType(options) {
      this.messageType = options
    },
    setWechatTemplateType(options) {
      this.wechatTemplateType = options
    },
    setTemplateStatus(options) {
      this.templateStatus = options
    },
    setChannelName(options) {
      this.channelName = options
    },
    setShortMessageChannel(options) {
      this.shortMessageChannel = options
    },
    setShortMessageNotificationSubTypeInfo(options) {
      this.shortMessageNotificationSubTypeInfo = options
    },
    setMailDomainName(options) {
      this.mailDomainName = options
    },
    setEnumBizConfig(options) {
      this.enumBizConfig = options
    },
    setNotificationType(options) {
      this.notificationType = options
    },
    setSearchTemplateList(options) {
      this.searchTemplateList = options
    },
    setSendIdentification(options) {
      this.sendIdentification = options
    },

    /**
     * @description: 模板列表相关枚举 联动前
     */
    async getMessageListAction() {
      const data = await queryWechatChannelEnum()
      this.setWechatChannel(transferArray(data.wechatChannel, 'value', 'key', 'key'))
      this.setTemplateStatus(transferArray(data.templateStatus, 'value', 'key', 'key'))
    },
    /**
     * @description: 模板列表相关枚举 联动后
     */
    async getMessageListChannelAction(wechatChannel) {
      const data = await queryWechatEnum({ wechatChannel })
      this.setMessageType(transferArray(data.messageType, 'value', 'key', 'key'))
      this.setWechatTemplateType(transferArray(data.wechatTemplateType, 'value', 'key', 'key'))
      this.setChannelName(transferArray(data.channelName, 'value', 'key', 'key'))
    },
    async getShortMessageChannelAction() {
      const data = await getNotificationTypeInfo()
      this.setShortMessageChannel(transferArray(data))
      return data
    },
    async getShortMessageNotificationSubTypeInfoAction() {
      const data = await getNotificationSubTypeInfo()
      this.setShortMessageNotificationSubTypeInfo(transferArray(data))
      return data
    },
    /**
     * 发送应用
     */
    async getQueryBizConfigList() {
      const data = await queryBizConfigList()
      this.bizConfigList = transferArray(data.list, 'name', 'bizAppId', 'bizAppId')
    },
    /**
     * 消息分类
     */
    async getClassificationRelationList() {
      if (this.classificationRelation.length) {
        return
      }
      const data = await classificationRelation()
      if (Array.isArray(data)) {
        this.classificationRelation.push(...data)
      }
    },
    /**
     * 消息紧急度
     */
    async getMsgScoreRelationList() {
      if (this.msgScoreRelation.length) {
        return
      }
      const data = await msgScoreRelation()
      const arr: Array<object> = []
      for (const key in data) {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
          const element = data[key]
          arr.push({ label: key, value: element, key: key })
        }
      }
      this.msgScoreRelation.push(...arr)
    },
    /**
     * 获取联系人
     */
    async setContactsOptions(name) {
      try {
        const data = await manageUserListApi({ search: name })

        this.contactsOptions = data.list
      } catch (error) {
        console.log('error===', error)
      }
    },
    /**
     * 获取邮件域名列表
     */
    async getMailDomainNameAction() {
      try {
        const data = await getMailDomainNameApi()
        this.setMailDomainName(transferArray(data.list, 'extValue', 'id', 'extValue'))
      } catch (error) {
        console.log('error===', error)
      }
    },
    /**
     * 获取业务线枚举
     */
    async getEnumBizConfigAction() {
      try {
        const data = await queryEnumBizConfigApi()
        this.setEnumBizConfig(transferArray(data, 'name', 'bizAppId', 'bizAppId'))
      } catch (error) {
        console.log('error===', error)
      }
    },
    /**
     * 获取push枚举
     */
    async getPushEnumConfigAction() {
      try {
        const data = await queryAppEnmuList()
        this.setPushEnmuList(transferArray(data, 'desc', 'code', 'code'))
      } catch (error) {
        console.log('error===', error)
      }
    },
    /**
     * 获取通道名称
     */
    async getNotificationTypeAction() {
      try {
        const data = await getChannelInfo()
        this.setNotificationType(transferArray(data))
      } catch (error) {
        console.log('error===', error)
      }
    },
    /**
     * 获取模板枚举
     */
    async getSearchTemplateListAction(params) {
      try {
        const data = await getSearchTemplateListApi(params)
        this.setSearchTemplateList(data)
      } catch (error) {
        console.log('error===', error)
      }
    },
    /**
     * 获取签名枚举
     */
    async getSendIdentificationAction(params) {
      try {
        const data = await searchSendIdentificationApi(params)
        this.setSendIdentification(transferArray(data, 'name', 'id', 'name'))
      } catch (error) {
        console.log('error===', error)
      }
    },
  },
})

// Need to be used outside the setup
export function useMessageStoreWidthOut() {
  return useMessageDataStore(store)
}
