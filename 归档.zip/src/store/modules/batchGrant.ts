import { defineStore } from 'pinia'
import { store } from '/@/store'
import { GetHumanUserApi } from '/@/api/integral/batchGrant'

interface BatchGrantState {
  humanUserList: Array<any>
}

export const useBatchGrantDataStore = defineStore({
  id: 'batchGrant',
  state: (): BatchGrantState => ({
    humanUserList: [], //获取人力列表
  }),
  getters: {
    getHumanUserList() {
      return this.humanUserList
    },
  },
  actions: {
    setHumanUserList(options) {
      this.humanUserList = options
    },

    /**
     * @description: 获取获取人力列表
     */
    async getHumanUserListAction() {
      const result = await GetHumanUserApi({})
      this.setHumanUserList(result)
    },
  },
})

// Need to be used outside the setup
export function useBatchGrantStoreWidthOut() {
  return useBatchGrantDataStore(store)
}
