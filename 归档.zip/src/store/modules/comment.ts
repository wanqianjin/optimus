import { defineStore } from 'pinia'
import { store } from '/@/store'
import { ModuleInfoList } from '/@/api/comment'

function transferArray(
  item,
  labelName = 'desc',
  valueName = 'code',
  keyCode = 'desc',
  moduleType = 'moduleType',
) {
  return (
    item &&
    item.map((v) => ({
      label: v[labelName],
      value: v[valueName],
      appId: v[keyCode],
      moduleType: v[moduleType],
    }))
  )
}

export const useCommentDataStore = defineStore({
  id: 'comment-formwork-center',
  state: () => ({
    templateStatus: [],
    moduleType: '', // 设置ModuleType:
    appId: '',
  }),
  actions: {
    setModuleType(val) {
      this.moduleType = val
    },
    setAppId(val) {
      this.appId = val
    },
    setTemplateStatus(options) {
      this.templateStatus = options
    },
    /**
     * @description: 模板列表相关枚举 联动前
     */
    async getCommentListAction() {
      if (this.templateStatus.length) {
        return
      }
      const data = await ModuleInfoList()
      this.setTemplateStatus(transferArray(data, 'moduleName', 'moduleKey', 'appId', 'moduleType'))
    },
  },
})

// Need to be used outside the setup
export function useCommentStoreWidthOut() {
  return useCommentDataStore(store)
}
