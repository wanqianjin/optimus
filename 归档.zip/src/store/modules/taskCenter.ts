import { defineStore } from 'pinia'
import { store } from '/@/store'

interface UserState {
  taskType: Number
  numOfPeopleLimit: Number | null
}

export const useTaskCenterDataStore = defineStore({
  id: 'taskCenter',
  state: (): UserState => ({
    taskType: 0,
    numOfPeopleLimit: null,
  }),
  getters: {
    getTaskType() {
      return this.taskType
    },
    getNumOfPeopleLimit() {
      return this.numOfPeopleLimit
    },
  },
  actions: {
    // 将任务类型存储
    async setTaskType(params = {}) {
      this.taskType = params
    },
    // 将任务限制-人数限制存储
    setNumOfPeopleLimit(params = null) {
      this.numOfPeopleLimit = params
    },
  },
})

// Need to be used outside the setup
export function useTaskCenterStoreWidthOut() {
  return useTaskCenterDataStore(store)
}
