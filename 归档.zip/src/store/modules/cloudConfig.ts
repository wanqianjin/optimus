import { defineStore } from 'pinia'
import { store } from '/@/store'

export const useCloudConfigDataStore = defineStore({
  id: 'cloudConfig',
  state: () => ({
    serviceType: null,
  }),
  getters: {
    getServiceType() {
      return this.serviceType
    },
  },
  actions: {
    setServiceType(params) {
      this.serviceType = params
    },
  },
})

// Need to be used outside the setup
export function useCloudConfigStoreWidthOut() {
  return useCloudConfigDataStore(store)
}
