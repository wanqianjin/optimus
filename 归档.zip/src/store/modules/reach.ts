import { defineStore } from 'pinia'
import { store } from '/@/store'
import {
  getSmsMessageTypeApi,
  querySignListApi,
  querySmsTemplateNameListApi,
  queryConditionApi,
  querytaskStatusListApi,
  queryAllTaskStatusListApi,
  getCdpRealtimeTagApi,
  getManualTaskTypeEnumApi, //人工触达-触达类型枚举值
  getAutoTaskTypeEnumApi, //自动触达-触达类型枚举值
} from '/@/api/reach'

export const userReachDataStore = defineStore({
  id: 'reach',
  state: () => ({
    // 消息类型
    messageTypeList: [],
    // 签名名称
    signNameList: [],
    // 短信模板名称
    smsTemplateNameList: [],
    // 触达条件
    conditionList: [],
    // 任务状态
    taskStatusList: [],
    // cdp标签id
    cdpTagIdOptionsList: [],
    //人工触达枚举值
    manualTaskTypeEnumList: [],
    //自动触达枚举值
    autoTaskTypeEnumList: [],
  }),
  getters: {
    getMessageTypeList() {
      return this.messageTypeList
    },
    getSignNameList() {
      return this.signNameList
    },
    getSmsTemplateNameList() {
      return this.smsTemplateNameList
    },
    getConditionList() {
      return this.conditionList
    },
    getCdpTagIdOptionsList() {
      return this.cdpTagIdOptionsList
    },
    getTaskStatusList() {
      return this.taskStatusList
    },
    getManualTaskTypeEnumList() {
      return this.manualTaskTypeEnumList
    },
    getAutoTaskTypeEnumList() {
      return this.autoTaskTypeEnumList
    },
  },
  actions: {
    setMessageTypeList(params) {
      this.messageTypeList = params
    },
    setSignNameList(params) {
      this.signNameList = params
    },
    setSmsTemplateNameList(params) {
      this.smsTemplateNameList = params
    },
    setConditionList(params) {
      this.conditionList = params
    },
    setCdpTagIdOptionsList(params) {
      this.cdpTagIdOptionsList = params
    },
    setTaskStatusList(params) {
      this.taskStatusList = params
    },
    setManualTaskTypeEnumList(params) {
      this.manualTaskTypeEnumList = params
    },
    setAutoTaskTypeEnumList(params) {
      this.autoTaskTypeEnumList = params
    },
    /**
     * @description: 获取消息类型
     */
    async getMessageTypeListAction(params = {}) {
      const data = await getSmsMessageTypeApi(params)
      this.setMessageTypeList(data)
    },
    /**
     * @description: 获取签名名称
     */
    async getSignNameListAction(params = {}) {
      const data = await querySignListApi(params)
      this.setSignNameList(data)
    },
    /**
     * @description: 获取短信模板名称
     */
    async getSmsTemplateNameListAction(params = {}) {
      const data = await querySmsTemplateNameListApi(params)
      this.setSmsTemplateNameList(data)
    },
    /**
     * @description: 获取触达条件列表
     */
    async getConditionListAction(params = { condition: '' }) {
      const data = await queryConditionApi(params)
      this.setConditionList(data)
    },
    /**
     * @description: 获取cdp标签id列表
     */
    async getCdpTagIdOptionsListAction(params = {}) {
      const data = await getCdpRealtimeTagApi(params)
      this.setCdpTagIdOptionsList(data)
    },
    /**
     * @description: 获取自动触达任务状态枚举值
     */
    async getTaskStatusListAction(params = {}) {
      const data = await querytaskStatusListApi(params)
      this.setTaskStatusList(data)
    },
    /**
     * @description: 获取所有任务状态枚举值
     */
    async getAllTaskStatusListAction(params = {}) {
      const data = await queryAllTaskStatusListApi(params)
      this.setTaskStatusList(data)
    },
    /**
     * @description: 获取人工触达类型
     */
    async getManualTaskType(params = {}) {
      const data = await getManualTaskTypeEnumApi(params)
      this.setManualTaskTypeEnumList(data)
    },
    /**
     * @description: 获取自动触达类型
     */
    async getAutoTaskType(params = {}) {
      const data = await getAutoTaskTypeEnumApi(params)
      this.setAutoTaskTypeEnumList(data)
    },
  },
})

export function useReachStoreWithOut() {
  return userReachDataStore(store)
}
