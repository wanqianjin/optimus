import { defineStore } from 'pinia'
import { store } from '/@/store'

export const useSceneConfigStore = defineStore({
  id: 'sceneConfig',
  state: () => ({
    MD5FileList: [],
    JSONFileList: [],
  }),
  getters: {
    getMD5FileList() {
      return this.MD5FileList
    },
    getJSONFileList() {
      return this.JSONFileList
    },
  },
  actions: {
    setMD5FileList(params) {
      this.MD5FileList = params
    },
    setJSONFileList(params) {
      this.JSONFileList = params
    },
  },
})

export function useSceneConfigStoreWidthOut() {
  return useSceneConfigStore(store)
}
