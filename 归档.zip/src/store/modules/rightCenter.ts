import { defineStore } from 'pinia'
import { store } from '/@/store'
import {
  queryAtomicEquityTypeApi,
  queryVoucherTypeApi,
  queryAllRightsTypeApi,
  queryPublisherListApi,
  queryDepartmentApi,
  queryCouponMallTypeApi,
  queryAllAvailableTerminalApi,
  queryDepartmentTreeApi,
  queryDistributeInfoApi,
  queryRelateSceneApi,
  querySceneAuthEnableApi,
  queryUserLimitOptionApi,
  queryPersonalLimitSelectListApi,
} from '/@/api/rightCenter'
import { getProvinceCity } from '/@/api/activityRegister'

export const useRightDataStore = defineStore({
  id: 'rightCenter',
  state: () => ({
    rightManageTab: 'voucher',
    rightPkgManageTab: 'vehicleRightPkg',
    rightTypeList: [],
    voucherTypeList: [],
    allRightsTypeList: [],
    publisher: [],
    department: [],
    departmentTree: [],
    allDepartmentTree: [],
    mallTypeList: [],
    terminalOptions: [],
    provinceCityList: [],
    couponCommodityTreeData: [],
    // 权益包相关元数据，包括权益包组合方式；权益发放方式；发放触发事件；跳链命名规则
    distributeInfoData: [],
    // 权益&券可用业务
    relateScene: [],
    // 权益&券可用业务白名单
    relateSceneAuth: false,
    // 券-单人领取限制数据
    userLimitOptions: [],
    // 单人领取限制数据
    personalLimitSelectOptions: [],
  }),
  getters: {
    getRightManageTab() {
      return this.rightManageTab
    },
    getRightPkgManageTab() {
      return this.rightPkgManageTab
    },
    getRightType() {
      return this.rightTypeList
    },
    getVoucherType() {
      return this.voucherTypeList
    },
    getAllRightsType() {
      return this.allRightsTypeList
    },
    getPublisher() {
      return this.publisher
    },
    getDepartment() {
      return this.department
    },
    getAllDepartmentTree() {
      return this.allDepartmentTree
    },
    getDepartmentTree() {
      return this.departmentTree
    },
    getMallType() {
      return this.mallTypeList
    },
    getAvailableTerminalOptions() {
      return this.terminalOptions
    },
    getProvinceCitys() {
      return this.provinceCityList
    },
    getCouponCommodityTree() {
      return this.couponCommodityTreeData
    },
    getDistributeInfoData() {
      return this.distributeInfoData
    },
    getRelateScene() {
      return this.relateScene
    },
    getRelateSceneAuth() {
      return this.relateSceneAuth
    },
    getUserLimitOptions() {
      return this.userLimitOptions
    },
    getPersonalLimitSelectOptions() {
      return this.personalLimitSelectOptions
    },
  },
  actions: {
    setRightManageTab(params) {
      this.rightManageTab = params
    },
    setRightPkgManageTab(params) {
      this.rightPkgManageTab = params
    },

    setRightType(params) {
      this.rightTypeList = params
    },
    setVoucherType(params) {
      this.voucherTypeList = params
    },
    setAllRightsType(params) {
      this.allRightsTypeList = params
    },
    setPublisher(params) {
      this.publisher = params
    },
    setDepartment(params) {
      this.department = params
    },
    setAllDepartmentTree(params) {
      this.allDepartmentTree = params
    },
    setDepartmentTree(params) {
      this.departmentTree = params
    },
    setMallType(params) {
      this.mallTypeList = params
    },
    setAvailableTerminalOptions(params) {
      this.terminalOptions = params
    },
    setProvinceCitys(params) {
      this.provinceCityList = params
    },
    setCouponCommodityTree(params) {
      this.couponCommodityTreeData = params
    },
    setDistributeInfoData(params) {
      this.distributeInfoData = params
    },
    setRelateScene(params) {
      this.relateScene = params
    },
    setRelateSceneAuth(params) {
      this.relateSceneAuth = params
    },
    setUserLimitOptions(params) {
      this.userLimitOptions = params
    },
    setPersonalLimitSelectOptions(params) {
      this.personalLimitSelectOptions = params
    },

    //原子权益类别获取
    async getTypeList() {
      try {
        const data = await queryAtomicEquityTypeApi()
        const typeList = data.typeList.map((item) => {
          return {
            label: item.name,
            value: item.type,
            disabled: item.hasOwnProperty('isDisplay') ? !item.isDisplay : false,
            candidateSubTypeList: item.candidateSubTypeList?.map((second) => {
              return {
                label: second.name,
                value: second.subType,
                disabled: second.hasOwnProperty('isDisplay') ? !second.isDisplay : false,
              }
            }),
          }
        })
        this.setRightType(typeList)
      } catch (error) {
        console.log('error===', error)
      }
    },

    //券模板权益类别获取
    async getVoucherTypeList() {
      try {
        const data = await queryVoucherTypeApi()
        const typeList = data.typeList.map((item) => {
          return {
            label: item.name,
            value: item.type,
            disabled: item.hasOwnProperty('isDisplay') ? !item.isDisplay : false,
            candidateSubTypeList: item.candidateSubTypeList?.map((second) => {
              return {
                label: second.name,
                value: second.subType,
                disabled: second.hasOwnProperty('isDisplay') ? !second.isDisplay : false,
              }
            }),
          }
        })
        this.setVoucherType(typeList)
      } catch (error) {
        console.log('error===', error)
      }
    },

    //所有权益类别获取
    async getAllRightsTypeList() {
      try {
        const data = await queryAllRightsTypeApi()
        const typeList = data.typeList.map((item) => {
          return {
            label: item.name,
            value: item.type,
            disabled: item.hasOwnProperty('isDisplay') ? !item.isDisplay : false,
            candidateSubTypeList: item.candidateSubTypeList?.map((second) => {
              return {
                label: second.name,
                value: second.subType,
                disabled: second.hasOwnProperty('isDisplay') ? !second.isDisplay : false,
              }
            }),
          }
        })
        this.setAllRightsType(typeList)
      } catch (error) {
        console.log('error===', error)
      }
    },

    //获取发布者数据
    async getPublisherList() {
      try {
        const data = await queryPublisherListApi()
        this.setPublisher(data.publisherEnumList)
      } catch (error) {
        console.log('error===', error)
      }
    },

    //获取部门数据
    async getDepartmentList() {
      try {
        const data = await queryDepartmentApi()
        if (data.childDepartmentInfoList) {
          const departmentList = data.childDepartmentInfoList.map((item) => {
            return {
              label: item.departmentName,
              value: item.departmentCode,
            }
          })
          this.setDepartment(departmentList)
        }
      } catch (error) {
        console.log('error===', error)
      }
    },

    //获取部门树形数据
    async getDepartmentTreeData(params) {
      try {
        const data = await queryDepartmentTreeApi(params)
        if (data.childDepartmentInfoList) {
          if (!params.hasOwnProperty('searchKey')) {
            this.setAllDepartmentTree(data.childDepartmentInfoList)
          }
          this.setDepartmentTree(data.childDepartmentInfoList)
        }
      } catch (error) {
        console.log('error===', error)
      }
    },

    //获取券模板-商城枚举值
    async getMallTypeList() {
      try {
        const data = await queryCouponMallTypeApi()
        const mallList = data?.children || []
        this.setMallType(mallList)
      } catch (error) {
        console.log('error===', error)
      }
    },

    //获取城市信息
    async getProvinceCityList() {
      let list: any[] = []
      try {
        const data = await getProvinceCity({})
        if (data?.length > 0) {
          list = data
        }
        this.setProvinceCitys(list)
      } catch (error) {
        console.log('error===', error)
      }
    },

    //获取核销可用端枚举值
    async getAllAvailableTerminalList() {
      try {
        const data = await queryAllAvailableTerminalApi()
        const clientList =
          data
            ?.filter((item) => item?.value !== 1)
            ?.map((item) => {
              let isDisabled = false
              //禁用能源小程序
              if (item.value === 8) {
                isDisabled = true
              }
              return Object.assign(item, { disabled: isDisabled })
            }) || []
        this.setAvailableTerminalOptions(clientList)
      } catch (error) {
        console.log('error===', error)
      }
    },

    //获取权益包下拉元数据
    async getDistributeInfoList() {
      try {
        const res = await queryDistributeInfoApi()
        this.setDistributeInfoData(res)
      } catch (error) {
        console.log('error===', error)
      }
    },

    // 获取权益&券的可用业务
    async getRelateSceneList(params) {
      try {
        const res = await queryRelateSceneApi(params)
        this.setRelateScene(res?.list || [])
      } catch (error) {
        console.log('error===', error)
      }
    },

    // 获取权益&券的可用业务白名单
    async getRelateSceneAuthList(params) {
      try {
        const res = await querySceneAuthEnableApi(params)
        this.setRelateSceneAuth(res?.authEnable || false)
      } catch (error) {
        console.log('error===', error)
      }
    },

    //获取券-单人领取限制枚举值
    async getUserLimitList() {
      try {
        const data = await queryUserLimitOptionApi()
        const limitList =
          data?.map((item) => {
            return { ...item, label: item?.name, value: item?.key }
          }) || []
        this.setUserLimitOptions(limitList)
      } catch (error) {
        console.log('error===', error)
      }
    },
    //获取 库存池-新建编辑-单人领取限制枚举值
    async getPersonalLimitSelectList() {
      try {
        const data = await queryPersonalLimitSelectListApi()
        const limitList = data.list
        this.setPersonalLimitSelectOptions(limitList)
      } catch (error) {
        console.log('error===', error)
      }
    },
  },
})

// Need to be used outside the setup
export function useRightDataStoreWidthOut() {
  return useRightDataStore(store)
}
