import { defineStore } from 'pinia'
import { store } from '/@/store'

export const useUserCenter = defineStore({
  id: 'userCenter',
  state: () => ({
    files: null,
  }),
  getters: {
    getFiles() {
      return this.files
    },
  },
  actions: {
    setFilesValue(options) {
      this.files = options
    },
  },
})

// Need to be used outside the setup
export function useOperationStoreWidthOut() {
  return useUserCenter(store)
}
