import { defineStore } from 'pinia'
import { store } from '/@/store'
import { queryModelEditionListApi, queryAllRelationApi } from '/@/api/operation'
interface UserState {
  modelRef: {}
  mainImage: string
  vehicleEditionsList: any
  channekEventList: []
  modelInfoList: []
}

// export const useRetainInfoDataStore = defineStore({
export const useConsultDataStore = defineStore({
  id: 'retainInfo',
  state: (): UserState => ({
    modelRef: {},
    mainImage: '',
    vehicleEditionsList: [],
    channekEventList: [],
    modelInfoList: [],
  }),
  getters: {
    getMainImage() {
      return this.mainImage
    },
    getVehicleEditionsList() {
      return this.vehicleEditionsList
    },
    getChannekEventList() {
      return this.channekEventList
    },
    getModelInfoList() {
      return this.modelInfoList
    },
  },
  actions: {
    setMainImage(params) {
      this.mainImage = params
    },
    setVehicleEditionsList(params) {
      this.vehicleEditionsList = params
    },
    setChannekEventList(params) {
      this.channekEventList = params
    },
    setModelInfoList(params = []) {
      return (this.modelInfoList = params)
    },
    /**
     * @description: 获取车型版本
     */
    async getVehicleEditionsListAction(params = {}) {
      const result = await queryModelEditionListApi(params)

      this.setVehicleEditionsList(result)
    },
    /**
     * @description: 获取关联渠道事件
     */
    // channelStatus：查询渠道状态，0-查询所有状态；1-查询上架状态渠道；
    async getChannekEventListAction(params = { channelStatus: 0 }) {
      const data = await queryAllRelationApi(params)
      this.setChannekEventList(data)
    },
  },
})

// Need to be used outside the setup
export function useConsultStoreWidthOut() {
  return useConsultDataStore(store)
}
