import { defineStore } from 'pinia'
import { store } from '/@/store'
export const useActivityManagerDataStore = defineStore({
  id: 'activityManager',
  state: () => ({
    enrollDeadlineType: 0,
  }),
  getters: {
    getEnrollDeadlineType() {
      return this.enrollDeadlineType
    },
  },
  actions: {
    // 将活动报名截止时间类型存储
    setEnrollDeadlineType(params) {
      this.enrollDeadlineType = params
    },
  },
})

// Need to be used outside the setup
export function useActivityManagerDataStoreWidthOut() {
  return useActivityManagerDataStore(store)
}
