import { defineStore } from 'pinia'
import { store } from '/@/store'
import {
  getEnumsApi,
  getResourcePositionForOmContentApi,
  GetVersionChannelList,
  getUserLabelListApi,
  GetChannelEventSearch,
  GetSearchChannelInfos,
} from '/@/api/resource'
interface UserState {
  allEnums: {}
  isDisabled: Boolean
  frequencyEnums: Array<any>
  resourcePositionNameEnums: Array<any>
  userLabelOptions: Array<any>
  versionOptions: Array<any>
  isDownloadDisabled: Boolean
  channelEventSearchList: Array<any>
}

export const useResourceDataStore = defineStore({
  id: 'resource',
  state: (): UserState => ({
    allEnums: {},
    versionOptions: [],
    userLabelOptions: [],
    isDisabled: false,
    isDownloadDisabled: false,
    frequencyEnums: [],
    resourcePositionNameEnums: [],
    channelEventSearchList: [],
  }),
  getters: {
    getAllEnums() {
      return this.allEnums
    },
    getIsDisabled() {
      return this.isDisabled
    },
    getIsDownloadDisabled() {
      return this.isDownloadDisabled
    },
    getFrequencyEnums() {
      return this.frequencyEnums
    },
    getResourcePositionNameEnums() {
      return this.resourcePositionNameEnums
    },
    getVersionOptions() {
      return this.versionOptions
    },
    getUserLabelOptions() {
      return this.userLabelOptions
    },
    getChannelEventSearchList() {
      return this.channelEventSearchList
    },
  },
  actions: {
    setAllEnums(params) {
      this.allEnums = params
    },
    setVersionChannel(params) {
      this.versionOptions = params
    },
    setUserLabelOptions(params) {
      this.userLabelOptions = params
    },
    setDisabled(params) {
      this.isDisabled = params.disabled
    },
    setDownloadDisabled(params) {
      this.isDownloadDisabled = params.disabled
    },
    setFrequencyEnums(params) {
      this.frequencyEnums = params
    },
    setResourcePositionNameEnums(params) {
      this.resourcePositionNameEnums = params
    },
    setChannelEventSearch(params) {
      this.channelEventSearchList = params
    },
    /**
     * @description: 获取用户标签列表
     */
    async getUserLabelOptionsAction(params = {}) {
      const data = await getUserLabelListApi(params)
      this.setUserLabelOptions(data.list)
    },
    /**
     * @description: 模板列表相关枚举 联动前
     */
    async getResourceEnumsAction(params = {}) {
      const data = await getEnumsApi(params)
      this.setAllEnums(data)
    },
    // 根据资源位类型获取投放频次option
    async getFrequencyEnumsAction(params = {}) {
      const data = await getEnumsApi(params)
      this.setFrequencyEnums(data.frequencyEnums)
    },

    // 选择端口、频道、资源位类型后自动过滤可选资源位（选择为「且」关系）
    async getResourcePositionNameEnumsAction(params) {
      console.log(params)
      const data = await getResourcePositionForOmContentApi(params)
      this.setResourcePositionNameEnums(data || [])
    },

    /**
     * @description: 模板列表相关枚举 联动前
     */
    async GetVersionChannelListAction(params = {}) {
      const data = await GetVersionChannelList(params)
      this.setVersionChannel(
        data.map((i) => {
          return {
            label: i.channelSecret,
            value: i.channelSecret,
          }
        }),
      )
    },
    /**
     * @description: 搜索渠道esj列表
     */
    async GetChannelEventSearchAction(params = {}) {
      const data = await GetChannelEventSearch(params)
      this.setChannelEventSearch(
        data.map((v) => {
          return {
            value: v.eventKey,
            label: v.eventName,
            key: v.eventKey,
          }
        }),
      )
    },
    /**
     * @description: 搜索渠道esj列表批量
     */
    async GetSearchChannelInfos(params = {}) {
      const data = await GetSearchChannelInfos(params)
      this.setChannelEventSearch(
        data.map((v) => {
          return {
            value: v.eventKey,
            label: v.eventName,
          }
        }),
      )
    },
  },
})

// Need to be used outside the setup
export function useResourceStoreWidthOut() {
  return useResourceDataStore(store)
}
