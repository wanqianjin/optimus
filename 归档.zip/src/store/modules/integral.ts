import { defineStore } from 'pinia'
import { store } from '/@/store'
import { queryOrganizationList, queryOrganizationChildrenList } from '/@/api/integral'

// 整理部门信息
function mapOrganizationList(organizationList) {
  return organizationList.map((Organization) => {
    const Organization1 = {
      label: '',
      value: 1,
      level: 1,
    }
    Organization1.label = Organization.name
    Organization1.value = Organization.organizationId
    Organization1.level = Organization.level
    return Organization1
  })
}
export const integralBatchDataStore = defineStore({
  id: 'integral-batch-manage',
  state: () => ({
    // 一级部门
    OrganizationOneList: [],
    // 二级部门
    OrganizationTwoList: [],
  }),
  getters: {
    // 获取一级部门
    getOrganizationOneList() {
      const OrganizationOneListData = mapOrganizationList(this.OrganizationOneList)
      return OrganizationOneListData
    },

    // 获取二级部门
    getOrganizationTwoList() {
      const OrganizationTwoListData = mapOrganizationList(this.OrganizationTwoList)
      return OrganizationTwoListData
    },
  },
  actions: {
    setOrganizationOneList(options) {
      this.OrganizationOneList = options
    },
    setOrganizationTwoList(options) {
      this.OrganizationTwoList = options
    },
    // 清空二级列表
    ResetOrganizationTwoList() {
      this.OrganizationTwoList = []
    },
    /** 获取一级部门信息
     */
    async getOrganizationOneListAction() {
      const data = await queryOrganizationList({ level: 1 })
      this.setOrganizationOneList(data)
      return data
    },
    /** 获取二级部门信息
     */
    async getOrganizationTwoListAction(organizationId) {
      const data = await queryOrganizationChildrenList({ parentId: organizationId })
      this.setOrganizationTwoList(data)
      return data
    },
  },
})
// Need to be used outside the setup
export function integralBatchDataStoreWidthOut() {
  return integralBatchDataStore(store)
}
