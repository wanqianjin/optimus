import { defineStore } from 'pinia'
import { store } from '/@/store'
import { activityTypeEnumApi, projectEnumApi } from '/@/api/marketingCenter'
interface UserState {
  activityTypeEnum: Array
  projectEnum: Array
}
function transferArray(item, labelName = 'desc', valueName = 'code', keyCode = 'desc') {
  return item && item.map((v) => ({ label: v[labelName], value: v[valueName], key: v[keyCode] }))
}

export const useMarketingCenterDataStore = defineStore({
  id: 'marketingCenter',
  state: (): UserState => ({
    activityTypeEnum: [],
    projectEnum: [], //项目
  }),
  getters: {
    getActivityTypeEnum() {
      return this.activityTypeEnum
    },
    getProjectEnum() {
      return this.projectEnum
    },
  },
  actions: {
    // 将活动类型存储
    async setActivityTypeEnumAction(params = {}) {
      const data = await activityTypeEnumApi(params)
      this.activityTypeEnum = transferArray(
        data,
        'activityTypeName',
        'activityType',
        'activityType',
      )
    },
    // 项目列表
    async setProjectEnumAction(params = {}) {
      const data = await projectEnumApi(params)
      this.projectEnum = data
    },
  },
})

// Need to be used outside the setup
export function useMarketingCenterStoreWidthOut() {
  return useMarketingCenterDataStore(store)
}
