import { defineStore } from "pinia";
import { store } from "/@/store";

export const useCarControlConfigStore = defineStore({
  id: 'carControlConfig',
  state: () => ({
    part: [], //分区枚举
    vehicleMode: [], //车型枚举
    specialPerm: [], //特殊权限枚举
  }),
  getters: {
    getPart() {
      return this.part
    },
    getVehicleMode() {
      return this.vehicleMode
    },
    getSpecialPerm() {
      return this.specialPerm
    }
  },
  actions: {
    setPart(options) {
      this.part = options
    },
    setVehicleMode(options) {
      this.vehicleMode = options
    },
    setSpecialPerm(options) {
      this.specialPerm = options
    },
  }
})

export function useCarCtrlConfigWithOut() {
  return useCarControlConfigStore(store)
}