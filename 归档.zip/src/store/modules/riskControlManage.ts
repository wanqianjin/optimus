import { defineStore } from 'pinia'
import { store } from '/@/store'
import * as Api from '/@/api/message/riskControlManage'

interface UserState {
  // 短信邮件
  riskNameRiskType: []
  riskNameBizType: []
  notificationType: []
  notificationSubType: []
  riskBizLimitTypeInfo: []
  bizAppType: []
  // push
  appType: []
  pushRiskNameRiskType: []
  pushNotificationType: []
  pushNotificationSubType: []
}

function transferArray(item, labelName = 'desc', valueName = 'code', keyCode = 'desc') {
  return (
    item && item.map((v) => ({ label: v[labelName], value: v[valueName] + '', key: v[keyCode] }))
  )
}

export const useRiskControlManageDataStore = defineStore({
  id: 'useRiskControlManage',
  state: (): UserState => ({
    // 短信邮件
    riskNameRiskType: [],
    riskNameBizType: [],
    notificationType: [],
    notificationSubType: [],
    riskBizLimitTypeInfo: [],
    bizAppType: [],

    // Push
    appType: [],
    pushRiskNameRiskType: [],
    pushNotificationType: [],
    pushNotificationSubType: [],
  }),
  getters: {
    // 短信/邮件s
    getRiskNameRiskType() {
      return this.riskNameRiskType
    },
    getRiskNameBizType() {
      return this.riskNameBizType
    },
    getNotificationType() {
      return this.notificationType
    },
    getNotificationSubType() {
      return this.notificationSubType
    },
    getRiskBizLimitTypeInfo() {
      return this.riskBizLimitTypeInfo
    },
    getBizAppType() {
      return this.bizAppType
    },

    // Push
    getAppType() {
      return this.appType
    },
    getPushRiskNameRiskType() {
      return this.pushRiskNameRiskType
    },
    getPushNotificationType() {
      return this.pushNotificationType
    },
    getPushNotificationSubType() {
      return this.pushNotificationSubType
    },
  },
  actions: {
    // 短信/邮件
    setRiskNameRiskType(options) {
      this.riskNameRiskType = options
    },
    setRiskNameBizType(options) {
      this.riskNameBizType = options
    },
    setNotificationType(options) {
      this.notificationType = options
    },
    setNotificationSubType(options) {
      this.notificationSubType = options
    },
    setRiskBizLimitTypeInfo(options) {
      this.riskBizLimitTypeInfo = options
    },
    setBizAppType(options) {
      this.bizAppType = options
    },

    /**
     * @description:  获取黑白名单枚举类别（短信/邮件）
     */
    async getRiskNameRiskTypeInfoAction() {
      const res = await Api.getRiskNameRiskTypeInfoApi({})
      this.setRiskNameRiskType(transferArray(res))
    },
    /**
     * @description: 获取黑白名单所属通道子类型（短信/邮件）
     */
    async getRiskNameBizTypeInfoAction() {
      const res = await Api.getRiskNameBizTypeInfoApi({})
      this.setRiskNameBizType(transferArray(res))
    },

    /**
     * @description: 联动获取通道类型、通道子类型 （短信/邮件）
     */
    async getNotificationTypeInfoAction() {
      const res = await Api.getNotificationTypeInfoApi()
      const list = transferArray(res)?.filter((v) => {
        // 风控管理只展示短信/邮件
        return v.value === '1' || v.value === '3'
      })

      this.setNotificationType(list)

      return res
    },
    async getNotificationSubTypeInAction(relation) {
      const res = await Api.getNotificationSubTypeInfoApi({ relation })
      this.setNotificationSubType(transferArray(res))
      return res
    },
    // 获取所属维度
    async getRiskBizLimitTypeInfoAction() {
      const res = await Api.getRiskBizLimitTypeInfoApi()
      this.setRiskBizLimitTypeInfo(transferArray(res))
      return res
    },
    // 阈值业务线
    async queryEnumBizConfigAction() {
      const res = await Api.queryEnumBizConfigApi()
      this.setBizAppType(transferArray(res, 'name', 'bizAppId', 'name'))
      return res
    },

    // ----------------------------------------Push----------------------------
    // push
    setAppType(options) {
      this.appType = options
    },
    setPushRiskNameRiskType(options) {
      this.pushRiskNameRiskType = options
    },
    setPushNotificationType(options) {
      this.pushNotificationType = options
    },
    setPushNotificationSubType(options) {
      this.pushNotificationSubType = options
    },
    /**
     * @description: push端类型枚举（Push）
     */
    async getAppTypeInfoAction() {
      const res = await Api.getAppTypeInfoApi({})
      this.setAppType(transferArray(res.data))
    },
    /**
     * @description: push端类型枚举（Push）
     */
    async getPushRiskNameRiskTypeInfoAction() {
      const res = await Api.getPushRiskNameRiskTypeInfoApi({})
      this.setPushRiskNameRiskType(transferArray(res.data))
    },
    /**
     * @description: 获取（通道）消息类型（Push）
     */
    async getPushNotificationTypeInfoAction() {
      const res = await Api.getPushNotificationTypeInfoApi({})
      this.setPushNotificationType(transferArray(res.data))
    },
    /**
     * @description: 获取（通道）消息子类型（Push）
     */
    async getPushNotificationSubTypeInfoAction(relation) {
      const res = await Api.getPushNotificationSubTypeInfoApi({ relation })
      this.setPushNotificationSubType(transferArray(res.data))
    },
  },
})

// Need to be used outside the setup
export function useRiskControlManageStoreWidthOut() {
  return useRiskControlManageDataStore(store)
}
