import { defineStore } from 'pinia'
import { store } from '/@/store'
import {
  queryChannelNameApi,
  getEventTypeListApi,
  queryProjectNameApi,
  queryAllRelationApi,
  queryProjectActivityApi,
  getDepartmentApi,
  getClientApi,
  getMarketingFlagApi,
  getProjectTypeApi,
  getCostTypeApi,
  getApolloDataApi,
  getCityShopApi,
  queryGroupByUserApi,
  queryAllThirdProjectApi,
} from '/@/api/channel'
import * as Api from '/@/api/channel/project'
import { GetHumanUserApi } from '/@/api/integral/batchGrant' //获取人员信息
import { getFullGroupTreeApi } from '/@/api/integral' //获取全量组织机构
import { getProvinceCity } from '/@/api/activityRegister' //城市接口
export const useChannelDataStore = defineStore({
  id: 'channel',
  state: () => ({
    rootChannelList: [], //一级渠道
    eventTypeList: [], //所属业务类型
    channelProjectIdList: [], //项目list
    channekEventList: [],
    activityIdList: [], //活动级联
    departmentList: [], //部门
    clientList: [], //端
    marketingList: [], //营销活动
    projectTypeList: [], //项目类型
    costTypeList: [], //费用类型
    humanUserList: [], //人员信息
    fullGroupList: [], //全量组织架构
    groupByUserList: [], //条件查询组织架构
    apolloData: {}, //apollo 所有配置
    cityList: [], //城市
    cityShopList: [], //门店
    projectRelationList: [], //全部项目树
    associatedProjectByLevelList: [], //已通过审批项目树
    allThirdProjectList: [], //包含未审批的三级项目树
    projectConcreteTypeList: [], //二级项目类型
    projectCostTypeList: [], //三级级项目费用类型
    projectTargetTypeList: [], //三级项目指标类型
    projectRegionTypeList: [], //三级项目区域类型
    secondProjectRegionTypeList: [], //二级项目区域类型
  }),
  getters: {
    getRootChannel() {
      return this.rootChannelList
    },

    getEventTypeList() {
      return this.eventTypeList
    },
    getChannelProjectIdList() {
      return this.channelProjectIdList
    },

    getChannekEventList() {
      return this.channekEventList
    },
    getActivityIdList() {
      return this.activityIdList
    },
    getDepartmentList() {
      return this.departmentList
    },
    getClientList() {
      return this.clientList
    },
    getMarketingList() {
      return this.marketingList
    },
    getProjectTypeList() {
      return this.projectTypeList
    },
    getCostTypeList() {
      return this.costTypeList
    },
    getHumanUserList() {
      return this.humanUserList
    },

    getGroupByUserList() {
      return this.groupByUserList
    },
    getFullGroupList() {
      return this.fullGroupList
    },
    getApolloData() {
      return this.apolloData
    },
    getCityList() {
      return this.cityList
    },
    getCityShopList() {
      return this.cityShopList
    },
    getProjectRelationList() {
      return this.projectRelationList
    },
    getAssociatedProjectByLevelList() {
      return this.associatedProjectByLevelList
    },
    getAllThirdProjectList() {
      return this.allThirdProjectList
    },
    getProjectConcreteTypeList() {
      return this.projectConcreteTypeList
    },
    getProjectCostTypeList() {
      return this.projectCostTypeList
    },
    getProjectTargetTypeList() {
      return this.projectTargetTypeList
    },
    getProjectRegionTypeList() {
      return this.projectRegionTypeList
    },
    getSecondProjectRegionTypeList() {
      return this.secondProjectRegionTypeList
    },
  },

  actions: {
    setRootChannel(options) {
      this.rootChannelList = options
    },
    setEventTypeList(options) {
      this.eventTypeList = options
    },
    setChannelProjectIdList(options) {
      this.channelProjectIdList = options
    },

    setChannekEventList(params) {
      this.channekEventList = params
    },
    setActivityIdList(params) {
      this.activityIdList = params
    },
    setDepartmentList(params) {
      this.departmentList = params
    },
    setClientList(params) {
      this.clientList = params
    },
    setMarketingList(params) {
      this.marketingList = params
    },
    setProjectTypeList(params) {
      this.projectTypeList = params
    },
    setCostTypeList(params) {
      this.costTypeList = params
    },
    setHumanUserList(params) {
      this.humanUserList = params
    },
    setGroupByUserList(params) {
      this.groupByUserList = params
    },
    setFullGroupList(params) {
      this.fullGroupList = params
    },
    setApolloData(params) {
      this.apolloData = params
    },
    setCityList(params) {
      this.cityList = params
    },
    setCityShopList(params) {
      this.cityShopList = params
    },
    setProjectRelationList(params) {
      this.projectRelationList = params
    },
    setAssociatedProjectByLevelList(params) {
      this.associatedProjectByLevelList = params
    },
    setAllThirdProjectList(params) {
      this.allThirdProjectList = params
    },
    setProjectConcreteTypeList(params) {
      this.projectConcreteTypeList = params
    },

    setProjectCostTypeList(params) {
      this.projectCostTypeList = params
    },
    setProjectTargetTypeList(params) {
      this.projectTargetTypeList = params
    },
    setProjectRegionTypeList(params) {
      this.projectRegionTypeList = params
    },
    setSecondProjectRegionTypeList(params) {
      this.secondProjectRegionTypeList = params
    },
    /**
     * @description: 获取一级渠道
     */
    async getRootChannelListAction() {
      const result = await queryChannelNameApi({ channelType: 1, channelLevel: 1 }) //channelType=1且channelLevel=1，会返回所有【一级渠道名称】；
      this.setRootChannel(result)
    },
    /**
     * @description: 获取业务类型
     */
    async getEventTypeListAction() {
      const result = await getEventTypeListApi({})
      this.setEventTypeList(result.eventTypeList)
    },
    /**
     * @description: .查询项目名称列表
     */
    async getChannelProjectIdListAction() {
      const result = await queryProjectNameApi({})
      this.setChannelProjectIdList(result)
    },
    /**
     * @description: .查询项目 活动 级联列表
     */
    async getActivityIdListAction() {
      const result = await queryProjectActivityApi({})
      // result?.unshift({
      //   projectActivityName: '无',
      //   projectActivityId: '0',
      //   projectActivityResponseList: [],
      // }) //给旧数据添加【无】选项
      this.setActivityIdList(result)
    },
    /**
     * @description: .查询部门列表
     */
    async getDepartmentListAction() {
      const result = await getDepartmentApi({})
      this.setDepartmentList(result.departments)
    },
    /**
     * @description: .查询端
     */
    async getClientListAction() {
      const result = await getClientApi({})
      this.setClientList(result.clients)
    },
    /**
     * @description: .查询营销活动
     */
    async getMarketingListAction() {
      const result = await getMarketingFlagApi({})
      this.setMarketingList(result.marketingFlagList)
    },
    /**
     * @description: .查询项目类型
     */
    async getProjectTypeListAction() {
      const result = await getProjectTypeApi({})
      this.setProjectTypeList(result.projectTypeList)
    },
    /**
     * @description: .查询费用类型
     */
    async getCostTypeListAction() {
      const result = await getCostTypeApi({})
      this.setCostTypeList(result.costTypeList)
    },
    /**
     * @description: .查询人员信息
     */
    async getHumanUserListAction() {
      const result = await GetHumanUserApi({})
      this.setHumanUserList(result)
    },
    /**
     * @description: .根据人员查询组织架构
     */
    async getGroupByUserAction(params = { user: [] }) {
      const result = await queryGroupByUserApi(params)
      this.setGroupByUserList(result)
    },
    /**
     * @description: .全量组织架构
     */
    async getFullGroupTreeAction() {
      const result = await getFullGroupTreeApi({})
      this.setFullGroupList(result)
    },
    /**
     * @description: .查询Apollo所有配置
     */
    async getApolloDataAction(apolloKeyList: []) {
      const result = await getApolloDataApi({ apolloKeyList })
      this.setApolloData(result)
    },
    /**
     * @description: 查询所有城市
     */
    async getProvinceCityAction() {
      const result = await getProvinceCity({})
      this.setCityList(result)
    },
    /**
     * @description: 查询所有城市门店
     */
    async getCityShopAction(params) {
      const result = await getCityShopApi(params)
      this.setCityShopList(result)
    },
    /**
     * @description: 查询全部项目树
     */
    async getProjectRelationAction(params) {
      const result = await Api.queryProjectRelationByLevelApi(params)
      this.setProjectRelationList(result)
    },
    /**
     * @description: 查询已通过审批项目树
     */
    async getAssociatedProjectByLevelAction(params) {
      const result = await Api.queryAssociatedProjectByLevelApi(params)
      this.setAssociatedProjectByLevelList(result)
    },
    /**
     * @description: 查询全部项目树（包含未审批）
     */
    async getAllThirdProjectListAction(params) {
      const result = await queryAllThirdProjectApi(params)
      this.setAllThirdProjectList(result)
    },
    /**
     * @description: 二级项目配置
     */
    async getProjectConcreteTypeListAction(params) {
      const result = await Api.getConfigInfoApi(params)
      this.setProjectConcreteTypeList(result.secondProjectTypeList)
      this.setSecondProjectRegionTypeList(result.secondProjectRegionTypeList)
      this.setProjectCostTypeList(result.thirdProjectCostTypeList)
      this.setProjectTargetTypeList(result.thirdProjectTargetTypeList)
      this.setProjectRegionTypeList(result.thirdProjectRegionTypeList)
    },
    /**
     * @description: 获取关联渠道事件
     */
    // channelStatus：查询渠道状态，0-查询所有状态；1-查询上架状态渠道；
    async getChannekEventListAction(params = { channelStatus: 0 }) {
      const data = await queryAllRelationApi(params)
      this.setChannekEventList(data)
    },
  },
})

// Need to be used outside the setup
export function useChannelStoreWidthOut() {
  return useChannelDataStore(store)
}
