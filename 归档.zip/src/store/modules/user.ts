import type { UserInfo } from '/#/store'

import { defineStore } from 'pinia'
import { store } from '/@/store'
import { RoleEnum } from '/@/enums/roleEnum'
import { ROLES_KEY, TOKEN_KEY, USER_INFO_KEY } from '/@/enums/cacheEnum'
import { getAuthCache, setAuthCache } from '/@/utils/auth'
import { getUserInfo, getUserPermission } from '/@/api/sys/user'
import { useI18n } from '/@/hooks/web/useI18n'
import { useMessage } from '/@/hooks/web/useMessage'
import { h } from 'vue'
import { useGlobSetting } from '/@/hooks/setting'
import { openWindow } from '/@/utils'

// import { router } from '/@/router'

const globSetting = useGlobSetting()
const { createMessage } = useMessage()

interface UserState {
  userInfo: Nullable<UserInfo>
  token?: string
  roleList: RoleEnum[]
  sessionTimeout?: boolean
  lastUpdateTime: number
  homePath?: string
  allRoutes: []
  menuRoutes: []
  permissionEnum: []
  actPermissionEnum: []
}

export const useUserStore = defineStore({
  id: 'app-user',
  state: (): UserState => ({
    // user info
    userInfo: null,
    // token
    token: undefined,
    // roleList
    roleList: [],
    // Whether the login expired
    sessionTimeout: false,
    // Last fetch time
    lastUpdateTime: 0,
    // 用户路由权限首页
    homePath: undefined,
    // 用户能访问的所有路由
    allRoutes: [],
    // 菜单中要显示的路由，从allRouter的hideMenu属性过滤
    menuRoutes: [],
    // 用户有的操作权限
    permissionEnum: [],
    // 用户有的操作权限(包含配置act数据权限)
    actPermissionEnum: [],
  }),
  getters: {
    getUserInfo(): UserInfo {
      return this.userInfo || getAuthCache<UserInfo>(USER_INFO_KEY) || {}
    },
    getToken(): string {
      return this.token || getAuthCache<string>(TOKEN_KEY)
    },
    getRoleList(): RoleEnum[] {
      return this.roleList.length > 0 ? this.roleList : getAuthCache<RoleEnum[]>(ROLES_KEY)
    },
    getSessionTimeout(): boolean {
      return !!this.sessionTimeout
    },
    getLastUpdateTime(): number {
      return this.lastUpdateTime
    },
    getHomePath(): string | undefined {
      return this.homePath
    },
    getAllRoutes(): [] {
      return this.allRoutes || []
    },
    getMenuRoutes(): [] {
      return this.menuRoutes || []
    },
    getPermissionEnum(): string[] {
      return this.permissionEnum || []
    },
    getActPermissionEnum(): any[] {
      return this.actPermissionEnum || []
    },
  },
  actions: {
    setToken(info: string | undefined) {
      this.token = info ? info : '' // for null or undefined value
      setAuthCache(TOKEN_KEY, info)
    },
    setRoleList(roleList: RoleEnum[]) {
      this.roleList = roleList
      setAuthCache(ROLES_KEY, roleList)
    },
    setUserInfo(info: UserInfo | null) {
      this.userInfo = info
      this.lastUpdateTime = new Date().getTime()
      setAuthCache(USER_INFO_KEY, info)
    },
    setSessionTimeout(flag: boolean) {
      this.sessionTimeout = flag
    },
    setHomePath(path: string) {
      this.homePath = path
    },
    resetState() {
      this.userInfo = null
      this.token = ''
      this.roleList = []
      this.sessionTimeout = false
    },
    async getUserInfoAction(): Promise<Object | null> {
      if (!this.getToken) return null
      try {
        const userInfo = await getUserInfo()
        this.setUserInfo(userInfo)
        return userInfo
      } catch (error: any) {
        // 这里是异常情况比如503等，
        if (!error.code) {
          console.error('获取用户信息失败')
          createMessage.error('获取用户信息失败')
        }
      }
    },
    /**
     * @description: logout
     */
    async logout(goLogin = false, redirectUrl = location.href) {
      this.setToken(undefined)
      this.setSessionTimeout(false)
      this.setUserInfo(null)

      if (goLogin) {
        const appId = globSetting.appId
        // 登出后回跳地址为登录，登录后回跳当前页面
        // 如果url上有token参数，需要处理掉，避免pass获取到过期的token
        const tokenReg = /[&]?token=[^&#?]+/g
        redirectUrl = redirectUrl.replace(tokenReg, '')

        const passportUrl = globSetting.passportUrl
        const loginUrl =
          `${passportUrl}/authorize?response_type=token&client_id=${appId}&redirect_uri=` +
          encodeURIComponent(redirectUrl)
        const openUrl = `${passportUrl}/logout?redirect=` + encodeURIComponent(loginUrl)
        openWindow(openUrl, { target: '_self' })
      }
    },

    /**
     * @description: Confirm before logging out
     */
    confirmLoginOut() {
      const { createConfirm } = useMessage()
      const { t } = useI18n()
      createConfirm({
        iconType: 'warning',
        title: () => h('span', t('sys.app.logoutTip')),
        content: () => h('span', t('sys.app.logoutMessage')),
        onOk: async () => {
          await this.logout(true)
        },
      })
    },
    setAllRoutes(routes) {
      this.allRoutes = routes || []
    },
    setPermissionEnum(permissionEnum) {
      this.permissionEnum = permissionEnum || []
    },
    setActPermissionEnum(actPermissionEnum) {
      this.actPermissionEnum = actPermissionEnum || []
    },
    /**
     * @description: 拉取权限信息
     */
    async getPermissionRoutesAction() {
      try {
        // 拉取权限信息，对路由进行过滤
        const resPermission = await getUserPermission({
          resourceType: [1, 2], // 菜单和按钮权限
        })
        const permission: string[] = []
        const actPermission: any[] = []
        resPermission?.resource?.forEach((item) => {
          if ([1, 2].includes(+item.resource_type)) {
            permission.push(item.code)
            actPermission.push({
              act: item.act,
              code: item.code,
            })
          }
        })

        // // 如果没有菜单权限，可跳转到无权限页面或者404等，业务逻辑自行处理，返回了[]过滤出有权限的路由也为[]，路由守卫统一处理了跳转到无权限页面
        // if (!permission || (permission && permission.length === 0)) {
        //   router.replace({ path: '/unauth' }) // 路由守卫统一处理了
        //   return []
        // }

        // 按钮操作和tab是否展示的权限
        this.setPermissionEnum(permission)
        // 包含菜单配置的act权限（数据权限）
        this.setActPermissionEnum(actPermission)

        return permission
      } catch (error: any) {
        if (!error.code) {
          console.error('获取用户权限信息失败') // 比如接口503
          createMessage.error('获取用户权限信息失败')
        }
      }
    },
  },
})

// Need to be used outside the setup
export function useUserStoreWithOut() {
  return useUserStore(store)
}
