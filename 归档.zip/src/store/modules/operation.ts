import { defineStore } from 'pinia'
import { store } from '/@/store'
import { getTabsListApi } from '/@/api/operation'

export const useOperationDataStore = defineStore({
  id: 'operation',
  state: () => ({
    tabsOptionsList: [],
  }),
  getters: {
    getTabsOptionsList() {
      return this.tabsOptionsList
    },
  },
  actions: {
    setTabsOptionsList(options) {
      this.tabsOptionsList = options
    },

    /**
     * @description: 获取apollo配置 tab信息
     */
    async getTabsOptionsListAction() {
      const data = await getTabsListApi({})
      this.setTabsOptionsList(data.tabInfoApollo)
    },
  },
})

// Need to be used outside the setup
export function useOperationStoreWidthOut() {
  return useOperationDataStore(store)
}
