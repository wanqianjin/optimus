import { defineStore } from 'pinia'
import { store } from '/@/store'
import { queryPlatformApi, getAgreementManagerOptions } from '/@/api/agreementManage'

export const useAgreementDataStore = defineStore({
  id: 'agreementManage',
  state: () => ({
    channelList: [],
    agreementManagerOptions: [],
    contractStatus: [
      {
        label: '已失效',
        value: 0,
      },
      {
        label: '待发布',
        value: 1,
      },
      {
        label: '生效中',
        value: 2,
      },
    ],
  }),
  getters: {
    getChannelType() {
      return this.channelList
    },
    getContractStatus() {
      return this.contractStatus
    },
    getAgreementManagerOptions() {
      return this.agreementManagerOptions
    },
  },
  actions: {
    setChannelType(params) {
      this.channelList = params
    },

    /**
     * 判断时间前小于10时是否需要添加0来填补
     */
    isZero(value) {
      if (value < 10) {
        return `0${value}`
      } else {
        return value
      }
    },

    /**
     * 时间戳转换
     */
    transformTime(timestamp) {
      if (timestamp) {
        const myDate = new Date(timestamp)
        const year = myDate.getFullYear()
        const month = this.isZero(myDate.getMonth() + 1)
        const day = this.isZero(myDate.getDate())

        const hour = this.isZero(myDate.getHours())
        const minite = this.isZero(myDate.getMinutes())
        const second = this.isZero(myDate.getSeconds())
        return `${year}-${month}-${day} ${hour}:${minite}:${second}`
      }
    },

    async getPlatform() {
      try {
        const data = await queryPlatformApi({})
        this.setChannelType(data.platformList)
      } catch (error) {
        console.log('error===', error)
      }
    },

    async setAgreementManagerOptions(userName) {
      try {
        const data = await getAgreementManagerOptions({ userName })
        this.agreementManagerOptions = data.list
      } catch (error) {
        console.log('error===', error)
      }
    },

    transformPlatform(value) {
      let list: any[] = []

      //传入的platform可能是单个值或以逗号分隔的字符串
      if (value === '') {
        return list
      } else if (String(value).includes(',')) {
        list = String(value).split(',')
      } else {
        list = [String(value)]
      }
      const data: any[] = list.map((item) => {
        let res = ''
        //带有‘-’则表示值为：platform-channel
        const keyList = item.split('-')
        const platform = this.getChannelType.filter(
          (platformItem) => platformItem.value === Number(keyList[0].trim()),
        )

        if (item.includes('-')) {
          const channelItem = platform[0]?.platformChannelResponseList.filter(
            (channel) => channel.channelValue === Number(keyList[1].trim()),
          )
          res = `${platform?.[0]?.label}-${channelItem?.[0]?.channelLabel}`
        } else {
          res = platform[0]?.label
        }
        return res
      })
      return data
    },

    /**
     * 获取对应平台-渠道的版本值
     * @description: 通过传入平台-渠道数组值来获取平台-渠道的版本值，最终值形态以map呈现，若平台存在渠道，则key为平台-渠道；若平台不存在渠道，则key为平台。最终value表示为版本值
     * @param params 传参
     */
    getPlatChannel(platformList) {
      const platChannel = new Map()
      platformList.forEach((item) => {
        let version = ''
        if (item.version?.vcList) {
          const versionDescriptions = item?.version?.vcList?.map((obj) => {
            const conditions = []
            if (obj.gt) {
              conditions.push(`版本号 > ${obj.gt}`)
            }
            if (obj.gte) {
              conditions.push(`版本号 >= ${obj.gte}`)
            }
            if (obj.lt) {
              conditions.push(`版本号 < ${obj.lt}`)
            }
            if (obj.lte) {
              conditions.push(`版本号 <= ${obj.lte}`)
            }
            return conditions.join(' 且 ')
          })
          version = versionDescriptions?.join(' 或 ')
        } else {
          version = '全部版本'
        }

        //其中channel=0主要是兼容老数据存在，若为0表示其是老数据，要判断平台是否存在渠道；若不为0则是新添加/修改的数据，对应的key肯定表示为平台-渠道
        if (item.channel === 0) {
          const platformData = this.getChannelType.filter(
            (platformItem) => platformItem.value === item.platform,
          )
          if (
            platformData[0]?.platformChannelResponseList &&
            platformData[0]?.platformChannelResponseList.length > 0
          ) {
            platformData[0].platformChannelResponseList.forEach((c) => {
              if (!platChannel.has(`${item.platform}-${c.channelValue}`)) {
                platChannel.set(`${item.platform}-${c.channelValue}`, version)
              }
            })
          } else {
            platChannel.set(item.platform, version)
          }
        } else {
          if (platChannel.has(`${item.platform}-${item.channel}`)) {
            platChannel.delete(`${item.platform}-${item.channel}`)
          }
          platChannel.set(`${item.platform}-${item.channel}`, version)
        }
      })
      return platChannel
    },
  },
})

// Need to be used outside the setup
export function useAgreementDataStoreWidthOut() {
  return useAgreementDataStore(store)
}
