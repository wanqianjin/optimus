import { defineStore } from 'pinia'
import { getSaleCarInfoApi } from '/@/api/cms/index'
import { message } from '@jidu/robot-ui'

export const useCMSPageStore = defineStore('retentionStatus', {
  state: () => {
    return {
      retentionStatus: 'before', // 留资前 before 留资后 after 已试驾 drived
      common: {
        carModelList: [
          {
            carModelId: 'AA',
            carModelName: 'ROBO-01',
          },
          {
            carModelId: 'AB',
            carModelName: 'ROBO-02',
          },
        ],
      },
      com63: {
        activeKey: 'AA',
      },
      com38: {
        activeKey: 'AA',
      },
    }
  },
  actions: {
    setRetentionStatus(key: any) {
      this.retentionStatus = key
    },
    setComActiveKey(comId, value) {
      this[`com${comId}`].activeKey = value
    },
    async getSaleCarInfo(comId: number | string, cb?: Function) {
      try {
        const { code, msg, data } = await getSaleCarInfoApi()
        if (code === 0) {
          this.common.carModelList = data
          this[`com${comId}`].activeKey = data[0].carModelId
          cb && cb(data)
        } else {
          message.error(msg)
        }
      } catch (error) {
        console.log(error)
      }
    },
  },
})
