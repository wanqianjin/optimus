import { setPerformance } from '/@/utils/track'

const calculateTime = (url, startTime) => {
  if (!url || !startTime) {
    return
  }
  const image = new Image()
  const imageUrl = url
  image.onload = () => {
    setPerformance('pageAvailable', {
      startTime,
      endTime: Date.now(),
    })
  }
  image.onerror = () => {
    console.error(`Failed to load image '${imageUrl}'`)
  }
  image.src = imageUrl
}

const imageLoadTimeDirective = {
  mounted(el, binding) {
    if (window.performance) {
      const performance = window.performance || window.webkitPerformance
      if (performance.timing && performance.timing.navigationStart) {
        const navigationStart = performance.timing.navigationStart
        if (
          sessionStorage.getItem('page_available_time') &&
          sessionStorage.getItem('page_available_time') == navigationStart
        ) {
          return
        }
        sessionStorage.setItem('page_available_time', navigationStart)

        const imgURL = binding.value ? binding.value : el.src
        calculateTime(imgURL, navigationStart)
      }
    }
  },
}

export function setupImageLoadTimeDirective(app) {
  app.directive('image-load-time', imageLoadTimeDirective)
}

export default imageLoadTimeDirective
