import 'virtual:windi-base.css'
import 'virtual:windi-components.css'
import '/@/design/index.less'
import 'virtual:windi-utilities.css'
// Register icon sprite
import 'virtual:svg-icons-register'
import App from './App.vue'
import { createApp } from 'vue'
import { initAppConfigStore } from '/@/logics/initAppConfig'
import { setupErrorHandle } from '/@/logics/error-handle'
import { router, setupRouter } from '/@/router'
import { setupRouterGuard } from '/@/router/guard'
import { setupStore } from '/@/store'
import { setupGlobDirectives } from '/@/directives'
import { setupI18n } from '/@/locales/setupI18n'
import { registerGlobComp } from '/@/components/registerGlobComp'
import * as sentry from '@sentry/vue'
import { BrowserTracing } from '@sentry/tracing'
import { createLocalStorage } from '/@/utils/cache'
import { APP_LOCAL_CACHE_KEY } from '/@/enums/cacheEnum'
import { sentryInit } from '@jidutool/utils-sentry'

async function bootstrap() {
  const app = createApp(App)

  if (import.meta.env.VITE_APP_ENV !== 'prod' || sessionStorage.getItem('getConsoleError')) {
    app.config.errorHandler = (error, instance, info) => {
      console.error(error, instance, info)
    }
  }

  // const sentryUrl =
  //   import.meta.env.VITE_APP_ENV === 'prod' ? 'sentry.jiduapp.cn' : 'sentry.jidudev.com'
  sentryInit({
    sentry,
    app,
    dsn: `https://1fdf3e72dd05d417ed4a0e986e143b85@sentry-fe.jiduapp.cn/6'`,
    integrations: [
      new BrowserTracing({
        routingInstrumentation: sentry.vueRouterInstrumentation(router),
        tracingOrigins: ['localhost', 'my-site-url.com', /^\//],
      }),
    ],
    // Set tracesSampleRate to 1.0 to capture 100%
    // of transactions for performance monitoring.
    // We recommend adjusting this value in production
    tracesSampleRate: 1.0,

    // 环境
    environment: import.meta.env.VITE_APP_ENV,
    enabled: process.env.NODE_ENV === 'production',
    release: `optimus@${import.meta.env.VITE_APP_ENV}${__BUILD_TIME__}`,
    initialScope: {
      user: {
        username:
          createLocalStorage().get(APP_LOCAL_CACHE_KEY)?.value?.USER__INFO__?.value?.userName,
      },
    },
  })
  // Configure store
  setupStore(app)

  // Initialize internal system configuration
  initAppConfigStore()

  // Register global components
  registerGlobComp(app)

  // Multilingual configuration
  // Asynchronous case: language files may be obtained from the server side
  await setupI18n(app)

  // Configure routing
  setupRouter(app)

  // router-guard
  setupRouterGuard(router)

  // Register global directive
  setupGlobDirectives(app)

  // Configure global error handling
  setupErrorHandle(app)

  // https://next.router.vuejs.org/api/#isready
  // await router.isReady();

  app.mount('#app')
}

bootstrap()
