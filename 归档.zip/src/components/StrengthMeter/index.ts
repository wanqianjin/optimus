import { withInstall } from '/@/utils'
import strengthMeter from './src/StrengthMeter.vue'

export const StrengthMeter = withInstall(strengthMeter)
