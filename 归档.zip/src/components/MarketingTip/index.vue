<template>
  <div>
    <Tip
      v-for="item in showMarketingList"
      :key="item"
      :left="tipList[item]?.left"
      :right="tipList[item]?.right"
    />
  </div>
</template>

<script setup>
import Tip from './tip.vue'
import { computed } from 'vue'

const props = defineProps({
  path: {
    type: String,
    default: '',
  },
})

const tipList = {
  mgm: {
    left: '<span>配置活动前，请先<a href="https://jiduauto.feishu.cn/wiki/OFoew0dZei0D7xk7yzgcbKD2nQe" target="_blank">查看完整配置地图</a>，依据checklist检查活动配置的前置项是否已完成</span>',
    right:
      '<a href="https://jiduauto.feishu.cn/wiki/EDe7wgcAwiKqvpkePAKcubwZnQf" target="_blank">活动操作手册</a>',
  },
  register: {
    left: '<span>配置活动前，请先<a href="https://jiduauto.feishu.cn/wiki/IaomwBGLKi3MlKktoC8cGmHUnSf" target="_blank">查看活动配置手册</a></span>',
  },
  messageArtificial: {
    left: '<span>配置触达前，请先<a href="https://jiduauto.feishu.cn/wiki/SH6hwmHhEiYwuektb7Hcd0BinjD" target="_blank">查看触达配置地图</a>，依据checklist检查触达配置的前置项是否已完成</span>',
    right:
      '<a href="https://jiduauto.feishu.cn/wiki/LY1Cw5c02iTjMLkQiUkcbc1Vnfg" target="_blank">人工触达操作手册</a>',
  },
  messageAutomatic: {
    left: '<span>配置触达前，请先<a href="https://jiduauto.feishu.cn/wiki/G8TGwD3o7iEDg5k50lAcFJx3n2H" target="_blank">查看触达配置地图</a>，依据checklist检查触达配置的前置项是否已完成</span>',
    right:
      '<a href="https://jiduauto.feishu.cn/wiki/KeiHw7rT4idE2Wk4U3FcBz8NnZc" target="_blank">自动触达操作手册</a>',
  },
}

const hasPath = (item) => props.path?.startsWith(item)

const showMarketingList = computed(() => {
  const showMgm = [
    '/marketingCenter/marketing/normal-invitation',
    '/marketingCenter/normal-invitation-create',
    '/marketingCenter/marketing/marketing-list',
    '/marketingCenter/marketing-creat',
    '/message-reaching/reach/reach-automatic',
    '/message-reaching/reach/reach-artificial',
    '/cmsPage/endConfig/activityPage',
    '/cmsPage/endConfig/normal-invitation',
  ].find(hasPath)
  const showRegister = ['/marketingCenter/marketing/register-list', '/activity/register-view'].find(
    hasPath,
  )
  const showMessageAutomatic = ['/message-reaching/reach/reach-automatic'].find(hasPath)
  const showMessageArtificial = ['/message-reaching/reach/reach-artificial'].find(hasPath)
  const showList = []
  if (showMgm) {
    showList.push('mgm')
  }
  if (showRegister) {
    showList.push('register')
  }
  if (showMessageArtificial) {
    showList.push('messageArtificial')
  }
  if (showMessageAutomatic) {
    showList.push('messageAutomatic')
  }
  return showList
})
</script>

<style lang="less" scoped>
.marketingTip {
  display: flex;
  align-items: center;
  padding: 8px;
  margin: 12px 20px 0 20px;
  background-color: rgba(101, 165, 255, 0.3);

  .tips {
    display: flex;
    align-items: center;
    width: 100%;
    box-sizing: border-box;
    justify-content: space-between;
  }
}
</style>
