<template>
  <div class="marketingTip">
    <AlertTriangleIcon :style="{ color: '#7c40ff', marginRight: '9px', fontSize: '18px' }" />
    <div class="tips">
      <div v-if="left" v-html="left"></div>
      <div v-if="right" v-html="right"></div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { AlertTriangleIcon } from '@robot/icon'

defineProps({
  left: {
    type: String,
    default: '',
  },
  right: {
    type: String,
    default: '',
  },
})
</script>

<style scoped lang="less">
.marketingTip {
  display: flex;
  align-items: center;
  padding: 8px;
  margin: 12px 20px 0 20px;
  background-color: rgba(101, 165, 255, 0.3);

  .tips {
    display: flex;
    align-items: center;
    width: 100%;
    box-sizing: border-box;
    justify-content: space-between;
  }
}
</style>
