<template>
  <div ref="wrapRef" :class="getWrapperClass">
    <BasicForm
      ref="formRef"
      submitOnReset
      v-bind="getFormProps"
      v-if="getBindValues.useSearchForm"
      :tableAction="tableAction"
      @register="registerForm"
      @submit="handleSearchInfoChange"
      @advanced-change="redoHeight"
    >
      <template #[replaceFormSlotKey(item)]="data" v-for="item in getFormSlotKeys">
        <slot :name="item" v-bind="data || {}"></slot>
      </template>
    </BasicForm>

    <Table
      ref="tableElRef"
      v-bind="getBindValues"
      :rowClassName="getRowClassName"
      v-show="getEmptyDataIsShowTable"
      @change="handleTableChange"
    >
      <template #[item]="data" v-for="item in Object.keys($slots)" :key="item">
        <slot :name="item" v-bind="data || {}"> </slot>
      </template>

      <template #[`header-${column.dataIndex}`] v-for="(column, index) in columns" :key="index">
        <template v-if="$slots[`header-${column.dataIndex}`]">
          <slot :name="`header-${column.dataIndex}`" :column="column"></slot>
        </template>
        <HeaderCell v-else :column="column" />
      </template>
    </Table>
  </div>
</template>
<script lang="ts">
import { onMounted } from 'vue'

import type { BasicTableProps, TableActionType, SizeType, ColumnChangeParam } from './types/table'

import { defineComponent, ref, computed, unref, toRaw, inject, watchEffect } from 'vue'
import { Table } from '@jidu/robot-ui'
import { BasicForm, useForm } from '/@/components/Form/index'
import { PageWrapperFixedHeightKey } from '/@/components/Page'
import HeaderCell from './components/HeaderCell.vue'
import { InnerHandlers } from './types/table'

import { usePagination } from './hooks/usePagination'
import { useColumns } from './hooks/useColumns'
import { useDataSource } from './hooks/useDataSource'
import { useLoading } from './hooks/useLoading'
import { useRowSelection } from './hooks/useRowSelection'
import { useTableScroll } from './hooks/useTableScroll'
import { useTableScrollTo } from './hooks/useScrollTo'
import { useCustomRow } from './hooks/useCustomRow'
import { useTableStyle } from './hooks/useTableStyle'
import { useTableHeader } from './hooks/useTableHeader'
import { useTableExpand } from './hooks/useTableExpand'
import { createTableContext } from './hooks/useTableContext'
import { useTableFooter } from './hooks/useTableFooter'
import { useTableForm } from './hooks/useTableForm'
import { useDesign } from '/@/hooks/web/useDesign'

import { omit } from 'lodash-es'
import { basicProps } from './props'
import { isFunction } from '/@/utils/is'
import { warn } from '/@/utils/log'
import { getQueryWithSpace, parseQueryToFilter } from '@jidu/robot-utils'

export default defineComponent({
  components: {
    Table,
    BasicForm,
    HeaderCell,
  },
  props: basicProps,
  emits: [
    'fetch-success',
    'fetch-error',
    'selection-change',
    'register',
    'row-click',
    'row-dbClick',
    'row-contextmenu',
    'row-mouseenter',
    'row-mouseleave',
    'edit-end',
    'edit-cancel',
    'edit-row-end',
    'edit-change',
    'expanded-rows-change',
    'change',
    'columns-change',
  ],
  setup(props, { attrs, emit, slots, expose }) {
    const tableElRef = ref(null)
    const tableData = ref<Recordable[]>([])

    const wrapRef = ref(null)
    const formRef = ref<any>(null)
    const innerPropsRef = ref<Partial<BasicTableProps>>()

    const { prefixCls } = useDesign('basic-table')
    const [registerForm, formActions] = useForm()

    const getProps = computed(() => {
      return { ...props, ...unref(innerPropsRef) } as BasicTableProps
    })

    const isFixedHeightPage = inject(PageWrapperFixedHeightKey, false)
    watchEffect(() => {
      unref(isFixedHeightPage) &&
        props.canResize &&
        warn(
          "'canResize' of BasicTable may not work in PageWrapper with 'fixedHeight' (especially in hot updates)",
        )
    })

    const { getLoading, setLoading } = useLoading(getProps)
    const {
      getPaginationInfo,
      getPagination,
      setPagination,
      setShowPagination,
      getShowPagination,
    } = usePagination(getProps)

    const {
      getRowSelection,
      getRowSelectionRef,
      getSelectRows,
      clearSelectedRowKeys,
      getSelectRowKeys,
      deleteSelectRowByKey,
      setSelectedRowKeys,
    } = useRowSelection(getProps, tableData, emit)

    const {
      handleTableChange: onTableChange,
      getDataSourceRef,
      getDataSource,
      getRawDataSource,
      setTableData,
      updateTableDataRecord,
      deleteTableDataRecord,
      insertTableDataRecord,
      findTableDataRecord,
      fetch,
      getRowKey,
      reload,
      getAutoCreateKey,
      updateTableData,
    } = useDataSource(
      getProps,
      {
        tableData,
        getPaginationInfo,
        setLoading,
        setPagination,
        getFieldsValue: formActions.getFieldsValue,
        clearSelectedRowKeys,
      },
      emit,
    )

    function handleTableChange(...args) {
      onTableChange.call(undefined, ...args)
      emit('change', ...args)
      // 解决通过useTable注册onChange时不起作用的问题
      const { onChange } = unref(getProps)
      onChange && isFunction(onChange) && onChange.call(undefined, ...args)
    }

    const {
      getViewColumns,
      getColumns,
      setCacheColumnsByField,
      setColumns,
      getColumnsRef,
      getCacheColumns,
    } = useColumns(getProps, getPaginationInfo)

    const { getScrollRef, redoHeight } = useTableScroll(
      getProps,
      tableElRef,
      getColumnsRef,
      getRowSelectionRef,
      getDataSourceRef,
      wrapRef,
      formRef,
    )

    const { scrollTo } = useTableScrollTo(tableElRef, getDataSourceRef)

    const { customRow } = useCustomRow(getProps, {
      setSelectedRowKeys,
      getSelectRowKeys,
      clearSelectedRowKeys,
      getAutoCreateKey,
      emit,
    })

    const { getRowClassName } = useTableStyle(getProps, prefixCls)

    const { getExpandOption, expandAll, expandRows, collapseAll } = useTableExpand(
      getProps,
      tableData,
      emit,
    )

    const handlers: InnerHandlers = {
      onColumnsChange: (data: ColumnChangeParam[]) => {
        emit('columns-change', data)
        // support useTable
        unref(getProps).onColumnsChange?.(data)
      },
    }

    const { getHeaderProps } = useTableHeader(getProps, slots, handlers)

    const { getFooterProps } = useTableFooter(getProps, getScrollRef, tableElRef, getDataSourceRef)

    const { getFormProps, replaceFormSlotKey, getFormSlotKeys, handleSearchInfoChange } =
      useTableForm(getProps, slots, fetch, getLoading)

    const getBindValues = computed(() => {
      const dataSource = unref(getDataSourceRef)
      let propsData: Recordable = {
        ...attrs,
        customRow,
        ...unref(getProps),
        ...unref(getHeaderProps),
        scroll: unref(getScrollRef),
        loading: unref(getLoading),
        tableLayout: 'fixed',
        rowSelection: unref(getRowSelectionRef),
        rowKey: unref(getRowKey),
        columns: toRaw(unref(getViewColumns)),
        pagination: toRaw(unref(getPaginationInfo)),
        dataSource,
        footer: unref(getFooterProps),
        ...unref(getExpandOption),
      }
      if (slots.expandedRowRender) {
        propsData = omit(propsData, 'scroll')
      }

      propsData = omit(propsData, ['class', 'onChange'])
      return propsData
    })

    const getWrapperClass = computed(() => {
      const values = unref(getBindValues)
      return [
        prefixCls,
        attrs.class,
        {
          [`${prefixCls}-form-container`]: values.useSearchForm,
          [`${prefixCls}--inset`]: values.inset,
        },
      ]
    })

    const getEmptyDataIsShowTable = computed(() => {
      const { emptyDataIsShowTable, useSearchForm } = unref(getProps)
      if (emptyDataIsShowTable || !useSearchForm) {
        return true
      }
      return !!unref(getDataSourceRef).length
    })

    function setProps(props: Partial<BasicTableProps>) {
      innerPropsRef.value = { ...unref(innerPropsRef), ...props }
    }

    const tableAction: TableActionType = {
      reload,
      getSelectRows,
      clearSelectedRowKeys,
      getSelectRowKeys,
      deleteSelectRowByKey,
      setPagination,
      setTableData,
      updateTableDataRecord,
      deleteTableDataRecord,
      insertTableDataRecord,
      findTableDataRecord,
      redoHeight,
      setSelectedRowKeys,
      setColumns,
      setLoading,
      getDataSource,
      getRawDataSource,
      setProps,
      getRowSelection,
      getPaginationRef: getPagination,
      getColumns,
      getCacheColumns,
      emit,
      updateTableData,
      setShowPagination,
      getShowPagination,
      setCacheColumnsByField,
      expandAll,
      expandRows,
      collapseAll,
      scrollTo,
      getSize: () => {
        return unref(getBindValues).size as SizeType
      },
    }
    createTableContext({ ...tableAction, wrapRef, getBindValues })

    expose(tableAction)

    emit('register', tableAction, formActions)

    onMounted(() => {
      if (getProps.value.isSaveToUrl || getProps.value.isSaveToSession) {
        initFilterForm()
      }
    })

    // 判断有筛选，才自动打开筛选框
    // TODO: 高级筛选需要展开
    const initFilterForm = () => {
      // formRef.value在这里相当于getForm
      // 如果是带form的table就需要初始化
      if (formRef.value) {
        // 从SessionStorage获取参数
        const querysString =
          '?' + sessionStorage.getItem('__TableFilter__' + location.origin + location.pathname)
        const querysBySessionStorage = getQueryWithSpace(querysString)
        // 从url获取参数
        const querysByUrl = getQueryWithSpace(location.href)
        let querys = querysByUrl
        // SessionStorage 优先级高
        if (Object.keys(querysBySessionStorage).length) {
          querys = querysBySessionStorage
        }
        const { filterParams } = parseQueryToFilter(querys)
        // 有缓存的筛选参数
        if (Object.keys(filterParams).length) {
          // 筛选参数赋值到form,请求用的
          formRef.value.setFieldsValue(filterParams)
          // 初始化分页参数
          setPagination({ current: querys._p_pageNum || 1 })
          // 请求不会被覆盖, ui回显会被覆盖，所以延迟一下
          setTimeout(() => {
            formRef.value.setFieldsValue(filterParams)
            // 展开搜索筛选
            formRef.value.advanceState.isAdvanced = true
          }, 200)
        }

        // if (isFilterShow) {
        //   // 只有高级筛选需要展开，不判断其他情况了
        //   setProps({ showAdvanceForm: true })
        // }
      }
    }

    return {
      formRef,
      tableElRef,
      getBindValues,
      getLoading,
      registerForm,
      handleSearchInfoChange,
      getEmptyDataIsShowTable,
      handleTableChange,
      getRowClassName,
      wrapRef,
      tableAction,
      redoHeight,
      getFormProps: getFormProps as any,
      replaceFormSlotKey,
      getFormSlotKeys,
      getWrapperClass,
      columns: getViewColumns,
    }
  },
})
</script>
<style lang="less">
@border-color: #cecece4d;

@prefix-cls: ~'@{namespace}-basic-table';

[data-theme='dark'] {
  .r-table-tbody > tr:hover.r-table-row-selected > td,
  .r-table-tbody > tr.r-table-row-selected td {
    background-color: #262626;
  }
}

.@{prefix-cls} {
  max-width: 100%;
  height: 100%;

  &-row__striped {
    td {
      background-color: @app-content-background;
    }
  }

  &-form-container {
    padding: 16px;

    .r-form {
      padding: 18px 10px 10px;
      margin-bottom: 16px;
      background-color: @component-background;
      border-radius: 2px;
    }
  }

  .r-tag {
    margin-right: 0;
  }

  .r-table-wrapper {
    padding: 10px 18px;
    // padding: 4px;
    background-color: @component-background;
    border-radius: 2px;

    .r-table-title {
      min-height: 40px;
      padding: 0 0 8px !important;
    }

    .r-table.r-table-bordered .r-table-title {
      border: none !important;
    }
  }

  .r-table {
    width: 100%;
    overflow-x: hidden;

    &-title {
      display: flex;
      padding: 8px 6px;
      border-bottom: none;
      justify-content: space-between;
      align-items: center;
    }

    //.r-table-tbody > tr.r-table-row-selected td {
    //background-color: fade(@primary-color, 8%) !important;
    //}
  }

  .r-pagination {
    margin: 10px 0 0;
  }

  .r-table-footer {
    padding: 0;

    .r-table-wrapper {
      padding: 0;
    }

    table {
      border: none !important;
    }

    .r-table-body {
      overflow-x: hidden !important;
      //  overflow-y: scroll !important;
    }

    td {
      padding: 12px 8px;
    }
  }

  &--inset {
    .r-table-wrapper {
      padding: 0;
    }
  }
}
</style>
