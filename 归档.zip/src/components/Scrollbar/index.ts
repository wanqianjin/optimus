/**
 * copy from element-ui
 */

import Scrollbar from './src/Scrollbar.vue'

export { Scrollbar }
export type { ScrollbarType } from './src/types'
