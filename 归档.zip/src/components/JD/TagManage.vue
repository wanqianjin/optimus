<template>
  <div style="display: flex; width: 640px">
    <Select
      v-model:value="model[field]"
      :disabled="disabled"
      size="middle"
      mode="multiple"
      showArrow
      allowClear
      placeholder="选择标签"
      @change="handleChange"
      :options="tagOptions"
      :style="style"
    />
  </div>
</template>
<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { Select, message } from '@jidu/robot-ui'
import { GetAllTagApi } from '/@/api/tagManage'

let props = defineProps({
  model: {
    type: Object,
    required: true,
  },
  field: {
    type: String,
    required: true,
  },
  disabled: Boolean,
  limitNum: Number,
  type: {
    type: Number,
  },
  style: {
    type: Object,
  },
})
let tagOptions = ref<SelectProps['options']>([])

const handleChange = (value) => {
  if (value.length > props.limitNum) {
    message.warning(`最多选择${props.limitNum}个标签哦～`)
    props.model[props.field] = value.slice(0, props.limitNum)
  } else {
    props.model[props.field] = value
  }
}
onMounted(() => {
  // type  1: 内容  2:活动
  GetAllTagApi({ type: props.type || 1 }).then((res) => {
    let data = []
    res.forEach((item: any) => {
      data.push({
        value: item.name,
        label: item.name,
      })
    })
    tagOptions.value = data
  })
})
</script>
