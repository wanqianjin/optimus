<template>
  <div class="upload-container">
    <Upload
      :accept="accept"
      :list-type="listType"
      :file-list="fileList"
      :showUploadList="showUploadList"
      :before-upload="beforeUpload"
      v-bind="{ ...propOption }"
      @preview="handlePreview"
      @change="handleChange"
      :disabled="disabled"
    >
      <div v-if="fileList.length < max">
        <r-button v-if="listType === 'picture'" :disabled="disabled">
          <upload-outlined />
          单击上传
        </r-button>
        <div v-if="listType === 'picture-card'" :disabled="disabled">
          <upload-outlined />
          <span class="r-upload-text" style="margin-left: 8px">单击上传</span>
        </div>
      </div>
    </Upload>
    <Modal :visible="previewVisible" :footer="null" @cancel="handleCancel">
      <img alt="example" style="width: 100%" :src="previewImage" />
    </Modal>

    <div class="tip">建议大小70KB-2M</div>
  </div>
</template>
<script setup lang="ts">
import { UploadOutlined } from '@ant-design/icons-vue'
import { ref } from 'vue'
import { Upload, Modal } from '@jidu/robot-ui'
import FileService from '@jidu/file-transfer-sdk'
import { getToken } from '/@/utils/auth'

function getBase64(file: File) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = () => resolve(reader.result)
    reader.onerror = (error) => reject(error)
  })
}

interface FileItem {
  uid: string
  name?: string
  status?: string
  response?: string
  percent?: number
  url?: string
  preview?: string
  originFileObj?: any
}

// export default defineComponent({
//   components: {
//     UploadOutlined,
//     Upload,
//     Modal,
//     // Tooltip
//     // CopyOutlined,
//   },

const max = ref(1)

const props = defineProps({
  listType: {
    type: String,
    default: 'picture',
  },
  model: Object,
  field: String,
  disabled: Boolean,
  type: {
    type: String,
    default: 'image',
  },
  accept: {
    type: String,
    default: '.png, .jpg, .jpeg, .gif',
  },
  // 针对于视频 formatParams="{ type: 'm3u8', showAll: true }" // 允许同时返回m3u8和mp4视频
  formatParams: {
    type: Object,
    default: () => {
      return {
        type: 'mp4',
        showAll: false,
      }
    },
  },
  propOption: {
    type: Object,
    default: () => {},
  },
})

const showUploadList = {
  showRemoveIcon: true,
}
const previewVisible = ref<boolean>(false)
const previewImage = ref<string | undefined>('')

const fileList = ref<FileItem[]>([])

const handleCancel = () => {
  previewVisible.value = false
}
function fileType(filePath) {
  //获取最后一个.的位置
  var index = filePath.lastIndexOf('.')
  //获取后缀
  var ext = filePath.substr(index + 1)
  //判断是否是图片类型
  if (
    ['png', 'jpg', 'jpeg', 'bmp', 'gif', 'webp', 'psd', 'svg', 'tiff'].indexOf(ext.toLowerCase()) !=
    -1
  ) {
    return 'image'
  }
}
const emit = defineEmits(['changeFile'])
const handleChange = (e) => {
  if (e.file.status == 'removed') {
    props.model[props.field] = ''
    setUploadEmpty()
  }
  emit('changeFile')
}

const handlePreview = async (file: FileItem) => {
  let url = file?.url || file?.response?.result // file?.response?.result 处理刚上传成功后点击查看文件空白页情况
  if (Object.prototype.toString.call(url) === '[object String]') {
    if (url && fileType(url) === 'image') {
      // 图片
      if (!file.url && !file.preview) {
        file.preview = (await getBase64(file.originFileObj)) as string
      }
      previewImage.value = file.url || file.preview
      previewVisible.value = true
    } else {
      url && window.open(url, '_blank')
    }
  }
}

function setMultipleUploadValue(params) {
  fileList.value = params.map((item) => ({ ...item, name: item.url }))
}

function setUploadEmpty() {
  fileList.value.splice(0, fileList.value.length)
}

const uploadFile = (file) => {
  const env = import.meta.env.VITE_UPLOAD_ENV
  const client = new FileService({
    env, //环境 目前支持 dev， testing， staging，alpha， production
    authClient: import.meta.env.VITE_GLOB_APP_ID,
  })

  const params = {
    path: '/optimus/settlement', //传输到对应的应用下的地址
    app_name: 'zhizi', //如果需要支持，请先到 https://nyuwa.jiduprod.com/workflow-fontend/ 平台申请应用, 或者联系 @柳振川
    is_encrypt: '0', // 是否对文件加密，0不加密，1加密，默认不加密
    url_type: '0', // 返回地址类型，0内网不鉴权地址，1内网鉴权地址，2 servicename地址，3公网鉴权地址，4bos公网地址， 如不传默认为0
    name: `${file.name}`, // 待保存文件的名称,含扩展名，不填按上传文件的名称
  }

  client
    .uploadFile({ file, token: getToken(), params })
    .then((res) => {
      const { key } = res
      fileList.value = [
        {
          uid: '-1',
          name: file.name,
          status: 'done',
          url: `https://uploader.jidudev.com/api/uploader-server/uploader/getFile?&app=private&is_decrypt=0&mode=preview&key=${key}`,
          thumbUrl: `https://uploader.jidudev.com/api/uploader-server/uploader/getFile?&app=private&is_decrypt=0&mode=preview&key=${key}`,
        },
      ]

      props.model[
        props.field
      ] = `https://uploader.jidudev.com/api/uploader-server/uploader/getFile?&app=private&is_decrypt=0&mode=preview&key=${key}`
      emit('changeFile')
    })
    .catch(() => {
      console.log('失败')
    })
}

const beforeUpload = (file) => {
  // if (file.size > 2 * 1024 * 1024) {
  //   message.warning(`大小不能超过2M`)
  //   return false
  // }
  // if (file.size < 70 * 1024) {
  //   message.warning(`大小不能小于10KB`)
  //   return false
  // }
  fileList.value = [
    {
      uid: '-1',
      name: file.name,
      status: 'uploading',
      url: ``,
    },
  ]
  uploadFile(file)
  return false
}

defineExpose({
  setMultipleUploadValue,
  setUploadEmpty,
})
</script>
<style lang="less" scoped>
.tip {
  color: #b4b1c1;
  font-size: 14px;
  line-height: 22px;
  font-family: 'PingFang SC';
}

::v-deep(.r-upload-list-picture-card-container) {
  overflow: hidden;
}

::v-deep(.r-upload-list-item-info) {
  padding: 0;
}

::v-deep(.r-upload-list-picture-card .r-upload-list-item-thumbnail) {
  line-height: 100px;
}
</style>
