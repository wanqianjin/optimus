import { withInstall } from '/@/utils'
import codeDiff from './src/code-diff/CodeDiff.vue'
import jsonPreview from './src/json-preview/JsonPreview.vue'

export const CodeDiff = withInstall(codeDiff)
export const JsonPreview = withInstall(jsonPreview)

export * from './src/typing'
