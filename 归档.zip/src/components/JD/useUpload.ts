import { message } from '@jidu/robot-ui'

export function checkFileType(file: any, accepts: any) {
  const newTypes = accepts.join('|')
  // const reg = /\.(jpg|jpeg|png|gif|txt|doc|docx|xls|xlsx|xml)$/i;
  const reg = new RegExp('\\.(' + newTypes + ')$', 'i')

  return reg.test(file.name)
}

export function getImgWidthOrHeight(file: any) {
  return new Promise((resolve, reject) => {
    const filereader = new FileReader()
    filereader.readAsDataURL(file)
    filereader.onload = (event: any) => {
      // const src = e.target.result
      const image = new Image()
      image.src = event.target.result
      // try {
      image.onload = function () {
        console.error('image.width', image.width, image.height)
        resolve({
          width: image.width,
          height: image.height,
        })
      }
      image.onerror = () => {
        message.warning(`上传错误`)
        reject(false)
      }
    }
  })
}
