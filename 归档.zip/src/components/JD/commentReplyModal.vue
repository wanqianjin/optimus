<template>
  <BasicModal
    v-bind="$attrs"
    @register="register"
    wrapClassName="reply-modal-box"
    :minHeight="90"
    :title="articleId || activityId || advertisementId ? '官方留言' : '回复评论'"
    @ok="handleSubmit"
  >
    <BasicForm @register="registerForm" />
  </BasicModal>
</template>

<script setup lang="ts">
import { BasicModal, useModalInner } from '/@/components/Modal'
import { BasicForm, useForm } from '/@/components/Form/index'
import { onMounted, ref } from 'vue'
import { queryAllVestListApi } from '/@/api/operation'
import { ReplyComment, CommentContent } from '/@/api/comment'
import { useMessage } from '/@/hooks/web/useMessage'
import { useCommentStoreWidthOut } from '/@/store/modules/comment'
const { createMessage } = useMessage()

const userStore = useCommentStoreWidthOut()

const emit = defineEmits(['success'])

const [registerForm, { validate, updateSchema, resetFields, getFieldsValue }] = useForm({
  labelWidth: 100,
  schemas: [
    {
      field: 'commentInfo',
      component: 'InputTextArea',
      label: '回复评论',
      colProps: {
        span: 24,
      },
      rules: [{ required: true }],
      componentProps: {
        style: {
          width: '390px',
        },
        placeholder: '请输入回复评论，不超过200个字',
        rows: 2,
        maxlength: 200,
        options: [],
      },
    },
    {
      field: 'userId',
      component: 'Select',
      label: '作者账号',
      colProps: {
        span: 24,
      },
      rules: [{ required: true }],
      componentProps: {
        style: {
          width: '390px',
        },
        placeholder: '请选择作者账号',
        options: [],
      },
    },
  ],
  actionColOptions: { span: 24 },
  showActionButtonGroup: false,
})

const commentId = ref()
const replyFlag = ref()
const articleId = ref()
const activityId = ref()
const advertisementId = ref()
const contentTitle = ref()
const [register, { closeModal, setModalProps, changeOkLoading }] = useModalInner(async (record) => {
  // console.log(record)
  commentId.value = record.commentId
  replyFlag.value = record.replyFlag

  articleId.value = record.articleId
  activityId.value = record.activityId
  advertisementId.value = record.advertisementId
  contentTitle.value = record.title

  resetFields()
  setModalProps({ confirmLoading: false })
  const list = await queryAllVestListApi({})
  updateSchema({
    field: 'commentInfo',
    label: articleId.value || activityId.value || advertisementId.value ? '官方留言' : '回复评论',
    componentProps: {
      placeholder:
        articleId.value || activityId.value || advertisementId.value
          ? '请输入留言评论，不超过200个字'
          : '请输入回复评论，不超过200个字',
    },
  })
  updateSchema({
    field: 'userId',
    componentProps: {
      // options: [{ value: data.userId, label: data.userId }, ...userList.value],
      options: [
        ...list.map((i) => {
          return {
            label: i.nickName,
            value: i.authorId,
          }
        }),
      ],
    },
  })
  // const id = list.find((i) => i.value == data.userId)?.value
  // if (id) {
  //   setFieldsValue({ userId: String(id) })
  // }
})

onMounted(async () => {})

const handleSubmit = async () => {
  await validate()
  setModalProps({ confirmLoading: true })
  const values = getFieldsValue()
  const { commentInfo, userId } = values
  const Func =
    articleId.value || activityId.value || advertisementId.value ? CommentContent : ReplyComment
  let obj = {}
  if (articleId.value || activityId.value || advertisementId.value) {
    obj = {
      contentId: articleId.value || activityId.value || advertisementId.value,
      moduleType: articleId.value ? '0' : activityId.value ? '1' : '2',
      appId: articleId.value ? 'content' : 'activity',
      contentTitle: contentTitle.value,
      commentInfo,
      userId,
    }
  } else {
    obj = {
      commentId: commentId.value,
      moduleType: userStore.moduleType,
      appId: userStore.appId,
      commentInfo,
      userId,
    }
  }
  try {
    await Func(obj)
    createMessage.success('回复成功')
    closeModal()
    emit('success')
  } catch (err) {
    changeOkLoading(false)
    closeModal()
    if (!articleId.value && !activityId.value && !advertisementId.value) {
      emit('success')
    }
    console.log(err)
  }
}
</script>

<style lang="less">
.reply-modal-box {
  .scrollbar {
    overflow: visible;
  }

  .scrollbar__wrap {
    overflow: visible;
  }

  .scroll-container .scrollbar__wrap {
    overflow-x: visible;
  }
}
</style>
