import { BasicColumn } from '/@/components/Table/src/types/table'
import { FormSchema } from '/@/components/Table'

export function formSchema(): FormSchema[] {
  return [
    {
      field: 'eventName',
      label: '事件名称',
      component: 'Input',
      slot: 'eventNameSlot',
      componentProps: {
        placeholder: '请输入事件名称，需保持命名的唯一性',
        autocomplete: 'off',
        maxLength: 100,
      },
      required: true,
    },
    {
      field: 'channelIds',
      label: '所属渠道资源位',
      component: 'Select',
      slot: 'channelIdSlot',
      required: true,
    },
    {
      field: 'channelActivityId',
      label: '所属项目',
      component: 'Select',
      slot: 'channelActivityIdSlot',
      required: true,
    },
    {
      field: 'touchFlag',
      label: '触达策略',
      component: 'RadioGroup',
      required: true,
      componentProps: {
        options: [
          { value: 3, label: '销售触达', key: 3 },
          // { value: 2, label: '销售探针触达', key: 2 },
          { value: 1, label: '销售不触达', key: 1 },
        ],
        size: 'middle',
      },
      slot: 'reachStrategySlot',
      ifShow: ({}) => {
        return false
      },
    },
    {
      label: '触达时效',
      field: 'touchValidation',
      component: 'Select',
      required: true,
      defaultValue: 1,
      ifShow: ({}) => {
        return false
      },

      slot: 'touchValidationSlot',
    },
    {
      field: 'eventType',
      label: '所属业务',
      component: 'Select',
      slot: 'eventTypeSlot',
      required: true,
    },
    {
      field: 'clientId',
      label: '所属端',
      component: 'Select',
      slot: 'clientIdSlot',
      required: true,
    },
    {
      field: 'departmentId',
      label: '所属部门',
      component: 'Select',
      slot: 'departmentIdSlot',
      required: true,
    },

    {
      field: 'description',
      component: 'InputTextArea',
      label: '事件描述',

      required: true,
      slot: 'descriptionSlot',
    },
    {
      field: 'marketingFlag',
      label: '所属营销类型',
      component: 'Select',
      defaultValue: 1,
      required: false,
      slot: 'marketingFlagSlot',
      ifShow: () => {
        return true
      },
    },
  ]
}

export function BasicTableColumns(): BasicColumn[] {
  return [
    {
      title: '事件名称',
      dataIndex: 'eventName',
      width: 240,
      slots: { customRender: 'eventNameSlot' },
    },
    {
      title: '所属渠道资源位',
      dataIndex: 'resourceChannelName',
    },
    {
      title: '所属活动',
      dataIndex: 'channelActivityName',
      width: 120,
    },
    {
      title: '销售标签',
      dataIndex: 'saleTag',
      width: 120,
    },
    {
      title: '所属业务',
      dataIndex: 'eventType',
      width: 120,
    },
    {
      title: '所属部门',
      dataIndex: 'departmentDesc',
      width: 140,
    },
    {
      title: '所属端',
      dataIndex: 'clientDesc',
      width: 120,
    },
    {
      title: '导入结果',
      dataIndex: 'result',
      width: 140,
    },
    {
      title: '描述',
      dataIndex: 'description',
      slots: { customRender: 'descriptionSlot' },
    },
  ]
}

export const channeEventDEVColumns = [
  {
    title: '事件名称',
    dataIndex: 'eventName',
    width: 240,
    slots: { customRender: 'eventNameSlot' },
  },
  {
    title: '密钥',
    dataIndex: 'eventKey',
    width: 120,
  },
  {
    title: '所属渠道资源位',
    dataIndex: 'resourceChannelName',
  },
  {
    title: '所属活动',
    dataIndex: 'channelActivityName',
    width: 120,
  },
  {
    title: '所属业务',
    dataIndex: 'eventType',
    width: 120,
  },
  {
    title: '所属部门',
    dataIndex: 'departmentDesc',
    width: 140,
  },
  {
    title: '所属端',
    dataIndex: 'clientDesc',
    width: 120,
  },
  {
    title: '导入结果',
    dataIndex: 'result',
    width: 140,
  },
  {
    title: '描述',
    dataIndex: 'description',
    slots: { customRender: 'descriptionSlot' },
  },
  // {
  //   title: '所属营销类型',
  //   dataIndex: 'marketingFlagDesc',
  // },
]
