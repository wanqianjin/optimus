<template>
  <PageWrapper>
    <BasicModal
      v-bind="$attrs"
      @register="register"
      :destroyOnClose="true"
      title="新建事件"
      :minHeight="createFlag ? 600 : 200"
      :width="createFlag ? '1150px' : '600px'"
      @ok="handleConfirm"
      wrapClassName="reply-modal-c"
      :closable="radioValue === optionsTypeEnum.single"
      :maskClosable="radioValue === optionsTypeEnum.single"
      :cancelButtonProps="{ disabled: cancelButtonDisabledFlag }"
      :okButtonProps="{ disabled: okButtonDisabledFlag }"
      :show-cancel-btn="createFlag"
    >
      <div v-if="createFlag">
        <Card class="header-guide">
          <div>
            <span>
              <Link type="primary" class="guide" @click="openChannelEventPage">点击此处</Link>
              可进入渠道事件管理页查看。
            </span>
          </div>
        </Card>
        <div class="pt-16px pr-16px">
          <Form class="reply-form">
            <FormItem label="新增方式" :colon="false" :label-col="{ span: 3 }">
              <RadioGroup
                :options="radioGroupOptions"
                option-type="button"
                v-model:value="radioValue"
                @change="radioGroupChange"
              />
            </FormItem>
          </Form>
          <SingleEventForm ref="SingleEventFormRef" v-if="radioValue === optionsTypeEnum.single" />
          <BatchEventForm
            ref="BatchEventFormRef"
            v-else
            :channelLevel="4"
            @changeCancelButtonState="changeCancelButtonState"
            @changeOkButtonState="changeOkButtonState"
          />
        </div>
      </div>
      <!-- 无创建权限 -->
      <div v-else> <NoPermission /></div>
    </BasicModal>
  </PageWrapper>
</template>
<script setup lang="ts">
import { PageWrapper } from '/@/components/Page'
import { ref, computed } from 'vue'
import { BasicModal, useModalInner } from '/@/components/Modal'
import { message, Card, Link, RadioGroup, Form, FormItem, Modal } from '@jidu/robot-ui'
import { createChannelEventApi } from '/@/api/channel'
import SingleEventForm from './components/SingleEventForm.vue'
import BatchEventForm from './components/BatchEventForm.vue'
import NoPermission from './components/NoPermission.vue'
import { useRouter } from 'vue-router'
import { usePermission } from '/@/hooks/web/usePermission'
const { hasPermission } = usePermission()
const router = useRouter()
defineEmits(['register', 'success'])

const SingleEventFormRef = ref()
const BatchEventFormRef = ref()
const radioValue = ref('1')
const optionsTypeEnum = {
  single: '1',
  batch: '2',
}
const radioGroupOptions = ref([
  {
    label: '单项新增',
    value: '1',
  },
  {
    label: '批量新增',
    value: '2',
  },
])
// 判断打开弹框是否有 渠道事件创建 权限
const createFlag = computed(() => {
  return (
    hasPermission('channel_event-manage_page_add_click') &&
    hasPermission('channel_event-manage_page_batch_add_click')
  )
})
const cancelButtonDisabledFlag = ref(false)
const okButtonDisabledFlag = ref(false)

// 修改 确认\取消 按钮状态
function radioGroupChange(e) {
  if (e.target.value === optionsTypeEnum.single) {
    cancelButtonDisabledFlag.value = false
    okButtonDisabledFlag.value = false
  }
}

// 批量上传时对 确认\取消 按钮状态做修改
function changeCancelButtonState(status) {
  cancelButtonDisabledFlag.value = status
}
function changeOkButtonState(status) {
  okButtonDisabledFlag.value = status
}
const [register, { closeModal, changeOkLoading }] = useModalInner(async () => {
  radioValue.value = optionsTypeEnum.single //初始化
  okButtonDisabledFlag.value = false
})

async function handleCreate(fields) {
  changeOkLoading(true) //用于修改确认按钮的 loading 状态
  const hide = message.loading('正在配置')
  try {
    let params = {
      ...fields,
    }
    // 活动ID 服务端需要字符串形式
    params.channelActivityId && (params.channelActivityId = params?.channelActivityId?.at(-1))
    await createChannelEventApi(params)
    message.success('创建成功')
    closeModal()
    return true
  } catch (error) {
    console.log('error', error)
    return false
  } finally {
    hide()
    changeOkLoading(false)
  }
}

async function handleConfirm() {
  try {
    if (radioValue.value === optionsTypeEnum.single && createFlag.value) {
      const params = await SingleEventFormRef.value.getValue()
      // '非营销类活动'
      if (params.marketingFlag === 1) {
        Modal.confirm({
          title: '提示',
          content: '是否确认当前创建的渠道事件不属于裂变相关？裂变相关请选择“裂变营销”',
          okText: '确认',
          cancelText: '取消',
          onOk: async () => {
            await handleCreate(params)
            message.success('创建成功')
            closeModal()
          },
        })
      } else {
        await handleCreate(params)
        message.success('创建成功')
        closeModal()
      }
    } else {
      closeModal()
    }
  } catch (error) {
    console.log(error, 'error')
  }
}

// 渠道事件管理
function openChannelEventPage() {
  const newpage = router.resolve({
    path: '/launchConfig/channel/event-manage',
  })
  window.open(newpage.href, '_blank')
}
</script>
<style lang="less">
.reply-modal-c {
  .scrollbar {
    padding: 0 !important;
  }

  .r-card-body {
    padding: 0 0 0 16px !important;
  }

  .header-guide {
    height: 38px;
    line-height: 38px;
    background-color: #f3f0ff;
    padding: 0 6px;

    .info {
      color: #824dfc;
      font-size: 16px;
      padding: 0 8px;
    }
  }

  .reply-form {
    margin: 16px 0 0 -4px;
  }
}
</style>
