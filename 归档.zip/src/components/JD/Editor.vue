<template>
  <div style="border: 1px solid #ccc" id="editor" :class="[useJDType]">
    <Toolbar
      style="border-bottom: 1px solid #ccc"
      :editor="editorRef"
      :defaultConfig="toolbarConfig"
      :mode="mode"
    />
    <Editor
      style="height: 500px; overflow-y: hidden"
      v-model="valueHtml"
      :defaultConfig="editorConfig"
      :mode="mode"
      @onCreated="handleCreated"
      @onChange="handleChange"
      @customPaste="customPaste"
    />
    <!-- 默认弹框的蒙层 -->
    <Modal class="editor-modal" :maskClosable="false" v-model:visible="modelVisible" width="1px" />
    <!-- 视频封面弹框 -->
    <Modal v-model:visible="showVideoPoster" title="视频封面" type="primary" @ok="videoPosterOk">
      <div class="modal-upload-box" v-if="showVideoPoster">
        <NewBasicUpload
          ref="imgRef"
          v-model:uploadValue="videoInfo['poster']"
          :maxSize="10"
          :disabled="mode === 'view'"
          listType="picture-card"
          :max="1"
        />
      </div>
    </Modal>
  </div>
</template>
<script setup lang="ts">
import '@wangeditor/editor/dist/css/style.css'
import { setVideoPoster } from '/@/components/JD/@wangeditor/menu/videoPosterMenu'
import '/@/components/JD/@wangeditor/menu/panterMenu'
import { onMounted, onBeforeUnmount, ref, shallowRef, defineExpose, nextTick } from 'vue'
import { message, Modal } from '@jidu/robot-ui'
// import BasicUpload from '/@/components/JD/BasicUpload.vue'
import NewBasicUpload from '/@/components/JD/Upload/BasicUpload.vue'

import axios from 'axios'
// 引入wangeditor组件
import { Editor, Toolbar } from './@wangeditor/editor-for-vue/index.esm.js'
import { getToken } from '/@/utils/auth'
// 引入代码高亮组件
// import hljs from 'highlight.js'

// 公共状态文件
// 官方文档：https://www.kancloud.cn/wangfupeng/wangeditor3/335774
// 设置富文本编辑器的HTML内容
const props = defineProps({
  contentHtml: String,
  excludeKeys: Array,
  model: Object,
  field: String,
  setFieldsValue: Function,
  // 使用业务方类型 article: 文章
  useJDType: {
    type: String,
    defalut: '',
  },
  // 使用内容的图片上传压缩服务
  useJDImgUpload: {
    type: Boolean,
    defaule: false,
  },
})

// 弹框mask是否展示
const modelVisible = ref(false)
// 获取编辑器实例
const editorRef = shallowRef()
const mode = ref('default')
// 内容 HTML
const valueHtml = ref('')
// 编辑器实例对象
const VITE_GLOB_API_URL = import.meta.env.VITE_GLOB_API_URL
// 展示文章封面编辑
const showVideoPoster = ref(false)
// 视频信息
const videoInfo = ref({
  // 视频封面
  poster: '',
})
onMounted(() => {
  // 设置富文本内容
  valueHtml.value = props.contentHtml
})
const toolbarConfig = {
  excludeKeys: ['fullScreen'], // 隐藏编辑器全屏
  insertKeys: {
    index: 5,
    keys: 'MyPainter',
  },
  getConfig() {},
  // 弹框加载到body下
  modalAppendToBody: true,
}

const editorConfig = {
  placeholder: '请输入内容...',
  hoverbarKeys: {
    video: {
      // 清空 image 元素的 hoverbar
      menuKeys: ['videoPoster'],
    },
  },
  MENU_CONF: {
    uploadImage: {
      maxFileSize: 1 * 1024 * 1024, // 1M
      allowedFileTypes: ['.png', '.jpg', '.jpeg', '.gif'],
      headers: {
        Authorization: getToken(),
      },
      // 自定义上传图片
      async customUpload(resultFiles, insertImgFn) {
        const formData = new FormData()
        formData.append('file', resultFiles)
        const hide = message.loading('正在上传', 0)
        let type = resultFiles?.type
        if (props.useJDImgUpload && type !== 'image/gif') {
          try {
            const res = await axios.post(
              `${VITE_GLOB_API_URL}/b/content-backend/backend/upload/uploadFileWithCompress?needCompress=true`,
              formData,
              {
                // 上传图片接口
                headers: {
                  'Content-Type': 'multipart/form-data',
                },
              },
            )
            // 上传图片，返回结果，将图片插入到编辑器中
            console.log('res---', res)
            if (res?.data?.code === 0) {
              insertImgFn(res?.data?.result)
              hide()
              message.success('上传成功')
            } else if (res?.data?.code === 40016 || res?.data?.code === 40015) {
              //
              insertImgFn(res?.data?.result?.url)
              hide()
              message.success('上传成功')
            } else {
              hide()
              const errorMsg = res?.data?.showMsg || res?.data?.showMsg || '上传失败'
              message.error(errorMsg)
            }
          } catch (err) {
            console.error('上传失败====>', err)
            hide()
            message.error('上传失败')
          }
        } else {
          try {
            const res = await axios.post(
              `${VITE_GLOB_API_URL}/b/content-backend/backend/upload/uploadFile`,
              formData,
              {
                // 上传图片接口
                headers: {
                  'Content-Type': 'multipart/form-data',
                },
              },
            )
            // 上传图片，返回结果，将图片插入到编辑器中
            if (res?.data?.code === 0) {
              insertImgFn(res?.data?.result)
              hide()
              message.success('上传成功')
            } else {
              hide()
              const errorMsg = res?.data?.showMsg || res?.data?.showMsg || '上传失败'
              message.error(errorMsg)
            }
          } catch (err) {
            console.error('上传失败====>', err)
            hide()
            message.error('上传失败')
          }
        }
      },
    },
    uploadVideo: {
      // 自定义上传视频
      async customUpload(resultFiles, insertVideoFn) {
        const formData = new FormData()
        formData.append('file', resultFiles)
        const hide = message.loading('正在上传', 0) // 设为0，默认不会自动关闭
        try {
          const res = await axios.post(
            `${VITE_GLOB_API_URL}/b/content-backend/backend/upload/uploadFile?type=mp4`,
            formData,
            {
              // 上传图片接口
              headers: {
                'Content-Type': 'multipart/form-data',
              },
            },
          )
          // 上传图片，返回结果，将图片插入到编辑器中
          if (res?.data?.code === 0) {
            insertVideoFn(res?.data?.result)
            hide()
            message.success('上传成功')
          } else {
            hide()
            const errorMsg = res?.data?.showMsg || res?.data?.showMsg || '上传失败'
            message.error(errorMsg)
          }
        } catch (err) {
          hide()
          message.error('上传失败')
          console.error('上传失败====>', err)
        }
      },
    },
  },
}
// 自定义粘贴
function customPaste(editor, event, callback) {
  const html = event.clipboardData.getData('text/html') // 获取粘贴的 html
  // 来自飞书的html, 删除飞书的html特有span,否则会复制两次
  const roboteamHtml = html.replace(/\<span data-lark-record-data=\"[\d\D]{0,}\<\/span\>/, '')
  // 来自飞书的复制
  if (roboteamHtml !== html) {
    editor.dangerouslyInsertHtml(roboteamHtml)
    callback(false)
  }
}

// 设置富文本编辑器的页面内容，父组件直接调用该方法
function setContentHtmlValue(value) {
  console.log('999999====>', value)
  valueHtml.value = value
}
// 禁用富文本
function setEditorDisabled() {
  editorRef.value && editorRef.value.disable()
}

defineExpose({
  setContentHtmlValue,
  setEditorDisabled,
})
//  页面卸载
onBeforeUnmount(() => {
  const editor = editorRef.value
  if (editor == null) return
  editor.destroy()
})
const handleCreated = (editor) => {
  editorRef.value = editor // 记录 editor 实例，重要！
  editor.getConfig().MENU_CONF.color.colors.unshift('red', '#000', 'pink') // 追加业务自定义颜色
  if (props.excludeKeys) {
    toolbarConfig.excludeKeys.push(...props.excludeKeys) //排除业务不需要的菜单项
  }
  // 自定义弹框展示
  editor.on('modalOrPanelShow', (modalOrPanel) => {
    if (modalOrPanel.type !== 'modal') return
    const { $elem } = modalOrPanel // modal element
    const width = $elem.width()
    const height = $elem.height()
    // set modal position z-index
    $elem.css({
      position: 'fixed',
      left: '50%',
      top: '50%',
      marginLeft: `-${width / 2}px`,
      marginTop: `-${height / 2}px`,
      zIndex: 99999,
    })
    modelVisible.value = true
    // 设置 modal 样式（定位、z-index）
    // 显示蒙层
  })
  // 自定义弹框隐藏
  editor.on('modalOrPanelHide', () => {
    modelVisible.value = false
  })
  // 监听点击视频封面事件
  editor.on('onTapVideoPosterMenu', (poster) => {
    showVideoPoster.value = true
    if (poster) {
      nextTick(() => {
        videoInfo.value.poster = poster || ''
      })
    }
    console.log('poster---', poster, 3)
    videoInfo.value.poster = poster || ''
  })
}
const handleChange = () => {
  // 将值valueHtml.value 传递至父组件
  props.model[props.field] = valueHtml.value

  props.setFieldsValue && props.setFieldsValue({ ...props.model })
}

// 设置视频封面
const videoPosterOk = () => {
  const poster = videoInfo.value.poster
  const editor = editorRef.value
  setVideoPoster(editor, poster)
  showVideoPoster.value = false
}
</script>
<style lang="less">
#editor {
  img {
    max-width: 100%;
    display: inline-block;
  }
}
/* 处理h1字体大小被覆盖 */
h1 {
  font-size: 2rem;
}
/* 隐藏组件库的modal内容, 只用mask */
.editor-modal .r-modal-content {
  display: none;
}

.modal-upload-box .upload-content {
  display: block;
  text-align: center;
}

// 视频相关
.w-e-textarea-video-container video {
  object-fit: contain;
  background-color: #000;
}
// 自定义视频封面, 与C端保持一致
.w-e-textarea-video-container .w-e-video-poster-box {
  position: absolute;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  padding: 10px 0px;
  box-sizing: border-box;

  &.hidden {
    display: none !important;
  }

  .w-e-video-poster-img {
    width: 100%;
    height: 100%;
    object-fit: cover;

    &.hidden {
      display: none !important;
    }
  }

  .w-e-video-poster-icon {
    position: absolute;
    left: 50%;
    top: 50%;
    width: 44px;
    height: 44px;
    transform: translate3d(-50%, -50%, 0);
    z-index: 10;
    backdrop-filter: blur(15px);
    border-radius: 50%;
  }
}
</style>
