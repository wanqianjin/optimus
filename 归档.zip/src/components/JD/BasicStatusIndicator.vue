<template>
  <div :class="`status-indicator ${getClass}`" :style="style">
    <div class="content">
      <slot></slot>
    </div>
  </div>
</template>
<script setup lang="ts">
import { computed } from 'vue'
import type { CSSProperties } from 'vue'
const props = defineProps({
  type: {
    type: String,
    default: 'success',
  },
  style: { type: Object as PropType<CSSProperties> },
})
const getClass = computed(() => {
  if (['success', 'info', 'warning', 'error'].includes(props.type)) {
    return `status-color-${props.type}`
  } else {
    return `status-color-success`
  }
})
</script>
<style lang="less" scoped>
.status-indicator {
  display: inline-block;
  margin-right: 6px;
  width: 7px;
  height: 7px;
  border-radius: 50%;
  position: relative;
  bottom: 1px;

  .content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: inherit;
  }
}

.status-color-success {
  background-color: #55d187;
}

.status-color-info {
  background-color: #824dfc;
}

.status-color-warning {
  background-color: #efbd47;
}

.status-color-error {
  background-color: #ccc9cc;
}
</style>
