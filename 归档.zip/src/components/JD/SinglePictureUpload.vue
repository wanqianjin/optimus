<template>
  <div class="img-upload">
    <Upload
      v-model:file-list="fileList"
      class="avatar-uploader"
      :multiple="false"
      v-bind="{ ...propOption }"
      @change="
        (file) => {
          handleChange(file)
        }
      "
      :headers="headers"
      list-type="picture-card"
      :action="url"
      :before-upload="
        async (file) => {
          await beforeUpload(file)
        }
      "
      @preview="handlePictureCardPreview"
      @remove="remove"
      :disabled="disabled"
    >
      <div v-if="!fileList.length" :disabled="disabled">
        <plus-outlined />
        <div class="r-upload-text">点击上传</div>
      </div>
    </Upload>
    <div v-if="leftTips || sizeTip" class="left-Tips" :disabled="disabled">
      <div> {{ leftTips }}</div>
      <div>{{ sizeTip }}</div>
    </div>
  </div>
  <!-- v-model:value="ImgRotateVue" -->

  <Modal
    :visible="dialogVisible"
    :footer="null"
    @cancel="
      () => {
        dialogVisible = false
      }
    "
  >
    <img alt="example" style="width: 100%" :src="dialogImageUrl" />
  </Modal>
  <!-- <div @click="test">123213</div> -->
</template>
<script setup lang="ts">
import { ref, onUnmounted, computed, watch } from 'vue'
import { message, Upload, Modal } from '@jidu/robot-ui'
// import { uploadHeaders } from '/@/utils/auth'
import { PlusOutlined } from '@ant-design/icons-vue'
import { getImgWidthOrHeight, checkFileType } from './useUpload'
const headers = { Authorization: 'bf40c1c30acb291b171bca5ed8307f20' }
const emit = defineEmits(['update:value', 'getWidthHeight', 'remove'])

let url = computed(() => {
  const VITE_GLOB_API_URL = import.meta.env.VITE_GLOB_API_URL
  if (props.type === 'image') {
    return `${VITE_GLOB_API_URL}/b/content-backend/backend/upload/uploadFile`
  } else {
    return `${VITE_GLOB_API_URL}/b/content-backend/backend/upload/uploadFile?type=${props.formatParams.type}&showAll=${props.formatParams.showAll}`
  }
})
const props = defineProps({
  value: {
    type: String,
    default: '',
  },
  leftTips: {
    type: String,
    default: '',
  },
  sizeTip: {
    type: String,
    default: '',
  },
  listType: {
    type: String,
    default: 'picture',
  },
  getWH: {
    // 获取图片宽高 配合 emit getWidthHeight
    type: Boolean,
    default: false,
  },
  maxWidth: {
    type: Number,
    default: 0,
  },
  maxHeight: {
    type: Number,
    default: 0,
  },
  // 目标宽高，将图片压缩到这个宽高
  targetWidth: {
    type: Number,
    default: 0,
  },
  targetHeight: {
    type: Number,
    default: 0,
  },
  // 限制宽高的情况下图片最大高度
  limitHeight: {
    type: Number,
    default: 0,
  },
  showTips: {
    type: String,
    default: '',
  },
  // 业务有个别类型符合的图片 [[宽1， 高1], [宽2， 高2]] 判断宽高比列
  widthAndHeightList: {
    type: Array,
    default: () => [],
  },
  // 上传大小设置
  maxSize: {
    type: Number,
    default: 0,
  },
  // 上传类型限制
  typeList: {
    type: Array,
    default: () => [],
  },
  // 原antdv 参数
  propOption: {
    type: Object,
    default: () => {},
  },
  type: {
    type: String,
    default: 'image',
  },
  // 视频是否转码
  formatParams: {
    type: Object,
    default: () => {
      return {
        type: 'mp4',
        showAll: false,
      }
    },
  },
  disabled: Boolean,
})
const dialogVisible = ref(false)
const dialogImageUrl = ref('')
// 列表数据
interface FileItem {
  uid?: string
  name?: string
  status?: string
  response?: string
  percent?: number
  url?: string
  preview?: string
  originFileObj?: any
  imageUrl?: string
}
const fileList = ref<FileItem[]>([])
watch(
  () => props.value,
  (newValue) => {
    if (newValue && !fileList.value.length) {
      fileList.value.push({
        imageUrl: props.value,
        url: props.value,
      })
    } else if (!newValue) {
      fileList.value = []
    }
  },
  { deep: true },
)
const handleChange = (info) => {
  const { status, response } = info.file
  switch (status) {
    case 'done':
      if (response.code === 0) {
        fileList.value = info.fileList.map((v) => ({
          ...v,
          imageUrl: v.imageUrl || v.response.result,
        }))
        emit('update:value', info.fileList[0].imageUrl || info.fileList[0].response.result)
        emit('uploadSuccess', info.fileList[0].imageUrl || info.fileList[0].response.result)
      } else {
        fileList.value = []
        emit('update:value', '')
        emit('getWidthHeight')
        message.error(`上传失败，请重试`)
      }
      break
    case 'error':
      message.error(`上传失败，请重试`)
      fileList.value = []
      emit('getWidthHeight')
      emit('update:value', '')
      break
    case 'removed':
      fileList.value = []
      emit('getWidthHeight')
      emit('update:value', '')
      break
    default:
  }
}

/**
 * @description: 判断图片在将宽放大缩小到 targetWidth 下，高度是否是指定 maxHeight
 * @param {*} widthAndHeight { height: number; width: number }
 * @return {*} boolean
 */
const isTargetWidthMaxHeight = (widthAndHeight: { height: number; width: number }) => {
  return (
    props.targetWidth &&
    props.maxHeight &&
    props.maxHeight !== widthAndHeight.height / (widthAndHeight.width / props.targetWidth)
  )
}

/**
 * @description: 判断图片在将宽放大缩小到 targetWidth 下，最大高度是否是指定 limitHeight
 * @param {*} widthAndHeight { height: number; width: number }
 * @return {*} boolean
 */
const isTargetWidthLimitHeight = (widthAndHeight: { height: number; width: number }) => {
  return (
    props.targetWidth &&
    props.limitHeight &&
    widthAndHeight.height / (widthAndHeight.width / props.targetWidth) >= props.limitHeight
  )
}

/**
 * @description: 判断图片在将高放大缩小到 targetWidth 下，宽度是否是指定 maxWidth
 * @param {*} widthAndHeight { height: number; width: number }
 * @return {*} boolean
 */
const isTargetHeightMaxWidth = (widthAndHeight: { height: number; width: number }) => {
  return (
    props.targetHeight &&
    props.maxWidth &&
    props.maxWidth !== widthAndHeight.height / (widthAndHeight.height / props.targetHeight)
  )
}

const beforeUpload = async (file: { name: string; size: number }) => {
  let fileNameList = file.name.split('.')
  let type = fileNameList[fileNameList.length - 1]
  return await new Promise(async (resolve, _reject) => {
    try {
      // 校验格式
      console.log('type', props.typeList, type, !props.typeList.includes[type])
      if (props.getWH) {
        console.log('props.getWH', props.getWH)
        const widthAndHeight: any = await getImgWidthOrHeight(file)
        emit('getWidthHeight', widthAndHeight)
      }
      if (props.typeList.length && !checkFileType(file, props.typeList)) {
        const title = props.typeList.join('/')
        message.warning(`只能上传${title}格式`)
        throw new Error()
      }
      console.log(props.maxSize)
      // 校验大小
      if (props.maxSize && file.size / 1024 / 1024 > props.maxSize) {
        message.warning(`大小不能超过${props.maxSize}M`)
        throw new Error()
      }
      // 判断宽高
      if (props.maxWidth || props.maxHeight) {
        const widthAndHeight: any = await getImgWidthOrHeight(file)
        if (
          (props.maxWidth && props.maxWidth !== widthAndHeight.width) ||
          (props.maxHeight && props.maxHeight !== widthAndHeight.height)
        ) {
          message.warning(props.leftTips)
          throw new Error(props.leftTips)
        }
      }

      // 在目标宽或目标高度的情况下，判断传入图片是需要的宽高或者是是否小于最大高度
      if (
        (!!props.targetWidth && !!props.maxHeight) ||
        (!!props.targetHeight && !!props.maxWidth) ||
        (!!props.targetWidth && !!props.limitHeight)
      ) {
        const widthAndHeight: any = await getImgWidthOrHeight(file)
        if (
          isTargetWidthMaxHeight(widthAndHeight) ||
          isTargetWidthLimitHeight(widthAndHeight) ||
          isTargetHeightMaxWidth(widthAndHeight)
        ) {
          message.warning(props.showTips || props.leftTips)
          throw new Error(props.showTips || props.leftTips)
        }
      }

      // 判断宽高比列
      if (props.widthAndHeightList && props.widthAndHeightList.length) {
        const widthAndHeight: any = await getImgWidthOrHeight(file)
        const comparisons = (widthAndHeight?.width / widthAndHeight?.height).toFixed(2)
        const isOkList = props.widthAndHeightList.map((o: Number) => {
          if ((o[0] / o[1]).toFixed(2) !== comparisons) {
            return false
          }
          return true
        })
        // 有一个符合就算符合
        if (isOkList.some((item) => item)) {
          resolve(true)
        } else {
          message.warning(props.showTips || props.leftTips)
          // await reject(false)
          throw new Error(props.showTips || props.leftTips)
        }
      }
      resolve(true)
    } catch (error) {
      console.log('error===', error)
    }
  })
}

function getBase64(file: File) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = () => resolve(reader.result)
    reader.onerror = (error) => reject(error)
  })
}
const handlePictureCardPreview = async (file: {
  url: any
  preview: string
  originFileObj: File
}) => {
  if (!file.url && !file.preview) {
    file.preview = (await getBase64(file.originFileObj)) as string
  }
  dialogImageUrl.value = file.url || file.preview
  dialogVisible.value = true
}
// const test = () => {
//   // emit('update:value', 12)
//   console.error('props.btn', props.value)
//   console.error('props.btn', props.value)
// }
// onMounted(() => {
//   if (props.value) {
//     fileList.value.push({
//       imageUrl: props.value,
//       url: props.value,
//     })
//   }
// })

// 点击移除文件时的回调，返回值为 false 时不移除
const remove = (e) => {
  emit('remove', e)
}

watch(
  () => props.value,
  (newValue) => {
    if (!fileList.value.length && newValue) {
      fileList.value.push({
        imageUrl: props.value,
        url: props.value,
      })
    } else if (!newValue) {
      fileList.value = []
    }
  },
  { deep: true, immediate: true },
)
onUnmounted(() => {})
</script>
<style lang="less" scoped>
.img-upload {
  display: flex;
  margin-bottom: 8px;
}

.left-Tips {
  align-self: center;
  color: #b4b1c1;
}

:deep(.r-upload-list-picture-card .r-upload-list-item:hover .r-upload-list-item-info::after) {
  opacity: 1;
}

::v-deep(.r-form-item-control-input-content) {
  display: flex;
}

:deep(.r-upload-list-picture-card .r-upload-list-item-info::after) {
  position: absolute;
  z-index: 1;
  top: 0;
  width: 100%;
  height: 100%;
  left: -50%;
  // background-color: rgba(31, 30, 30, 0.5);
  opacity: 0;
  transition: all 0.3s;
  content: ' ';
}

:deep(.r-upload.r-upload-select-picture-card) {
  margin-bottom: 0;
}

:deep(.r-upload-list-picture-card-container) {
  margin: 0 8px 0px 0;
}

.avatar-uploader {
  width: auto;
}

::v-deep(.r-upload-list-item) {
  padding: 0;
}

::v-deep(.r-upload) {
  background-color: #f8f8fa;
}

::v-deep(.r-upload-list-item-actions) {
  a {
    position: relative;
    top: -1.5px;
  }

  .robot-icon-eye {
    margin: 0 10px 0 2px;
    transform: scale(1.05);
  }
}

:deep(.robot-icon svg) {
  color: #ffffff !important;
  font-size: 16px;
}

// .r-upload-select-picture-card .r-upload-text {
//   margin-top: 8px;
//   color: #666;
// }
</style>
