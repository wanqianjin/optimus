<template>
  <div id="ckId" ref="editor" class="box" :style="{ height: `${props.height || 100}px` }"> </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import jiduEditor from '@jidudev/editor-ck/editor.common.js'
import { getToken } from '/@/utils/auth'

const VITE_GLOB_API_URL = import.meta.env.VITE_GLOB_API_URL
const props = defineProps({
  readOnly: {
    type: Boolean,
  },
  defaultData: {
    type: String,
    default: '',
  },
  height: {
    type: Number,
  },
  hiddenTool: {
    type: Boolean,
  },
  model: Object,
  field: String,
})
const onDataChange = (data) => {
  props.model[props.field] = data
}

const editor = ref(null)
let jidu
onMounted(() => {
  console.log('clientid===>', import.meta.env.VITE_GLOB_APP_ID)
  jidu = new jiduEditor({
    ele: editor.value,
    height: 'extend',
    // debounceTime:100,
    Authorization: getToken(), // token
    AuthClient: import.meta.env.VITE_GLOB_APP_ID, //应用clientid
    onChange: onDataChange,
    readOnly: props.readOnly,
    hiddenToolbar: props.hiddenTool,
    defaultData: props.defaultData,
    setting: {
      fontSize: {
        options: [12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 40, 48],
        default: 14,
      },
      fontColor: {
        colors: [
          {
            color: '#656277',
            // label: 'Black'
          },
          {
            color: '#49465C',
            // label: 'Dim grey'
          },
          {
            color: '#848197',
            // label: 'Grey'
          },
          {
            color: '#D0CFD9',
            // label: 'Light grey'
          },
          {
            color: '#E9E8EE',
            // label: 'White',
            hasBorder: false,
          },
          {
            color: '#824DFC',
            // label: 'Black'
          },
          {
            color: '#0462FE',
            // label: 'Dim grey'
          },
          {
            color: '#29CC78',
            // label: 'Grey'
          },
          {
            color: '#FF4D63',
            // label: 'Light grey'
          },
          {
            color: '#FAC800',
            // label: 'White',
          },
          {
            color: '#A385FF',
            // label: 'Black'
          },
          {
            color: '#60A7FF',
            // label: 'Dim grey'
          },
          {
            color: '#77E6A5',
            // label: 'Grey'
          },
          {
            color: '#FF99A0',
            // label: 'Light grey'
          },
          {
            color: '#FFEC57',
            // label: 'White',
          },
        ],
      },
      upload: {
        url: `${VITE_GLOB_API_URL}/b/content-backend/backend/upload/uploadFile`,
        header: {
          Authorization: getToken(),
          'Auth-Client': import.meta.env.VITE_GLOB_APP_ID,
        },
        // params: function () {
        //   return {}
        // },
        resolveObj: function (res) {
          console.log('res===>', res)
          return {
            default: res.result,
          }
        },
      },
    },
  })
  jidu.init().then(() => {
    // jidu.setDefaultData('<p>dsgdcxzvcbfffg</p>')
    console.log(jidu.getData())
    // jidu.hiddenToolbar(true)
    // setTimeout(() => {
    //   //    jidu.destroy()
    //   jidu.setHeight('1000px')
    // }, 5000)
  })
})
// 设置富文本编辑器的页面内容，父组件直接调用该方法
function setContentHtmlValue(value) {
  jidu.setDefaultData(value)
}
// 修改富文本只读状态
function setReadOnlyMode(status) {
  jidu.setReadOnlyMode(status)
}
defineExpose({
  setContentHtmlValue,
  setReadOnlyMode,
})
</script>

<style scoped>
#app {
  /* font-family: Avenir, Helvetica, Arial, sans-serif; */
  /* font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px; */
}

.box {
  /* width: 100%; */
  height: 500px;
  /* border: 1px solid red; */
}

::v-deep(h1),
::v-deep(h2),
::v-deep(h3),
::v-deep(h4),
::v-deep(h5),
::v-deep(h6) {
  font-size: inherit;
  margin-left: 0 !important;
}

::v-deep(.ck.ck-dropdown.ck-font-size-dropdown .ck.ck-reset.ck-dropdown__panel) {
  height: 220px;
  overflow: scroll;
}

::v-deep(.ck-content ul) {
  list-style-type: disc;
  padding-left: 40px;
}
</style>
