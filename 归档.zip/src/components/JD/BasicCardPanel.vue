<template>
  <div class="conditions-box">
    <div class="title-container">
      <div class="left-container">
        <div class="line"></div>
        <!-- 标题 -->
        <div class="title">{{ title || '--' }}</div>
        <!-- 提示文案包括icon -->
        <div class="tips">
          <slot name="titleTips"></slot>
        </div>
      </div>
      <div class="right-container">
        <!-- 标题右侧内容 -->
        <slot name="right"></slot>
      </div>
    </div>
    <div class="container-box">
      <!-- 内容 -->
      <div class="container-part">
        <slot name="content"></slot>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { onMounted } from 'vue'
const props = defineProps({
  title: {
    type: String,
    default: '',
  },
})

onMounted(() => {
  console.log('props===', props)
})
</script>
<style lang="less" scoped>
.conditions-box {
  margin-bottom: 24px;

  .title-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    // margin-left: -5px;
    height: 30px;
    margin-bottom: 6px;

    .left-container {
      display: flex;
      align-items: center;

      .line {
        width: 4px;
        height: 16px;
        margin-right: 8px;
        background: @primary-color;
      }

      .title {
        font-weight: bold;
      }

      .tips {
        margin-left: 10px;
        cursor: pointer;
      }
    }
  }

  .container-box {
    // padding: 6px 0;
    // display: flex;
    position: relative;
    // flex-direction: column;

    // .container-part {
    //   flex: 1;
    // }
  }
}
</style>
