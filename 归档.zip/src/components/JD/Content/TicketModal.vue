<!-- 工单详情 -->
<template>
  <Modal
    :visible="visible"
    @cancel="cancel"
    title="查看工单进展"
    :footer="null"
    width="700px"
    height="500px"
  >
    <Tabs v-model:activeKey="activeTab">
      <Tabs.TabPane
        :tab="item.name"
        v-for="(item, index) in listData"
        :key="item.name"
        style="height: 500px; overflow-y: scroll"
      >
        <div class="tabContent" v-if="ticketInfo[index]?.id">
          <Form
            :label-col="{
              flex: '100px',
            }"
            :wrapper-col="{ span: 16 }"
          >
            <FormItem label="工单ID">{{ ticketInfo[index]?.id }}</FormItem>
            <FormItem label="工单状态">{{ ticketInfo[index].orderStatusDesc }}</FormItem>
            <FormItem label="工单进展">
              <Timeline class="ticket-line">
                <TimelineItem v-for="(item, no) in ticketInfo[index].operateDetails" :key="no">
                  <div class="ticket">
                    <div class="title">{{ no }}</div>
                    <template v-for="(v, i) in item" :key="i">
                      <div class="item">
                        <div class="subtitle">
                          <div class="text">{{ v.createTime.split(' ')[1] }}</div>
                          <div class="text"
                            ><LinkPersonal :maxWidth="300">{{
                              v.operateRealname
                            }}</LinkPersonal></div
                          >
                          <div class="text">{{ v.operateTypeName }}</div>
                        </div>
                        <div class="desc" v-html="v.operateContent"></div>
                      </div>
                    </template>
                  </div>
                </TimelineItem>
              </Timeline>
            </FormItem>
          </Form>
        </div>
        <div v-else> <Empty description="暂无内容" class="!mt-4" /> </div>
      </Tabs.TabPane>
    </Tabs>
  </Modal>
</template>
<script setup lang="ts">
import {
  Modal,
  Timeline,
  TimelineItem,
  Form,
  FormItem,
  LinkPersonal,
  Tabs,
  Empty,
} from '@jidu/robot-ui'
import { ref } from 'vue'
defineProps({
  visible: {
    type: Boolean,
    default: false,
  },
  ticketInfo: {
    type: Object,
    default: () => ({}),
  },
})
const activeTab = ref('舆情工单')

const emit = defineEmits(['cancel'])
const listData = [
  {
    name: '舆情工单',
    id: 1,
  },
  {
    name: '客诉工单',
    id: 2,
  },
]

const cancel = () => {
  emit('cancel')
}
</script>
<style lang="less">
.ticket {
  &-line {
    padding-top: 10px;
  }

  .item {
    width: 500px;
    padding: 10px;
    background-color: #f2f3f8;
  }

  .item ~ .item {
    margin-top: 10px;
  }

  .title {
    font-weight: bold;
  }

  .desc {
    margin-top: 10px;
  }

  .subtitle {
    display: flex;
    align-items: center;

    .text {
      margin-right: 5px;
    }
  }
}
</style>
