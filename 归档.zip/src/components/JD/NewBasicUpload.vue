<template>
  <div class="img-upload">
    <!--  左侧label -->
    <!-- <div style='margin-right:14px'>
      <span  style='margin-right:2px'>{{uploadProps.label}}</span>
      <Tooltip placement="top">
        <template #title>
          <span>{{uploadProps.helpMessage}}</span>
        </template>
       <info-circle-outlined />
      </Tooltip>
    </div> -->
    <Upload
      :action="url"
      :headers="headers"
      :list-type="listType"
      v-model:file-list="fileList"
      :showUploadList="showUploadList"
      :accept="accept"
      v-bind="{ ...propOption }"
      @preview="handlePreview"
      @change="handleChange"
      :disabled="disabled"
      class="avatar-uploader"
    >
      <div v-if="fileList.length < max">
        <r-button v-if="listType === 'picture'" :disabled="disabled">
          <upload-outlined />
          单击上传
        </r-button>
        <div
          v-if="listType === 'picture-card'"
          :disabled="disabled"
          style="display: flex; flex-direction: column; align-items: center"
        >
          <plus-outlined />
          <span class="r-upload-text">点击上传</span>
        </div>
      </div>
    </Upload>
    <Modal :visible="previewVisible" :footer="null" @cancel="handleCancel">
      <img alt="example" style="width: 100%" :src="previewImage" />
    </Modal>
  </div>
</template>
<script setup lang="ts">
import { UploadOutlined } from '@ant-design/icons-vue'
import { ref, computed } from 'vue'
import { Upload, Modal, message } from '@jidu/robot-ui'
import { getToken } from '/@/utils/auth'
import { PlusOutlined } from '@ant-design/icons-vue'

const headers = { Authorization: getToken() }
function getBase64(file: File) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = () => resolve(reader.result)
    reader.onerror = (error) => reject(error)
  })
}

interface FileItem {
  uid: string
  name?: string
  status?: string
  response?: string
  percent?: number
  url?: string
  preview?: string
  originFileObj?: any
}

// export default defineComponent({
//   components: {
//     UploadOutlined,
//     Upload,
//     Modal,
//     // Tooltip
//     // CopyOutlined,
//   },

const props = defineProps({
  listType: {
    type: String,
    default: 'picture',
  },
  model: Object,
  field: String,
  disabled: Boolean,
  max: {
    type: Number,
    default: 1,
  },
  type: {
    type: String,
    default: 'image',
  },
  accept: {
    type: String,
    default: '.png, .jpg, .jpeg, .gif',
  },
  // 针对于视频 formatParams="{ type: 'm3u8', showAll: true }" // 允许同时返回m3u8和mp4视频
  formatParams: {
    type: Object,
    default: () => {
      return {
        type: 'mp4',
        showAll: false,
      }
    },
  },
  propOption: {
    type: Object,
    default: () => {},
  },
})

let url = computed(() => {
  const VITE_GLOB_API_URL = import.meta.env.VITE_GLOB_API_URL
  console.log('global_env', VITE_GLOB_API_URL)
  if (props.type === 'video') {
    return `${VITE_GLOB_API_URL}/b/content-backend/backend/upload/uploadFile?type=${props.formatParams.type}&showAll=${props.formatParams.showAll}`
  } else {
    return `${VITE_GLOB_API_URL}/b/content-backend/backend/upload/uploadFile`
  }
})

const showUploadList = {
  showRemoveIcon: true,
}
const previewVisible = ref<boolean>(false)
const previewImage = ref<string | undefined>('')

const fileList = ref<FileItem[]>([])

const handleCancel = () => {
  previewVisible.value = false
}
function fileType(filePath) {
  //获取最后一个.的位置
  var index = filePath.lastIndexOf('.')
  //获取后缀
  var ext = filePath.substr(index + 1)
  //判断是否是图片类型
  if (
    ['png', 'jpg', 'jpeg', 'bmp', 'gif', 'webp', 'psd', 'svg', 'tiff'].indexOf(ext.toLowerCase()) !=
    -1
  ) {
    return 'image'
  }
}
const handlePreview = async (file: FileItem) => {
  let url = file?.url || file?.response?.result // file?.response?.result 处理刚上传成功后点击查看文件空白页情况
  if (Object.prototype.toString.call(url) === '[object String]') {
    if (url && fileType(url) === 'image') {
      // 图片
      if (!file.url && !file.preview) {
        file.preview = (await getBase64(file.originFileObj)) as string
      }
      previewImage.value = file.url || file.preview
      previewVisible.value = true
    } else {
      url && window.open(url, '_blank')
    }
  }
}
const handleChange = (e) => {
  if (e.file.status == 'removed') {
    props.model[props.field] = ''
    //移除图片时；
    //setUploadimages && setUploadimages('')
  } else if (e.file.status == 'done') {
    //上传完成时
    if (e.file.response.code == 0) {
      if (e.file.response.result && typeof e.file.response.result === 'object') {
        props.model[props.field] = JSON.stringify(e.file.response.result)
      } else {
        props.model[props.field] = e.file.response.result
      }
      fileList.value = e.fileList
      //done && done(e.file.response.result)
      //setUploadimages && setUploadimages(e.file.response.result)
    } else {
      message.error(e.file.response.msg ?? '上传失败')
    }
  } else if (e.file.status == 'error') {
    //上传错误时
    message.error('上传失败')
  }
  // console.log('newFileList===>', newFileList)
  // fileList.value = newFileList
}
function setUploadValue(params) {
  fileList.value = [
    {
      uid: '-1',
      name: params?.name,
      status: 'done',
      url: params.url,
      thumbUrl: params.url,
    },
  ]
}

function setMultipleUploadValue(params) {
  fileList.value = params.map((item) => ({ ...item, name: item.url }))
}

function setUploadEmpty() {
  fileList.value.splice(0, fileList.value.length)
}

defineExpose({
  setUploadValue,
  setMultipleUploadValue,
  setUploadEmpty,
})
</script>
<style lang="less" scoped>
.img-upload {
  display: flex;
  margin-bottom: 8px;
}

.left-Tips {
  align-self: center;
  color: #b4b1c1;
}

:deep(.r-upload-list-picture-card .r-upload-list-item:hover .r-upload-list-item-info::after) {
  opacity: 1;
}

::v-deep(.r-form-item-control-input-content) {
  display: flex;
}

:deep(.r-upload-list-picture-card .r-upload-list-item-info::after) {
  position: absolute;
  z-index: 1;
  top: 0;
  width: 100%;
  height: 100%;
  left: -50%;
  // background-color: rgba(31, 30, 30, 0.5);
  opacity: 0;
  transition: all 0.3s;
  content: ' ';
}

:deep(.r-upload.r-upload-select-picture-card) {
  margin-bottom: 0;
}

:deep(.r-upload-list-picture-card-container) {
  margin: 0 8px 0px 0;
}

.avatar-uploader {
  width: auto;
}

::v-deep(.r-upload-list-item) {
  padding: 0;
}

::v-deep(.r-upload) {
  background-color: #f8f8fa;
}
// .r-upload-select-picture-card .r-upload-text {
//   margin-top: 8px;
//   color: #666;
// }
</style>
