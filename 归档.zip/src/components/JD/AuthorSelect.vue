<template>
  <div style="display: flex">
    <Select
      v-model:value="model[field]"
      :disabled="disabled"
      size="middle"
      showArrow
      allowClear
      placeholder="请选择作者"
      style="width: 500px"
      @change="handleChange"
      :options="authorOptions"
    />
  </div>
</template>
<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { Select } from '@jidu/robot-ui'
import { queryAllVestListApi } from '/@/api/operation'

let props = defineProps({
  model: {
    type: Object,
    required: true,
  },
  field: {
    type: String,
    required: true,
  },
  disabled: Boolean,
})
let authorOptions = ref<SelectProps['options']>([])

const handleChange = () => {
  console.log(props)
  // if (value.length > props.limitNum) {
  //   message.warning(`最多选择${props.limitNum}个标签哦～`)
  //   props.model[props.field] = value.slice(0, props.limitNum)
  // } else {
  //   props.model[props.field] = value
  // }
}
onMounted(() => {
  queryAllVestListApi({}).then((res) => {
    let data = []
    res.forEach((item: any) => {
      data.push({
        value: item.authorId,
        label: item.nickName,
      })
    })
    authorOptions.value = data
  })
})
</script>
