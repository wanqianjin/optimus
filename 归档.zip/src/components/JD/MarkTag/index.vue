<template>
  <div>
    <BasicDrawer @register="drawerRegister" showFooter :destroyOnClose="true" width="70%">
      <template #title>
        <div>{{ title }}</div>
      </template>
      <Card>
        <ScrollContainer style="height: 60vh">
          <Table
            :columns="getBasicTableColumns()"
            :data-source="tableData"
            :indentSize="20"
            rowKey="id"
            :defaultExpandedRowKeys="defaultExpandedRowKeys"
          >
            <template #bodyCell="{ column, record }">
              <template v-if="column.dataIndex === 'labelName'">
                <div style="display: flex">
                  <Checkbox
                    v-model:checked="record.choose"
                    v-if="record.labelType === 2"
                    @change="(e) => handleCheckTag(e, record)"
                    :disabled="record.disabled"
                  />
                  <div style="margin-left: 20px">{{ record.labelName }}</div>
                </div>
              </template>
            </template>
          </Table>
        </ScrollContainer>
      </Card>
      <Card style="margin-top: 10px">
        <div style="font-weight: 700">已选标签</div>
        <ScrollContainer style="height: 10vh">
          <template v-for="tag in checkedTags" :key="tag.id">
            <Tag :closable="true" @close="handleDeleteTag(tag)">
              {{ tag.labelName }}
            </Tag>
          </template>
        </ScrollContainer>
      </Card>

      <template #footer>
        <Button @click="handleClose">取消</Button>
        <Button @click="handleUpdateTag" type="primary">确认</Button>
      </template>
    </BasicDrawer>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { BasicDrawer, useDrawerInner } from '/@/components/Drawer'
import { ScrollContainer } from '/@/components/Container'
import { Card, Button, Table, Checkbox, Tag, message } from '@jidu/robot-ui'
import { getLabelTreeApi } from '/@/api/integral'
import {
  getBasicTableColumns,
  TagItem,
  removeChildrenIfLabelTypeIsTwo,
  findByIdAndUpdateChoose,
  updateAndCollectLabels,
  updateDisabledStatus,
} from './config.data'

const emit = defineEmits(['close', 'register', 'update'])

const tableData = ref<Array<TagItem>>([]) // 树表格数据
const checkedKeys = ref<Array<string | number>>([]) // 选中标签的id
const checkedTags = ref<Array<TagItem>>([]) // 选中标签的完整对象  下方展示使用
const defaultExpandedRowKeys = ref<Array<any>>([]) // 默认展开的行
// 具体项目信息（权益、积分）
const subJectInfo = ref<any>({ subjectType: null, subjectId: '', subjectName: '' })

let title = computed(() => {
  return ` 您正在为${subJectInfo.value.subjectName}(${subJectInfo.value.subjectId})打标`
})

const [drawerRegister, { closeDrawer }] = useDrawerInner(async (data) => {
  checkedKeys.value = []
  checkedTags.value = []
  console.log(data, '抽屉接收数据')
  try {
    const { labelList, subjectType, subjectId, subjectName } = data
    await getLabelTree({ subjectType })
    subJectInfo.value.subjectType = subjectType
    subJectInfo.value.subjectId = subjectId
    subJectInfo.value.subjectName = subjectName

    // 回显选中标签
    if (Array.isArray(labelList) && labelList.length > 0) {
      const { updatedTableData, updatedLabels } = updateAndCollectLabels(tableData.value, labelList)
      tableData.value = updatedTableData
      checkedKeys.value = labelList
      checkedTags.value = updatedLabels
      // 更新已选标签禁用态
      checkedKeys.value.forEach((id) => {
        updateDisabledStatus(tableData.value, id, true)
      })
    }
  } catch (error) {
    console.log(error, '抽屉内容数据处理错误')
  }
})
/**
 * 处理标签的选中状态, 更新checkedKeys数组
 *
 * @param e 事件对象
 * @param record 表格中的一行数据记录
 */
function handleCheckTag(e, record) {
  const isChecked = e.target.checked

  const index = checkedKeys.value.findIndex((id) => id === record.id)
  const tagIndex = checkedTags.value.findIndex((item) => item.id === record.id)

  if (isChecked && index === -1) {
    // 如果被选中并且不在数组中，则添加
    checkedKeys.value.push(record.id)
    checkedTags.value.push(record)
    updateDisabledStatus(tableData.value, record.id, true)
  } else if (!isChecked && index !== -1) {
    // 如果未被选中并且在数组中，则移除
    checkedKeys.value.splice(index, 1)
    checkedTags.value.splice(tagIndex, 1)
    updateDisabledStatus(tableData.value, record.id, false)
  }
}

/**
 * 处理删除标签的函数
 * @param tag 被删除的标签对象
 */
async function handleDeleteTag(tag) {
  const { id } = tag
  tableData.value = findByIdAndUpdateChoose({ data: tableData.value, id, choose: false })
  const index = checkedKeys.value.findIndex((itemId) => itemId === id)
  const tagIndex = checkedTags.value.findIndex((item) => item.id === id)
  checkedKeys.value.splice(index, 1)
  checkedTags.value.splice(tagIndex, 1)
  updateDisabledStatus(tableData.value, id, false)
}

//
function handleUpdateTag() {
  if (checkedKeys.value.length > 50) {
    message.error('最多选择50个标签')
    return
  } else {
    emit('update', { labelIdList: checkedKeys.value, ...subJectInfo.value })
    handleClose()
  }
}
/**
 * 关闭弹窗
 * @param tag 被删除的标签对象
 */
async function handleClose() {
  checkedKeys.value = []
  checkedTags.value = []
  closeDrawer()
}

onMounted(async () => {
  try {
    getLabelTree({})
  } catch (error) {
    console.log(error, '获取标签树失败')
  }
})
async function getLabelTree(params) {
  const { subjectType } = params
  try {
    const res = await getLabelTreeApi({ subjectType })
    tableData.value = removeChildrenIfLabelTypeIsTwo(res)
  } catch (error) {
    console.log(error, '获取标签树失败')
  }
}
</script>

<style lang="less" scoped>
::v-deep(.r-card-body) {
  padding-top: 8px !important;
}

::v-deep(.r-form-item) {
  margin-bottom: 24px !important;
}

::v-deep(.r-descriptions-item) {
  padding-bottom: 16px !important;
  padding-top: 0px;
}
</style>
