<template>
  <PageWrapper>
    <BasicModal
      v-bind="$attrs"
      @register="register"
      :destroyOnClose="true"
      title="查看标签"
      width="600px"
      :showCancelBtn="false"
      @ok="closeModal"
    >
      <div v-if="groupedData.length">
        <template v-for="(item, index) in groupedData" :key="index">
          <div class="groupParentName"> {{ item.groupParentName }}</div>
          <div class="tag">
            <template v-for="(tag, index) in item.labelStrList" :key="index">
              <Tag>{{ tag }} </Tag>
            </template>
          </div>
        </template>
      </div>
    </BasicModal>
  </PageWrapper>
</template>
<script setup lang="ts">
import { PageWrapper } from '/@/components/Page'
import { ref } from 'vue'
import { BasicModal, useModalInner } from '/@/components/Modal'
import { Tag } from '@jidu/robot-ui'

defineEmits(['register'])

const groupedData = ref([])

const [register, { closeModal }] = useModalInner(async (data) => {
  console.log(data)

  groupedData.value = []
  const { labelList } = data
  // 遍历数据，按照 groupParentId 分组
  labelList.forEach((item) => {
    let found = false
    // 查找是否已经存在对应的 groupParentName
    for (let i = 0; i < groupedData.value.length; i++) {
      if (groupedData.value[i].groupParentName === item.groupParentName) {
        // 如果找到了，就在 labelStrList 中添加新的 label
        groupedData.value[i].labelStrList.push(`${item.labelGroupName}-${item.labelName}`)
        found = true
        break
      }
    }
    if (!found) {
      // 如果没有找到，就创建一个新的分组对象
      groupedData.value.push({
        groupParentName: item.groupParentName,
        labelStrList: [`${item.labelGroupName}-${item.labelName}`],
      })
    }
  })
})
</script>
<style lang="less" scoped>
.groupParentName {
  font-size: 16px;
  font-weight: bold;
  margin: 16px 0;
}
</style>
