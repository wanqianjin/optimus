export function getBasicTableColumns() {
  return [
    {
      title: '标签名称',
      dataIndex: 'labelName',
      key: 'id',
    },
  ]
}
export interface TagItem {
  id: number
  key?: number
  labelName: string
  labelType: number
  choose?: boolean
  children?: TagItem[]
}

/**
 * 如果标签类型为2，则删除其children,因为展开按钮会根据有无children 来添加。
 *
 * @param items 标签项数组
 * @returns 处理后的标签项数组
 */
export function removeChildrenIfLabelTypeIsTwo(items: TagItem[]): TagItem[] {
  return items.map((item) => {
    // 检查当前对象的 labelType 是否为 2
    if (item.labelType === 2) {
      // 如果是，删除 children 属性（如果存在的话）
      delete item.children
    }
    // 如果对象有 children 属性，递归处理
    if (item.children) {
      item.children = removeChildrenIfLabelTypeIsTwo(item.children)
    }

    // 返回处理后的对象
    return item
  })
}
/**
 * 根据ID查找并更新数组中对象的choose属性为false
 *
 * @param data treeData
 * @param id 要查找的对象的ID
 * @returns 如果找到了匹配的ID并成功更新了choose属性，则返回true；否则返回false
 */
export function findByIdAndUpdateChoose(params): any[] {
  const { data, id, choose } = params
  for (let i = 0; i < data.length; i++) {
    const item = data[i]
    // 如果找到匹配的ID，修改choose属性为false并返回true
    if (item.id === id) {
      item.choose = choose
      return data
    }
    // 如果对象有children属性，递归查找
    if (Array.isArray(item.children)) {
      item.children = findByIdAndUpdateChoose({ data: item.children, id, choose: false })
    }
  }
  // 如果没有找到，返回false
  return data
}
/**
 * 更新表格数据并收集标签, 标签回显
 *
 * @param tableData 表格数据源
 * @param labelList 标签列表
 * @returns 更新后的表格数据源和收集到的标签数组
 */
export function updateAndCollectLabels(tableData, labelList) {
  // 初始化更新后的数据源和收集到的标签数组
  const updatedTableData = [...tableData]
  const updatedLabels = []

  // 辅助函数，递归遍历树结构
  function traverseTree(items) {
    for (const item of items) {
      // 如果当前项的id在labelList中，则更新choose属性
      if (labelList.includes(item.id)) {
        item.choose = true
        // 收集更新后的标签对象
        updatedLabels.push({
          ...item,
        })
      }

      // 如果有子项，递归遍历子项
      if (item.children) {
        traverseTree(item.children)
      }
    }
  }

  // 遍历数据源
  traverseTree(updatedTableData)

  // 返回更新后的数据源和收集到的标签数组
  return {
    updatedTableData,
    updatedLabels,
  }
}

export function updateDisabledStatus(labelList, targetId, disabled) {
  function findAndUpdate(nodes, targetId, disabled) {
    for (const node of nodes) {
      // 如果是二级标签（labelType === 1）
      if (node.labelType === 1) {
        // 遍历其所有子标签
        for (const child of node.children) {
          // 如果找到了目标三级标签（labelType === 2）
          if (child.id === targetId) {
            // 判断该二级标签的multiSelect属性
            if (!node.multiSelect) {
              // 如果multiSelect为false，则禁用除目标三级标签外的所有子标签
              for (const sibling of node.children) {
                if (sibling.id !== targetId) {
                  sibling.disabled = disabled
                }
              }
            }
            // 找到后返回，因为不需要继续在其他二级标签中查找
            return
          }
        }
      } else {
        // 递归查找子节点
        findAndUpdate(node?.children, targetId, disabled)
      }
    }
  }

  findAndUpdate(labelList, targetId, disabled)
}
