<template>
  <div class="version" :class="{ 'filed-version': isFiledStyle }">
    <span v-if="!props.isFiledStyle">版本号：</span>
    <div>
      <Input v-model:value="versionArr[0]" />
      <span>.</span>
      <Input v-model:value="versionArr[1]" />
      <span>.</span>
      <Input v-model:value="versionArr[2]" />
    </div>
  </div>
</template>
<script setup lang="ts">
import { watch, ref } from 'vue'
import { Input } from '@jidu/robot-ui'
const props = defineProps({
  version: {
    type: String,
    required: true,
  },
  onChange: {
    type: Function,
    required: true,
  },
  isFiledStyle: {
    type: Boolean,
  },
})
const versionArr = ref<string[]>(props.version.split('.'))

watch(
  () => versionArr.value,
  (val) => {
    props.onChange(val.join('.'))
  },
  { deep: true },
)
watch(
  () => props.version,
  (val) => {
    versionArr.value = val.split('.')
  },
  { deep: true },
)
</script>
<style scoped lang="less">
.version {
  display: flex;
  margin: 10px 0;
  background: white;
  width: 300px;
  justify-content: center;
  padding: 3px;

  > span {
    line-height: 30px;
  }

  > div {
    > input {
      width: 70px;
      height: 30px;
      margin-right: 5px;
    }

    > span {
      position: relative;
      right: 2px;
      top: -5px;
    }
  }

  .icon-des {
    position: relative;
    left: -20px;
  }
}

.filed-version {
  justify-content: left;
  margin: 0;
}
</style>
