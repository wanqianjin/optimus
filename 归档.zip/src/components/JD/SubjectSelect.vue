<template>
  <div style="display: flex">
    <Select
      v-model:value="model[field]"
      :disabled="disabled"
      size="middle"
      allowClear
      show-search
      placeholder="请选择专题"
      style="width: 500px"
      @change="(_, option) => $emit('searchTypeOptions', option)"
      @search="handleSearch"
      :options="subjectOptions"
      :default-active-first-option="false"
      :show-arrow="false"
      :filter-option="false"
      :not-found-content="null"
    />
  </div>
</template>
<script setup lang="ts">
import { ref } from 'vue'
import { Select, message } from '@jidu/robot-ui'
import { querySubjectNameList } from '/@/api/operation'

defineProps({
  model: {
    type: Object,
    required: true,
  },
  field: {
    type: String,
    required: true,
  },
  disabled: Boolean,
})
let subjectOptions = ref<SelectProps['options']>([])
// const emit = defineEmits(['getSubjectTypes'])
let timeout: any
let currentValue = ''

const emit = defineEmits(['init'])

// 下拉框支持id/标题搜索专题
const handleSearch = (value: string) => {
  fetch(value)
}
const getSubjectName = (keyword, init) => {
  let params = {}
  if (currentValue || keyword) {
    params = { keyword: currentValue || keyword }
    querySubjectNameList({ ...params })
      .then((res) => {
        let data = []
        res.forEach((item: any) => {
          data.push({
            value: item.subjectId,
            label: item.subjectName,
            type: item.type,
            tabFlag: item.tabFlag,
          })
        })
        subjectOptions.value = data
        if (init === 'init') {
          emit('init', data)
        }
        // emit('getSubjectTypes', props.model.subjectId)
      })
      .catch(() => {
        message.error('搜索失败')
      })
  }
}
const fetch = (value: string) => {
  if (timeout) {
    clearTimeout(timeout)
    timeout = null
  }
  currentValue = value

  timeout = setTimeout(getSubjectName, 300)
}
defineExpose({
  getSubjectName,
})
</script>
