<template>
  <div>
    <div style="margin-bottom: 20px">
      <Select
        v-model:value="model[field]"
        show-search
        placeholder="请输入详细地址"
        :style="{ width }"
        :default-active-first-option="false"
        :show-arrow="false"
        :filter-option="false"
        :not-found-content="null"
        :options="data"
        :disabled="disabled"
        @search="handleSearch"
        @change="(value, option) => handleChange(value, option)"
      />
    </div>
    <div id="container" :style="{ height, width, zIndex }"></div>
    <div v-if="isShowLocation" class="location-show">
      <div>经度：{{ location?.lat || '' }}</div>
      <div>纬度：{{ location?.lng || '' }}</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import { Select, message } from '@jidu/robot-ui'
import { getSuggestionApi } from '/@/api/activityRegister'

let timeout: any
let currentValue = ''
const data = ref<any[]>([])
let map = {}
let markerLayer
let center = null
let location = ref({})
let address = ref('')
function fetch(value: string, callback: any) {
  if (timeout) {
    clearTimeout(timeout)
    timeout = null
  }
  currentValue = value

  function fake() {
    if (props?.model?.city) {
      value &&
        getSuggestionApi({ city: props.model.city[1], keyword: value }).then((d) => {
          if (currentValue === value) {
            const result = d.pojoList
            const data: any[] = []
            result.forEach((r: any) => {
              data.push({
                value: r.title,
                label: r.title,
                location: r.location,
                address: r.address,
              })
            })
            callback(data)
          }
        })
    } else {
      message.error('请先选择城市')
    }
  }

  timeout = setTimeout(fake, 300)
}
// export default defineComponent({
//   name: 'AMap',
//   components: {
//     Select,
//   },
let props = defineProps({
  width: {
    type: String,
    default: '500px',
  },
  height: {
    type: String,
    default: '300px',
  },
  zIndex: {
    type: String,
    default: '300',
  },
  model: Object,
  field: String,
  disabled: Boolean,
  isShowLocation: {
    type: Boolean,
    default: false,
  },
})

const handleSearch = (val: string) => {
  fetch(val, (d: any[]) => (data.value = d))
}
function handleChange(val: string, option) {
  location.value = option.location
  address.value = option.address
  location?.value?.lat && updateMark({ lat: location?.value?.lat, lng: location?.value?.lng })
}
function initMap() {
  //定义地图中心点坐标
  var center = new TMap.LatLng(39.98412, 116.307484)
  //定义map变量，调用 TMap.Map() 构造函数创建地图
  map = new TMap.Map(document.getElementById('container'), {
    center: center, //设置地图中心点坐标
    zoom: 17, //设置地图缩放级别
    pitch: 0, //设置俯仰角
    rotation: 0, //设置地图旋转角度
  })
  // 设置地图中心
  map.setCenter(center)
  // 创建并初始化MultiMarker
  markerLayer = new TMap.MultiMarker({
    map: map,
    styles: {
      // 点标记样式
      marker: new TMap.MarkerStyle({
        width: 20, // 样式宽
        height: 30, // 样式高
        anchor: { x: 10, y: 30 }, // 描点位置
      }),
    },
    geometries: [
      // 点标记数据数组
      {
        // 标记位置(经度，纬度，高度)
        position: center,
        id: 'marker',
      },
    ],
  })
}
function updateMark(params) {
  center = new TMap.LatLng(params.lat, params.lng)
  // 修改地图中心
  map.setCenter(center)
  // 更新标记
  markerLayer.updateGeometries([
    {
      styleId: 'marker',
      id: 'marker',
      position: new TMap.LatLng(params.lat, params.lng),
    },
  ])
  location.value = { lat: params.lat, lng: params.lng }
}
function clearTxMapInput() {
  props.model[props.field] = ''
  data.value = ''
}
defineExpose({
  location,
  address,
  updateMark,
  clearTxMapInput,
})
onMounted(() => {
  initMap()
})
onUnmounted(() => {
  map.destroy()
  markerLayer.destroy()
})
</script>
<style lang="less" scoped>
.location-show {
  margin-top: 10px;
  font-size: 14px;
  color: #a7a7a7;
}
</style>
