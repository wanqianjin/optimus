import { ref, onMounted } from 'vue'
import { fill } from 'lodash-es'
import { CompressModal } from './typing'

export function useCompressModal(props) {
  // 压缩弹窗列表
  const compressModalList = ref<CompressModal[]>([])
  // 每个弹窗状态，0:关闭；1:打开中；
  const modalStatusList = ref<Number[]>([])

  onMounted(() => {
    // 初始需填充弹窗列表，用于循环初始化modal实例
    compressModalList.value = Array(props?.maxCount)
      .fill({
        modalId: '',
        visible: false,
        limit: null,
        url: '',
      })
      .map((item) => {
        return { ...item }
      })
    modalStatusList.value = Array(props?.maxCount).fill(0)
  })

  // 弹窗数据替换
  function done(index, data) {
    const item = { ...compressModalList.value[index], ...data }
    fill(compressModalList.value, item, index, index + 1)
  }

  // 弹窗删除
  function remove(index) {
    compressModalList.value.splice(index, 1)
    const list = Array(props?.maxCount - compressModalList.value.length).fill({
      modalId: '',
      visible: false,
      limit: null,
      url: '',
    })
    compressModalList.value = [...compressModalList.value, ...list]
  }

  // 更新弹窗状态
  function updateStatus(index, data) {
    fill(modalStatusList.value, data, index, index + 1)
  }

  return { compressModalList, modalStatusList, done, remove, updateStatus }
}
