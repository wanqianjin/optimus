export interface WHProportion {
  width: number
  height: number
}

export interface FormatParams {
  type: string
  showAll: boolean
}

export interface Prompts {
  //提示文案
  text: string
  //文案位置，包括四个属性值：top, bottom, left, right
  placement: string
}

export interface FileItem {
  uid: string
  name?: string
  status?: string
  response?: UploadApiResult
  percent?: number
  url?: string
  preview?: string
  originFileObj?: any
}

export enum UploadStatusEnum {
  ERROR = 'error',
  SUCCESS = 'success',
  DONE = 'done',
  UPLOADING = 'uploading',
  REMOVED = 'removed',
}

export interface UploadApiResult {
  code: number
  msg: string
  result: string | object
}

export interface CompressModal {
  modalId: string | number
  visible: boolean
  limit: number | null
  url: string
  status?: string
}
