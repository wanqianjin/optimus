<template>
  <div>
    <!-- 上传组件，包括上传文件的大小、类型等提示文字，提示文字会在上传组件的上下左右方向 -->
    <div :class="`upload-content ${getContainerClass}`">
      <!-- 上传组件 -->
      <div>
        <Upload
          ref="uploadRef"
          v-model:file-list="fileListRef"
          v-bind="{ ...propOption }"
          :headers="headers"
          :list-type="listType"
          :action="url"
          :accept="accept"
          :multiple="isMultiple"
          :key="uploadKey"
          :before-upload="handleBeforeUpload"
          @change="handleChange"
          @preview="handlePreview"
        >
          <slot name="action">
            <Button
              v-if="listType === 'picture' || listType === 'text'"
              :disabled="propOption?.disabled || isCanOperate"
            >
              <upload-outlined />
              <span style="margin-left: 8px">单击上传</span>
            </Button>
            <div
              v-if="listType === 'picture-card' && !isCanOperate"
              style="display: flex; flex-direction: column; align-items: center"
            >
              <plus-outlined />
              <span>点击上传</span>
            </div>
          </slot>
        </Upload>
      </div>
      <!-- 文字提示 -->
      <div v-if="prompts?.text" style="margin: auto 0">
        <span class="prompts-text">{{ prompts?.text }}</span>
        <div class="prompts-text" v-if="prompts?.more">{{ prompts?.more }}</div>
      </div>
    </div>
    <!-- 上传结果列表 -->
    <div v-if="fileListRef?.length > 0 && isShowResult"></div>
    <!-- 以卡片形式展示的结果列表 -->
    <Card v-if="fileListRef?.length > 0 && isShowResultCard" />
  </div>
  <!-- 预览弹窗 -->
  <Modal :visible="previewVisible" :footer="null" @cancel="handleCancel">
    <img alt="example" style="width: 100%" :src="previewImage" />
  </Modal>
  <!-- 压缩图片需要展示的弹窗 -->
  <template v-if="isCompress">
    <template v-for="(item, index) in compressModalList" :key="index">
      <CompressModal
        :visible="item.visible"
        :limit="item.limit"
        :imgUrl="item.url"
        @close-modal="closeCompressModal(index, 'close-modal')"
        @re-upload="handleReUpload(index)"
      />
    </template>
  </template>
</template>
<script setup lang="ts">
import { toRefs, computed, ref, watch, unref } from 'vue'
import { Upload, Modal, Button, Card, message } from '@jidu/robot-ui'
import { PlusOutlined, UploadOutlined } from '@ant-design/icons-vue'
import CompressModal from './components/CompressModal.vue'
import { useUpload } from './useUpload'
import { useCompressModal } from './useCompressModal'
import { getToken } from '/@/utils/auth'
import { buildUUID } from '/@/utils/uuid'
import { isString, isArray, isNullOrUnDef, isFunction } from '/@/utils/is'
import { findIndex } from 'lodash-es'
import { FileItem, UploadStatusEnum } from './typing'
import { getImgWidthOrHeight, checkFileType, isImgTypeByName, getBase64 } from './helper'
import { basicUploadProps, basicUploadEmits } from './props'

const props = defineProps(basicUploadProps)
const emit = defineEmits(basicUploadEmits)
const {
  uploadValue,
  isShowResult,
  isShowResultCard,
  acceptType,
  listType,
  isCompress,
  isMultiple,
  maxCount,
  prompts,
  propOption,
} = toRefs(props)
const { accept, uploadKey, getContainerClass, url, setUrl } = useUpload(props)
const { compressModalList, modalStatusList, done, remove, updateStatus } = useCompressModal(props)
let uploadRef = ref(null)

// 上传内容数据初始化
let fileListRef = ref<FileItem[]>([])
const headers = { Authorization: getToken() }

// 文件查看数据初始化
let previewVisible = ref<boolean>(false)
let previewImage = ref<string | undefined>('')

// 上传单选/多选时是否可操作
let isCanOperate = computed(() => {
  if (isMultiple.value) {
    return fileListRef.value.length >= maxCount.value
  }
  return fileListRef.value.length >= 1
})

watch(
  () => uploadValue.value,
  (newValue) => {
    // 监测数据回显赋值给fileList
    if (newValue && fileListRef.value.length === 0) {
      // 部分业务存储为数组
      if (isArray(newValue) && newValue?.length > 0) {
        fileListRef.value = newValue?.map((item, index) => {
          let uid = buildUUID()

          // 若为图片上传且需要压缩，则压缩弹窗初始化
          if (isCompress.value) {
            done(index, { modalId: uid })
          }

          return {
            uid: uid,
            status: 'done',
            response: { code: 0, result: isString(item) ? item : '', msg: 'success' },
            url: isString(item) ? item : '',
          }
        })
      } // 部分业务存储文件url
      else if (!isNullOrUnDef(newValue) && isString(newValue)) {
        fileListRef.value = [
          {
            uid: buildUUID(),
            status: 'done',
            response: { code: 0, result: newValue || '', msg: 'success' },
            url: newValue,
          },
        ]
      }
    }
  },
  { deep: true, immediate: true },
)

function handleChange(e) {
  const { onChangeFn } = props
  const { status, response, uid } = e?.file
  let index
  switch (status) {
    case UploadStatusEnum.DONE:
      // 获取当前变化的文件的索引
      index = findIndex(e?.fileList, (item) => item?.uid === e?.file.uid)
      handleModalList(status, index, uid)
      handleUploadDone(e, response, index)
      break
    case UploadStatusEnum.ERROR:
      message.error(`上传失败`)
      break
    case UploadStatusEnum.REMOVED:
      // 获取当前变化的文件的索引
      index = findIndex(compressModalList.value, (item) => item?.modalId === e?.file.uid)
      handleModalList(status, index, uid)
      handleUploadRemoved(e)
      break
    case UploadStatusEnum.UPLOADING:
      handleUploading(e)
      break
    default:
      fileListRef.value = []
      break
  }
  // 如果外部组件有自定义change操作，则需处理
  if (onChangeFn && isFunction(onChangeFn)) {
    onChangeFn(e, response)
  }
}

// 文件上传状态为done时的处理
function handleUploadDone(e, response, index) {
  const { isGetUrl } = props
  let result: string | any[] = getResultImgs(e)
  setFileList(result)

  // 若上传的是图片，默认接口上传会包含压缩服务
  if (response.code === 0 || response.code === 40015 || response.code === 40016) {
    if (isGetUrl) {
      if (isArray(result)) {
        emit(
          'update:uploadValue',
          result?.map(({ url }) => url),
        )
      }
      emit('update:uploadValue', result)
    }

    // code为40015表示压缩符合目标，40016压缩后大于目标值，可以选择重新上传压缩
    if ((response.code === 40015 || response.code === 40016) && isCompress.value) {
      if (isImgTypeByName(e?.file)) {
        // 压缩图片弹窗逻辑
        done(index, {
          visible: true,
          limit: response?.result?.fileMaxSize,
          url: response?.result?.url,
        })
        // 更新对应弹窗状态为打开
        updateStatus(index, 1)
        return
      }
    }
    // 确认单张图上传成功后，emit value值更新事件,若code === 40015 | 40016, 则不emit
    if (isGetUrl) {
      if (!isArray(result)) {
        emit('changeValue', result)
      }
    }
  } else {
    message.error(e?.file.response.msg ?? '上传失败')
    emit('error', e?.file.response.msg ?? '上传失败')
  }
}

// 文件上传状态为removed时的处理
function handleUploadRemoved(e) {
  let result
  if (isArray(getResultImgs(e))) {
    result = getResultImgs(e)?.map(({ url }) => url)
  } else {
    result = getResultImgs(e)
  }
  emit('update:uploadValue', result)
  emit('remove', e)
}

// 文件上传状态为uploading时的处理
function handleUploading(e) {
  if (isMultiple.value) {
    fileListRef.value = e?.fileList
  } else {
    fileListRef.value = [e?.file]
  }
}

// 文件处理单张/多张时的数据获取
function getResultImgs(e) {
  let result: string | any[] = ''
  if (isMultiple.value) {
    result = e?.fileList?.map(({ uid, status, response }) => {
      if (isString(response?.result)) {
        return { uid, status, url: response?.result ?? '' }
      } else {
        return { uid, status, url: response?.result?.url ?? '' }
      }
    })
  } else {
    let url = isString(e?.fileList?.[0]?.response?.result)
      ? e?.fileList?.[0]?.response?.result
      : e?.fileList?.[0]?.response?.result?.url
    result = url ?? ''
  }
  return result
}

// 设置fileListRef值
function setFileList(value) {
  if (isMultiple.value) {
    fileListRef.value = value
      ?.filter((item) => {
        return [UploadStatusEnum.UPLOADING, UploadStatusEnum.DONE].includes(item?.status)
      })
      .map((item) => {
        return {
          uid: item?.uid || buildUUID(),
          status: item?.status,
          response: { code: 0, result: item?.url, msg: 'success' },
          url: item?.url,
        }
      })
  } else {
    if (value) {
      fileListRef.value = [
        {
          uid: buildUUID(),
          status: 'done',
          response: { code: 0, result: value || '', msg: 'success' },
          url: value,
        },
      ]
    } else {
      fileListRef.value = []
    }
  }
}

// 预览
async function handlePreview(file: FileItem) {
  let url = file?.url || file?.response?.result
  if (url && isImgTypeByName(file)) {
    // 图片
    if (!file.url && !file.preview) {
      file.preview = (await getBase64(file.originFileObj)) as string
    }
    previewImage.value = file.url || file.preview
    previewVisible.value = true
  } else {
    url && window.open(url, '_blank')
  }
}

function handleCancel() {
  previewVisible.value = false
}

// 上传文件前的校验
function handleBeforeUpload(file: File) {
  // 若需要压缩并已经执行了上传操作，则关闭压缩判断的弹窗
  if (isCompress.value) {
    let modalIndex = modalStatusList.value?.findIndex((item) => item === 2)
    if (modalIndex >= 0) {
      closeCompressModal(modalIndex)
      fileListRef.value.splice(modalIndex, 1)
      // 需要重置上传接口，不执行压缩
      setUrl(false)
    } else {
      setUrl(true)
    }
  }

  const { isGetWH, maxSize, maxWidth, maxHeight, widthAndHeightList } = toRefs(props)
  const { beforeUpload } = unref(propOption.value ?? {})
  return new Promise(async (resolve, _reject) => {
    try {
      // 获取宽高
      if (isGetWH.value) {
        const widthAndHeight: any = await getImgWidthOrHeight(file)
        emit('getWidthHeight', widthAndHeight)
      }
      //自定义beforeUpload
      if (beforeUpload && isFunction(beforeUpload)) {
        const result = await beforeUpload(...arguments)
        if (!result) {
          return Upload.LIST_IGNORE
        }
      }
      //校验类型
      if (acceptType.value.length && !checkFileType(file, acceptType.value)) {
        const title = acceptType.value.join('/')
        message.warning(`只能上传${title}格式`)
        return Upload.LIST_IGNORE
      }
      // 校验大小
      if (maxSize?.value && file.size / 1024 / 1024 > maxSize?.value) {
        message.warning(`大小不能超过${maxSize?.value}M`)
        return Upload.LIST_IGNORE
      }
      // 校验宽高
      if (maxWidth?.value || maxHeight?.value) {
        const widthAndHeight: any = await getImgWidthOrHeight(file)
        if (
          (maxWidth?.value && maxWidth?.value !== widthAndHeight.width) ||
          (maxHeight?.value && maxHeight?.value !== widthAndHeight.height)
        ) {
          message.warning('请上传正确宽高的图片')
          return Upload.LIST_IGNORE
        }
      }
      // 判断宽高比列
      if (widthAndHeightList?.value && widthAndHeightList?.value?.length) {
        const widthAndHeight: any = await getImgWidthOrHeight(file)
        const comparisons = (widthAndHeight?.width / widthAndHeight?.height).toFixed(2)
        const isWHProportion = widthAndHeightList?.value?.some(
          (item) => (item.width / item.height).toFixed(2) === comparisons,
        )
        if (!isWHProportion) {
          message.warning('请上传正确宽高比例的图片')
          return Upload.LIST_IGNORE
        }
      }
      return resolve(true)
    } catch (error) {
      console.log('error===', error)
      return Upload.LIST_IGNORE
    }
  })
}

function handleModalList(status, index, uid) {
  if (status === 'done') {
    done(index, { modalId: uid })
  } else if (status === 'removed') {
    remove(index)
  }
}

function closeCompressModal(index, type) {
  // 只有单图,emit value确认改变事件
  if (compressModalList.value.length === 1 && type === 'close-modal') {
    emit('changeValue', compressModalList.value[0].url)
  }

  done(index, {
    visible: false,
    limit: null,
    url: '',
  })
  updateStatus(index, 0)
}

// 重新上传
function handleReUpload(index) {
  const upload = unref(uploadRef.value)
  const uploadEl: Element = upload.$el
  uploadEl.querySelector('.r-upload-select input').click()

  // 确定重新上传设置弹窗状态
  updateStatus(index, 2)
}
</script>
<style lang="less" scoped>
.upload-content {
  display: flex;

  .prompts-text {
    color: #b4b1c1;
    font-size: 14px;
  }
}

.upload-placement-right {
  flex-direction: row;
}

.upload-placement-left {
  flex-direction: row-reverse;
  justify-content: flex-end;
}

.upload-placement-top {
  flex-direction: column-reverse;
}

.upload-placement-bottom {
  flex-direction: column;
}
</style>
