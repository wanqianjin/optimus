import { ref, toRefs, onMounted, computed } from 'vue'
import { buildUUID } from '/@/utils/uuid'

export function useUpload(props) {
  const { action, acceptType, type, isCompress, prompts, formatParams } = toRefs(props)
  const VITE_GLOB_API_URL = import.meta.env.VITE_GLOB_API_URL

  // 上传接口
  const url = ref('')
  // 上传的文件类型
  const accept = computed(() => {
    return acceptType.value
      ?.map((item) => {
        if (item.indexOf('/') > 0 || item.startsWith('.')) {
          return item
        } else {
          return `.${item}`
        }
      })
      .join(',')
  })
  const uploadKey = computed(() => {
    return buildUUID() + Date.now()
  })
  // 上传组件及提示文案样式
  const getContainerClass = computed(() => {
    const { placement } = prompts.value
    return `upload-placement-${placement}`
  })

  onMounted(() => {
    setUrl()
  })

  // url赋值
  const setUrl = (needCompress: Boolean = true) => {
    const api = action.value
      ? action.value
      : 'b/content-backend/backend/upload/uploadFileWithCompress'
    if (type.value === 'video') {
      url.value = `${VITE_GLOB_API_URL}/${api}?type=${formatParams.value.type}&showAll=${formatParams.value.showAll}`
    } else if (type.value === 'image' && isCompress.value) {
      url.value = `${VITE_GLOB_API_URL}/${api}?needCompress=${needCompress}`
    } else {
      url.value = `${VITE_GLOB_API_URL}/${api}`
    }
  }

  return { accept, uploadKey, getContainerClass, url, setUrl }
}
