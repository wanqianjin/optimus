import type { PropType } from 'vue'
import { WHProportion, FormatParams, Prompts } from './typing'

export const basicUploadProps = {
  /**
   * 上传文件内容
   * @default: ''
   */
  uploadValue: {
    type: [String, Array] as PropType<string | string[]>,
    default: '',
  },
  /**
   * 上传接口
   * @default: ''
   */
  action: {
    type: String as PropType<string>,
  },
  /**
   * 是否获取上传文件URL
   * @default: false
   */
  isGetUrl: {
    type: Boolean as PropType<boolean>,
    default: true,
  },
  /**
   * 是否展示上传列表
   * @default: false
   */
  isShowResult: {
    type: Boolean as PropType<boolean>,
    default: false,
  },
  /**
   * 上传结果是否以卡片形式展示
   * @default: false
   */
  isShowResultCard: {
    type: Boolean as PropType<boolean>,
    default: false,
  },
  /**
   * 上传图片类型限制
   * @default: ['jpg', 'png', 'jpeg', 'gif']
   */
  acceptType: {
    type: Array as PropType<string[]>,
    default: () => ['png', 'jpg', 'jpeg', 'bmp', 'gif', 'tiff'],
  },
  /**
   * 组件的内建样式
   * @default: 'picture-card'
   */
  listType: {
    type: String as PropType<string>,
    default: 'picture-card',
    validator: (v: string) => {
      return ['text', 'picture', 'picture-card'].includes(v)
    },
  },
  /**
   * 判断上传的文件类型
   * @default: 'image'
   */
  type: {
    type: String as PropType<string>,
    default: 'image',
  },
  /**
   * 是否需要压缩服务
   * @default: true
   */
  isCompress: {
    type: Boolean as PropType<boolean>,
    default: true,
  },
  /**
   * 是否可多张上传
   * @default: false
   */
  isMultiple: {
    type: Boolean as PropType<boolean>,
    default: false,
  },
  /**
   * 限制上传数量
   * @default: 1
   */
  maxCount: {
    type: Number as PropType<number>,
    default: 1,
  },
  /**
   * 是否获取图片宽高
   * @default: false
   */
  isGetWH: {
    type: Boolean as PropType<boolean>,
    default: false,
  },
  /**
   * 上传图片最大宽度
   * @default: 0
   */
  maxWidth: {
    type: Number as PropType<number>,
  },
  /**
   * 上传图片最大高度
   * @default: 0
   */
  maxHeight: {
    type: Number as PropType<number>,
  },
  /**
   * 上传图片比例
   * @default: [{width: 0, height: 0}]
   */
  widthAndHeightList: {
    type: Array as PropType<WHProportion[]>,
  },
  /**
   * 上传图片大小限制
   * @default: 0
   */
  maxSize: {
    type: Number as PropType<number>,
    default: 10,
  },
  /**
   * 组件对应的提示文案
   * @default: {text: '', placement: 'right'}
   */
  prompts: {
    type: Object as PropType<Prompts>,
    default: { text: '', more: '', placement: 'right' },
  },
  /**
   * change方法配置
   * @default: {}
   */
  onChangeFn: {
    type: Function as PropType<(...args) => void>,
    default: null,
  },
  /**
   * 原antdv upload组件参数
   * @default: {}
   */
  propOption: {
    type: Object,
    default: () => {},
  },
  /**
   * 视频是否转码，type:file格式，showAll:是否同时返回file原格式+type指定上传格式两个文件链接，目前只有type=m3u8时支持showAll为true
   */
  formatParams: {
    type: Object as PropType<FormatParams>,
    default: () => {
      return {
        type: 'mp4',
        showAll: false,
      }
    },
  },
  /**
   * 压缩质量，为80则服务端自动设置
   */
  quality: {
    type: Number as PropType<number>,
    default: 80,
  },
}

export const basicUploadEmits = [
  'update:uploadValue',
  'getWidthHeight',
  'remove',
  'changeValue',
  'error',
]
