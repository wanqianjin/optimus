import { FileItem } from './typing'
import { message } from '@jidu/robot-ui'

export function getBase64(file: File) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = () => resolve(reader.result)
    reader.onerror = (error) => reject(error)
  })
}

// 检查文件类型
export function checkFileType(file: File, accepts: string[]): boolean {
  const newTypes = accepts
    .map((item) => {
      if (item.indexOf('/') > 0) {
        return item.split('/').join('\\/')
      } else if (item.startsWith('.')) {
        return item
      } else {
        return `.${item}`
      }
    })
    .join('|')
  //文件后缀判断
  const suffixReg = new RegExp('\\' + newTypes + '$', 'i')
  //文件类型判断
  const typeReg = new RegExp('^' + newTypes, 'i')

  return suffixReg.test(file.name || '') || typeReg.test(file.type || '')
}

export function isImgTypeByName(file: FileItem): boolean {
  let isImg = false
  //获取文件后缀
  const fileType = file?.url?.split('.').pop() || file?.name?.split('.').pop() || ''
  //判断是否是图片类型
  if (
    ['png', 'jpg', 'jpeg', 'bmp', 'gif', 'webp', 'psd', 'svg', 'tiff'].indexOf(
      fileType.toLowerCase(),
    ) != -1
  ) {
    isImg = true
  } else {
    isImg = false
  }
  return isImg
}

// 获取上传组件图片/视频宽高
export function getImgWidthOrHeight(file: File): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    // 根据文件的MIME类型判断是图片还是视频
    const fileType = file.type
    const isImage = fileType.startsWith('image/')
    const isVideo = fileType.startsWith('video/')

    if (isImage) {
      const image = new Image()
      const reader = new FileReader()
      reader.readAsDataURL(file)
      reader.onload = (event) => {
        image.src = event.target.result
        image.onload = () => {
          resolve({ width: image.width, height: image.height })
        }
        image.onerror = () => {
          message.warning(`图片加载错误`)
          reject(new Error('图片加载错误'))
        }
      }
      reader.onerror = () => {
        message.warning(`文件读取错误`)
        reject(new Error('文件读取错误'))
      }
    } else if (isVideo) {
      const video = document.createElement('video')
      video.preload = 'metadata'
      const reader = new FileReader()
      reader.readAsArrayBuffer(file)
      reader.onload = (event) => {
        const url = URL.createObjectURL(new Blob([event.target.result]))
        video.src = url
        video.onloadedmetadata = () => {
          resolve({ width: video.videoWidth, height: video.videoHeight })
          URL.revokeObjectURL(url) // 释放内存
        }
        video.onerror = () => {
          message.warning(`视频加载错误`)
          reject(new Error('视频加载错误'))
        }
      }
      reader.onerror = () => {
        message.warning(`文件读取错误`)
        reject(new Error('文件读取错误'))
      }
    } else {
      message.warning(`上传错误`)
      reject(new Error('上传错误'))
    }
  })
}
