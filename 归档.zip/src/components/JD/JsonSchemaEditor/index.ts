import JsonSchemaEditor from './src/JsonSchemaEditor.vue'

JsonSchemaEditor.install = function (Vue) {
  Vue.component(JsonSchemaEditor.name, JsonSchemaEditor)
}

export default JsonSchemaEditor
