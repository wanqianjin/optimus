<template>
  <MenuItem
    :name="item.path"
    v-if="!menuHasChildren(item) && getShowMenu"
    v-bind="$props"
    :class="getLevelClass"
  >
    <Icon v-if="getIcon" :icon="getIcon" :size="16" />
    <div v-if="collapsedShowTitle && getIsCollapseParent" class="mt-1 collapse-title">
      {{ getI18nName }}
    </div>
    <template #title>
      <span :class="['ml-2', `${prefixCls}-sub-title`]">
        {{ getI18nName }}
      </span>
      <SimpleMenuTag :item="item" :collapseParent="getIsCollapseParent" />
    </template>
  </MenuItem>
  <SubMenu
    :name="item.path"
    v-if="menuHasChildren(item) && getShowMenu"
    :class="[getLevelClass, theme]"
    :collapsedShowTitle="collapsedShowTitle"
  >
    <template #title>
      <component v-if="getIcon" :is="getIcon" />
      <!-- <Icon v-if="getIcon" :icon="getIcon" :size="16" /> -->
      <div v-if="collapsedShowTitle && getIsCollapseParent" class="mt-2 collapse-title">
        {{ getI18nName }}
      </div>

      <span v-show="getShowSubTitle" :class="['ml-2', `${prefixCls}-sub-title`]">
        {{ getI18nName }}
      </span>
      <SimpleMenuTag :item="item" :collapseParent="!!collapse && !!parent" />
    </template>
    <template v-for="childrenItem in item.children || []" :key="childrenItem.path">
      <SimpleSubMenu v-bind="$props" :item="childrenItem" :parent="false" />
    </template>
  </SubMenu>
</template>
<script lang="ts">
import type { PropType } from 'vue'
import type { Menu } from '/@/router/types'

import { defineComponent, computed } from 'vue'
import { useDesign } from '/@/hooks/web/useDesign'
import Icon from '/@/components/Icon/index'
import {
  // 页面管理
  PageManagerIcon,
  // 审核管理
  AuditsManagementIcon,
  // 内容管理
  ContentIcon,
  // 活动管理
  EventManagementIcon,
  // 积分管理
  PointsManagementIcon,
  // 消息触达
  MessageReachIcon,
  // 权益中心
  NationalCenterForLesbianRightsIcon,
  // 资源外管理
  ResourceLevelManagementIcon,
  // 评论管理
  CommentManagementIcon,
  // 公众号管理
  OfficialAccountManagementIcon,
  // 标签管理
  LabelManagementIcon,
  // 渠道管理
  ChannelManagementIcon,
  // 协议管理
  ProtocolManagementIcon,
  // 营销中心
  MarketingCenterIcon,
  // 广告管理
  AdvertisementManagementIcon,
  // 用户管理
  UserManagementIcon,
  // 场景化服务
  ScenarioizedServicesIcon,
  // 投放管理
  KeyboardShortcutsIcon,
  // 用户操作日志
  LogSearchIcon,
  // 搜索配置
  SearchIcon,
  // 海报管理
  QuestionnaireIcon,
  // 云配置
  CloudConfigurationIcon,
} from '@robot/icon'

import MenuItem from './components/MenuItem.vue'
import SubMenu from './components/SubMenuItem.vue'
import { propTypes } from '/@/utils/propTypes'
import { useI18n } from '/@/hooks/web/useI18n'
import { createAsyncComponent } from '/@/utils/factory/createAsyncComponent'

export default defineComponent({
  name: 'SimpleSubMenu',
  components: {
    SubMenu,
    MenuItem,
    SimpleMenuTag: createAsyncComponent(() => import('./SimpleMenuTag.vue')),
    Icon,
    PageManagerIcon,
    AuditsManagementIcon,
    ContentIcon,
    EventManagementIcon,
    PointsManagementIcon,
    MessageReachIcon,
    NationalCenterForLesbianRightsIcon,
    ResourceLevelManagementIcon,
    CommentManagementIcon,
    OfficialAccountManagementIcon,
    LabelManagementIcon,
    ChannelManagementIcon,
    ProtocolManagementIcon,
    MarketingCenterIcon,
    AdvertisementManagementIcon,
    UserManagementIcon,
    ScenarioizedServicesIcon,
    KeyboardShortcutsIcon,
    LogSearchIcon,
    SearchIcon,
    QuestionnaireIcon,
    CloudConfigurationIcon,
  },
  props: {
    item: {
      type: Object as PropType<Menu>,
      default: () => ({}),
    },
    parent: propTypes.bool,
    collapsedShowTitle: propTypes.bool,
    collapse: propTypes.bool,
    theme: propTypes.oneOf(['dark', 'light']),
  },
  setup(props) {
    const { t } = useI18n()
    const { prefixCls } = useDesign('simple-menu')

    const getShowMenu = computed(() => !props.item?.meta?.hideMenu)
    const getIcon = computed(() => props.item?.icon)
    const getI18nName = computed(() => t(props.item?.name))
    const getShowSubTitle = computed(() => !props.collapse || !props.parent)
    const getIsCollapseParent = computed(() => !!props.collapse && !!props.parent)
    const getLevelClass = computed(() => {
      return [
        {
          [`${prefixCls}__parent`]: props.parent,
          [`${prefixCls}__children`]: !props.parent,
        },
      ]
    })

    function menuHasChildren(menuTreeItem: Menu): boolean {
      return (
        !menuTreeItem.meta?.hideChildrenInMenu &&
        Reflect.has(menuTreeItem, 'children') &&
        !!menuTreeItem.children &&
        menuTreeItem.children.length > 0
      )
    }

    return {
      prefixCls,
      menuHasChildren,
      getShowMenu,
      getIcon,
      getI18nName,
      getShowSubTitle,
      getLevelClass,
      getIsCollapseParent,
    }
  },
})
</script>
