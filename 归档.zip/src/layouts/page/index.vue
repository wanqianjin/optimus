<template>
  <MicroIFrame
    v-if="isUseMicroIframe"
    class="micro-iframe"
    source="optimus"
    :env="env"
    :token="token"
    :intranet="true"
    :meta="currentEembeddedRouteMeta"
  />
  <RouterView v-else>
    <template #default="{ Component, route }">
      <transition
        :name="
          getTransitionName({
            route,
            openCache,
            enableTransition: getEnableTransition,
            cacheTabs: getCaches,
            def: getBasicTransition,
          })
        "
        mode="out-in"
        appear
      >
        <div>
          <MarketingTip :path="route.fullPath" />
          <keep-alive v-if="openCache" :include="getCaches" :key="Date.now()">
            <component :is="Component" :key="route.fullPath" />
          </keep-alive>
          <component v-else :is="Component" :key="route.fullPath" />
        </div>
      </transition>
    </template>
  </RouterView>

  <!-- vben的iframe，不太好用，token难以控制 -->
  <FrameLayout v-if="getCanEmbedIFramePage" />
</template>

<script lang="ts">
import { computed, defineComponent, unref } from 'vue'
import { useRouter } from 'vue-router'

import { MicroIFrame, IEembeddedRouteMeta } from '@jidu/micro-iframe'

import FrameLayout from '/@/layouts/iframe/index.vue'

import { useRootSetting } from '/@/hooks/setting/useRootSetting'

import { useTransitionSetting } from '/@/hooks/setting/useTransitionSetting'
import { useMultipleTabSetting } from '/@/hooks/setting/useMultipleTabSetting'
import { getTransitionName } from './transition'

import { useMultipleTabStore } from '/@/store/modules/multipleTab'
import { useUserStore } from '/@/store/modules/user'
import MarketingTip from '/@/components/MarketingTip/index.vue'

export default defineComponent({
  name: 'PageLayout',
  components: { MarketingTip, FrameLayout, MicroIFrame },
  setup() {
    const router = useRouter()
    const userStore = useUserStore()
    const { getShowMultipleTab } = useMultipleTabSetting()
    const tabStore = useMultipleTabStore()

    const { getOpenKeepAlive, getCanEmbedIFramePage } = useRootSetting()

    const { getBasicTransition, getEnableTransition } = useTransitionSetting()

    const token = computed<string>(() => {
      return userStore?.getToken
    })

    const openCache = computed(() => unref(getOpenKeepAlive) && unref(getShowMultipleTab))

    const getCaches = computed((): string[] => {
      if (!unref(getOpenKeepAlive)) {
        return []
      }
      return tabStore.getCachedTabList
    })

    const currentEembeddedRouteMeta = computed<IEembeddedRouteMeta>(() => {
      return router?.currentRoute?.value?.meta?.microIframe as IEembeddedRouteMeta
    })

    const env = computed(() => {
      console.log('layout-环境', import.meta.env.MODE)
      return import.meta.env.MODE || 'prod'
    })

    const isUseMicroIframe = computed(() => {
      return Boolean(currentEembeddedRouteMeta.value)
    })

    return {
      env,
      token,
      getTransitionName,
      openCache,
      getEnableTransition,
      getBasicTransition,
      getCaches,
      getCanEmbedIFramePage,

      isUseMicroIframe,
      currentEembeddedRouteMeta,
    }
  },
})
</script>

<style lang="less" scoped>
.micro-iframe {
  width: 100%;
  height: calc(100% + 24px);
}
</style>
