<template>
  <div
    :class="[prefixCls, getLayoutContentMode]"
    :style="{ marginTop: bannerWrapShow ? '38px' : '0px' }"
    v-loading="getOpenPageLoading && getPageLoading"
  >
    <LayoutBreadcrumb />
    <PageLayout />
  </div>
</template>
<script lang="ts">
import { defineComponent, inject } from 'vue'
import PageLayout from '/@/layouts/page/index.vue'
import { useDesign } from '/@/hooks/web/useDesign'
import { useRootSetting } from '/@/hooks/setting/useRootSetting'
import { useTransitionSetting } from '/@/hooks/setting/useTransitionSetting'
import { useContentViewHeight } from './useContentViewHeight'
import { LayoutBreadcrumb } from '../header/components'

export default defineComponent({
  name: 'LayoutContent',
  components: { PageLayout, LayoutBreadcrumb },
  setup() {
    const { prefixCls } = useDesign('layout-content')
    const { getOpenPageLoading } = useTransitionSetting()
    const { getLayoutContentMode, getPageLoading } = useRootSetting()
    const { bannerWrapShow } = inject('bannerState')

    useContentViewHeight()
    return {
      prefixCls,
      getOpenPageLoading,
      getLayoutContentMode,
      getPageLoading,
      bannerWrapShow,
    }
  },
})
</script>
<style lang="less">
@prefix-cls: ~'@{namespace}-layout-content';

.@{prefix-cls} {
  position: relative;
  flex: 1 1 auto;
  min-height: 0;

  &.fixed {
    width: 1200px;
    margin: 0 auto;
  }

  &.banner {
    margin-top: 38px;
  }

  &-loading {
    position: absolute;
    top: 200px;
    z-index: @page-loading-z-index;
  }
}
</style>
