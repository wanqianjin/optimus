<template>
  <!-- notify -->
  <LayoutHeader
    class="banner-wrap"
    v-if="bannerShow"
    :style="{ height: `${LAYOUT_BANNER_HEIGHT}px` }"
  >
    <div class="banner-content-wrap">
      <ExplainFillIcon :style="{ color: '#7c40ff', marginRight: '9px', fontSize: '18px' }" />
      <div class="banner-content" v-html="bannerContent"></div>
    </div>
    <div class="banner-close-wrap" @click="closeBanner">
      <CloseIcon />
    </div>
  </LayoutHeader>
</template>
<script lang="ts">
import { defineComponent, onMounted, ref } from 'vue'
import { CloseIcon, ExplainFillIcon } from '@robot/icon'
// import { getBanner } from '/@/api/notification'
import { LayoutHeader } from '@jidu/robot-ui'
// import { useWebsocket } from '/@/hooks/web/useWebsocket'
// import { API } from '/@/api/common/ws'
import { LAYOUT_BANNER_HEIGHT } from './constants'
export default defineComponent({
  name: 'Banner',
  components: {
    CloseIcon,
    LayoutHeader,
    ExplainFillIcon,
  },
  emits: ['getBanner'],
  setup(props, { emit }) {
    const bannerContent = ref(
      '擎天柱菜单结构已进行重新梳理，可参考<a href="https://jiduauto.feishu.cn/wiki/G6jBwycCliSPAikYf4WcVOz9nKa" target="_blank">菜单结构对照</a>搜索原有菜单路径',
    )
    const bannerShow = ref(true)
    // const bannerContent = ref('')
    // 初始化 websocket (列表状态变更)
    // useWebsocket({
    //   url: API.fotaWebsocketUrl,
    //   eventType: 'suspendBanner',
    //   retryTimes: 5,
    //   success: (resData) => {
    //     console.log('data', resData)
    //     if (resData) {
    //       // 只要有返回消息就请求banner
    //       getBannerContent()
    //     }
    //   },
    // })

    onMounted(() => {
      emit('getBanner', { bannerShow })
    })

    // 获取横幅信息
    // const getBannerContent = async () => {
    //   const banner = await getBanner()
    //   if (banner.maintenance) {
    //     bannerContent.value = banner.content
    //     bannerShow.value = true
    //     emit('getBanner', { bannerShow })
    //   } else {
    //     closeBanner()
    //   }
    // }

    const closeBanner = () => {
      bannerShow.value = false
      emit('getBanner', { bannerShow })
    }
    return {
      CloseIcon,
      closeBanner,
      bannerContent,
      bannerShow,
      LAYOUT_BANNER_HEIGHT,
    }
  },
})
</script>
<style lang="less">
.banner-wrap {
  position: fixed;
  background-color: #f3f0ff;
  z-index: 505;
  width: 100%;
  text-align: center;
  line-height: 38px;

  .banner-content-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .banner-close-wrap {
    width: 38px;
    height: 38px;
    position: absolute;
    right: 0;
    top: 0;
    line-height: 30px;
    cursor: pointer;
  }

  .banner-content {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
</style>
