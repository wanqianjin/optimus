export enum UserCenterOperationEventEnum {
  '复制手机号' = 1,
  '批量复制手机号' = 2,
  '批量导出' = 3,
  '修改手机号' = 4,
  '强制用户下线' = 5,
  '解绑三方账号' = 6,
  '添加黑名单' = 7,
  '批量添加黑名单' = 8,
  '删除黑名单' = 9,
  '添加虚拟账号' = 10,
  '删除虚拟账号' = 11,
  '批量顺序导出' = 12,
  '重置昵称' = 13,
  '重置头像' = 14,
}

export enum LoginStatus {
  '登录' = 1,
  '登出' = 2,
  '离线' = 3,
}

export enum LoginClassStatus {
  'table_green' = 1,
  'table_grey' = 2,
  'table_red' = 3,
}

export enum GenderList {
  '未填写' = 0,
  '男' = 1,
  '女' = 2,
  '保密' = 3,
}
