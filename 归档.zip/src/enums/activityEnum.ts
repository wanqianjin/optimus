export enum ActivityType {
  // 权益发放
  Rights = 101,
  // 抽奖
  Lottery = 102,
  // 裂变
  Fission = 103,
  // 积分红包
  Score = 201,
  // 新春红包
  Spring = 301,
  // 三里屯活动
  Sanlitun = 401,
  // 报名活动
  Enroll = 501,
}

// 关联活动类型
export enum AssociatedActivityFlagType {
  // 否
  NoAssociated = 0,
  // 是
  Associated = 1,
}
