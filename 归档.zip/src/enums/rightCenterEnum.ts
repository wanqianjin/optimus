import type { PropType } from 'vue'

interface CreatePageType {
  manage_list_title?: string
  create_update_title: string
  create_update_api: PropType<(...arg: any[]) => Promise<any>> | null
}

// 权益发行页-抽屉不同场景操作枚举
export enum OperateDrawerEnum {
  // 权益发行
  Rights_Release = 'Rights_Release',
  // 累计发行记录
  Release_Records = 'Release_Records',
  // 库存池编辑
  Edit_StockPool = 'Edit_StockPool',
  // 券码池导入
  Import_CouponPool = 'Import_CouponPool',
  // 编辑券码池
  Edit_CouponPool = 'Edit_CouponPool',
  // 查看券码池
  View_CouponPool = 'View_CouponPool',
  // 创建多库存池
  Create_MultiStockPool = 'Create_MultiStockPool',
  // 余额作废
  Cancel_RemainingAmount = 'Cancel_RemainingAmount',
}

// 权益发行页-抽屉不同标题枚举
export enum OperateTitleEnum {
  Rights_Release = '权益发行',
  Release_Records = '累计发行记录',
  Edit_StockPool = '编辑库存池',
  Import_CouponPool = '导入券码ID',
  Edit_CouponPool = '编辑券码池',
  View_CouponPool = '查看券码池',
  Create_MultiStockPool = '新建库存池',
}

// 权益发行页-抽屉操作唯一id和title获取
export const operateDrawerMap: Map<OperateDrawerEnum, OperateTitleEnum> = (() => {
  const map = new Map<OperateDrawerEnum, OperateTitleEnum>()
  map.set(OperateDrawerEnum.Rights_Release, OperateTitleEnum.Rights_Release)
  map.set(OperateDrawerEnum.Release_Records, OperateTitleEnum.Release_Records)
  map.set(OperateDrawerEnum.Edit_StockPool, OperateTitleEnum.Edit_StockPool)
  map.set(OperateDrawerEnum.Import_CouponPool, OperateTitleEnum.Import_CouponPool)
  map.set(OperateDrawerEnum.Edit_CouponPool, OperateTitleEnum.Edit_CouponPool)
  map.set(OperateDrawerEnum.View_CouponPool, OperateTitleEnum.View_CouponPool)
  map.set(OperateDrawerEnum.Create_MultiStockPool, OperateTitleEnum.Create_MultiStockPool)
  return map
})()

// 不同场景新建库存池枚举
export enum StockPoolCreateSceneEnum {
  // 首次新建库存池
  FirstCreate = 'FirstCreate',
  // 非首次新建库存池
  OtherCreate = 'OtherCreate',
}

// 券/权益/权益包列表操作场景
export enum OperationMode {
  // 券
  'voucher' = 'voucher',
  // 权益
  'right' = 'right',
  // 权益包
  'rightPkg' = 'rightPkg',
  // 购车权益包
  'vehicleRightPkg' = 'vehicleRightPkg',
  // 权益查看
  'rightView' = 'rightView',
  // 权益包查看
  'rightPkgView' = 'rightPkgView',
  // 权益编辑
  'rightEdit' = 'rightEdit',
  // 权益包编辑
  'rightPkgEdit' = 'rightPkgEdit',
  // 权益复制
  'rightCopy' = 'rightCopy',
  // 权益包复制
  'rightPkgCopy' = 'rightPkgCopy',
  // 投放点位创建
  'launch' = 'launch',
  // 投放点位编辑
  'launchEdit' = 'launchEdit',
  // 投放点位查看
  'launchView' = 'launchView',
}

// 券/权益/权益包创建页-标题/数据接口的枚举
export const CreatePageContent = {
  voucher: {
    manage_list_title: '券',
    create_update_title: '新建券模板',
    create_update_api: null,
  },
  right: {
    manage_list_title: '权益列表',
    create_update_title: '新建权益',
    create_update_api: null,
  },
  rightPkg: {
    manage_list_title: '其他权益包',
    create_update_title: '新建权益包',
    create_update_api: null,
  },
  vehicleRightPkg: {
    manage_list_title: '购车权益包',
    create_update_title: '新建权益包',
    create_update_api: null,
  },
  rightView: {
    create_update_title: '查看权益',
    create_update_api: null,
  },
  rightPkgView: {
    create_update_title: '查看权益包',
    create_update_api: null,
  },
  rightEdit: {
    create_update_title: '编辑权益',
    create_update_api: null,
  },
  rightPkgEdit: {
    create_update_title: '编辑权益包',
    create_update_api: null,
  },
}

// 券/权益/权益包创建页-标题/数据接口的获取
export const createPageContentMap: Map<OperationMode, CreatePageType> = (() => {
  const map = new Map<OperationMode, CreatePageType>()
  map.set(OperationMode.voucher, CreatePageContent.voucher)
  map.set(OperationMode.right, CreatePageContent.right)
  map.set(OperationMode.rightPkg, CreatePageContent.rightPkg)
  map.set(OperationMode.vehicleRightPkg, CreatePageContent.vehicleRightPkg)
  map.set(OperationMode.rightView, CreatePageContent.rightView)
  map.set(OperationMode.rightPkgView, CreatePageContent.rightPkgView)
  map.set(OperationMode.rightEdit, CreatePageContent.rightEdit)
  map.set(OperationMode.rightPkgEdit, CreatePageContent.rightPkgEdit)
  return map
})()
