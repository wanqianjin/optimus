// 中台地图针对B端格环境ak
export enum ENV_AK {
  dev = 'DBQZ-8G26-AORR',
  test = 'TCT5-IM92-QZIA',
  staging = 'SQCT-B71T-GEU3',
  prod = 'P5OT-85W6-5J75',
}
