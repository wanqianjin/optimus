/**
 * @description: 页面管理
 */
import cmsPageRoute from './router/cmsPageRoute'
// import cmsAdminRoute from './router/cmsAdminRoute'
/**
 * @description: 内容管理
 */
// import operationRoute from './router/operationRoute'
/**
 * @description: 广告管理
 */
import adRoute from './router/adRoute'
/**
 * @description: 活动管理
 */
// import activityRoute from './router/activityRoute'
/**
 * @description: 积分管理
 */
// import integralRoute from './router/integralRoute'

/**
 * @description: 权益中心
 */
// import rightCenterRoute from './router/rightCenterRoute'
/**
 * @description: 成就中心
 */
// import achievementCenterRoute from './router/achievementCenter'

/* @description:  资源位管理
 */
// import resourceRoute from './router/resourceRoute'
/* @description: 评论管理
 */
// import commentRoute from './router/commentRoute'
/**
 * @description: 公众号管理
 */
import officialRoute from './router/officialRoute'
// import tagRoute from './router/tagRoute'
/**
 * @description: 渠道管理
 */
// import channelRoute from './router/channelRoute'

/**
 * @description: 协议管理
 */
// import agreementManageRoute from './router/agreementManageRoute'
/**
 * @description: 营销中心
 */
import marketingCenterRoute from './router/marketingRoute'

/*
 * @description: 消息触达
 */
import messageReachingRotes from './router/messageReachingRotes'

/**
 * @description: 用户中心
 */
import userCenterRoute from './router/userCenterRoute'

/**
 * @description: 用户中心
 */
import sceneRoute from './router/sceneRoute'

/**
 * @description: 投放页管理（留资）
 */
// import consultRoute from './router/consultRoute'
/**
 * @description: 操作日志查询
 */
// import operateLogRoute from './router/operateLogRoute'
/**
 * @description: 海报管理
 */
// import posterRoute from './router/posterRoute'

/**
 * @description: 搜索配置
 */
// import searchRoute from './router/searchRoute'
/**
 * @description: 云配置
 */
import cloudConfigRoute from './router/cloudConfig'
// 投放管理

import launchConfigRoute from './router/launchConfigRoute'
import contentRoute from './router/contentRoute'

import configManageRoute from './router/configManageRoute'
import projectManageRoute from './router/projectManageRoute'

export const dynamicRoutes = [
  cmsPageRoute,
  launchConfigRoute,
  // cmsAdminRoute,
  // consultRoute,
  // operationRoute,
  contentRoute,
  marketingCenterRoute,
  projectManageRoute,
  adRoute,
  // activityRoute,
  // integralRoute,
  messageReachingRotes,
  // rightCenterRoute,
  // achievementCenterRoute,
  // resourceRoute,
  // commentRoute,
  officialRoute,
  // tagRoute,
  // channelRoute,
  // agreementManageRoute,
  userCenterRoute,
  configManageRoute,
  sceneRoute,
  // operateLogRoute,
  // searchRoute,
  // posterRoute,
  cloudConfigRoute,
]
