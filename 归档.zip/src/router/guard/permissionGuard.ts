import type { Router, RouteRecordRaw } from 'vue-router'

import { usePermissionStoreWithOut } from '/@/store/modules/permission'
import { useUserStoreWithOut } from '/@/store/modules/user'
import { PAGE_NOT_FOUND_ROUTE, NOAUTH_ROUTE } from '/@/router/routes/basic'
import { openWindow, getQueryObject } from '/@/utils'
import { useGlobSetting } from '/@/hooks/setting'
import { filterPermissionRoutes } from '/@/router/helper/permissionHelper'
import { useWatermark } from '/@/hooks/web/useWatermark'
// import { getStaticRouterOrder } from '/@/utils/http/axios'
import { getJet } from '/@/utils/track'
import * as Sentry from '@sentry/vue'
import { BlindWatermark } from 'watermark-js-plus'

const globSetting = useGlobSetting()
const env = import.meta.env.MODE || 'prod'
console.log(env, 'env')

export function createPermissionGuard(router: Router) {
  const userStore = useUserStoreWithOut()
  const permissionStore = usePermissionStoreWithOut()
  router.beforeEach(async (to, _, next) => {
    const token = userStore.getToken
    getJet(userStore.userInfo?.userId)

    // mock环境下，不需要进行登陆，先写死token
    if (env === 'mock') {
      userStore.setToken('mock-token')
    }
    // 如果 token 不存在
    if (!token) {
      // 判断白名单页面
      if (to.meta.ignoreAuth) {
        next()
        return
      }

      const callbackToken = getQueryObject().token

      if (callbackToken) {
        userStore.setToken(callbackToken)
      } else {
        // 跳转统一登录页
        const appId = globSetting.appId
        // 登录回跳地址更改为从哪来回哪去
        // 如果url上有token参数，需要处理掉，避免pass获取到过期的token
        const tokenReg = /[&]?token=[^&#?]+/g
        const redirectUrl = location.href.replace(tokenReg, '')
        const passportUrl = globSetting.passportUrl
        const openUrl = `${passportUrl}/authorize?response_type=token&client_id=${appId}&redirect_uri=${encodeURIComponent(
          redirectUrl,
        )}`
        openWindow(openUrl, { target: '_self' })
        // 此时禁止后续执行...
        return
      }
    }

    if (permissionStore.getIsDynamicAddedRoute) {
      next()
      return
    }

    // 获取本地的路由定义
    const routes = await permissionStore.buildRoutesAction()

    let routeList = routes
    let isCheckAuth = globSetting.isRouterCheckAuth === 'true'
    // 这里防止环境变量中的被修改...
    if (env === 'prod' || env === 'staging') {
      isCheckAuth = true
    }
    if (isCheckAuth) {
      // 获取权限信息和用户信息，并根据权限信息过滤路由
      const [resRouteList, resUserInfo] = await Promise.all([
        filterPermissionRoutes(routes),
        userStore.getUserInfoAction(),
      ])
      // 这里确保 token 有效才继续向下执行，否则：getUserInfoAction如果拿到token无效（axios/index）， 清空token，然后跳转登录，同时这里又继续执行 next(), 又会到路由守卫 beforeEach，走到 callbackToken setToken一个无效的token
      if (!resUserInfo) {
        // 这里针对无应用权限的特殊处理（目前无应用权限是拿不到用户信息的）
        if (to.name === 'PageNotAuth') {
          permissionStore.setDynamicAddedRoute(true)
          next({ path: to.fullPath, query: to.query, replace: true })
        }
        return
      }
      routeList = resRouteList
    } else {
      await userStore.getUserInfoAction()
    }

    // 动态添加路由
    routeList.forEach((route) => {
      router.addRoute(route as unknown as RouteRecordRaw)
    })
    router.addRoute(PAGE_NOT_FOUND_ROUTE as unknown as RouteRecordRaw)

    // 设置首页地址, 如果没有则跳转到无权限页面或者维护通知页面（维护开启时）
    // const homePath =
    //   (routeList[0] && routeList[0].path) ||
    //   [...new Set(getStaticRouterOrder())][0] ||
    //   NOAUTH_ROUTE.path
    const homePath = (routeList[0] && routeList[0].path) || NOAUTH_ROUTE.path
    userStore.setHomePath(homePath)

    permissionStore.setDynamicAddedRoute(true)

    // 添加水印
    const { setWatermark } = useWatermark()
    const { username, email } = userStore.getUserInfo
    setWatermark(`${username}`)

    // 添加暗水印==> 用来溯源
    const watermark = new BlindWatermark({
      content: `${username}-${email}`,
      width: 200,
      height: 200,
      onSuccess: () => {
        // console.log('create watermark success')
      },
    })
    watermark.create()

    Sentry.setUser({ username: username })

    delete to.query.token
    if (to.name === 'Root' || to.name === 'PageNotAuth') {
      next({ path: homePath, query: to.query, replace: true })
    } else {
      next({ path: to.fullPath, query: to.query, replace: true })
    }
  })
}
