import type { Router } from 'vue-router'
import { configureDynamicParamsMenu } from '../helper/menuHelper'
import { Menu } from '../types'
import { PermissionModeEnum } from '/@/enums/appEnum'
import { useAppStoreWithOut } from '/@/store/modules/app'

import { usePermissionStoreWithOut } from '/@/store/modules/permission'

export function createParamMenuGuard(router: Router) {
  const permissionStore = usePermissionStoreWithOut()
  router.beforeEach(async (to, _, next) => {
    if (to?.path === '/activity/register-create') {
      if (to?.query?.mode === 'view') {
        to.meta.title = '查看活动'
      } else if (to?.query?.mode === 'edit') {
        to.meta.title = '编辑活动'
      }
    } else if (to?.path === '/right-center/create') {
      if (to?.query?.content == 'right' || to?.query?.content == 'rightEdit') {
        to.meta.title = '创建权益'
      } else if (to?.query?.content == 'rightPkg' || to?.query?.content == 'rightPkgEdit') {
        to.meta.title = '创建权益包'
      }
    }
    // filter no name route
    if (!to.name) {
      next()
      return
    }

    // menu has been built.
    if (!permissionStore.getIsDynamicAddedRoute) {
      next()
      return
    }

    let menus: Menu[] = []
    if (isBackMode()) {
      menus = permissionStore.getBackMenuList
    } else if (isRouteMappingMode()) {
      menus = permissionStore.getFrontMenuList
    }
    menus.forEach((item) => configureDynamicParamsMenu(item, to.params))

    next()
  })
}

const getPermissionMode = () => {
  const appStore = useAppStoreWithOut()
  return appStore.getProjectConfig.permissionMode
}

const isBackMode = () => {
  return getPermissionMode() === PermissionModeEnum.BACK
}

const isRouteMappingMode = () => {
  return getPermissionMode() === PermissionModeEnum.ROUTE_MAPPING
}
