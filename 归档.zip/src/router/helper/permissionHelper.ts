import type { AppRouteRecordRaw } from '/@/router/types'

import { cloneDeep } from 'lodash-es'
import { transformRouteToMenu } from '/@/router/helper/menuHelper'
import { usePermissionStoreWithOut } from '/@/store/modules/permission'
import { useUserStoreWithOut } from '/@/store/modules/user'

// 过滤有权限的路由&缓存路由
export async function filterPermissionRoutes(
  routes: AppRouteRecordRaw[],
): Promise<AppRouteRecordRaw[]> {
  const userStore = useUserStoreWithOut()
  const permissionStore = usePermissionStoreWithOut()

  let routesClone: AppRouteRecordRaw[] = cloneDeep(routes)
  const permission: string[] = (await userStore.getPermissionRoutesAction()) || []
  // 过滤有权限的路由
  if (routesClone && permission) {
    routesClone = filterPermissionTree(routesClone, permission)
  }
  routesClone = getTree(routesClone)
  console.log('permissionRoutes', routesClone)
  // 缓存路由
  userStore.setAllRoutes(routesClone)
  //  Background routing to menu structure
  const backMenuList = transformRouteToMenu(routesClone)
  permissionStore.setBackMenuList(backMenuList)
  return routesClone
}

// 过滤出有权限的路由
const filterPermissionTree = (
  routes: AppRouteRecordRaw[],
  permission: string[],
  isParentAuthCheck?: string[] | boolean, // true 所有子路由都支持 数组为匹配的子路由支持
): AppRouteRecordRaw[] => {
  const newTree: AppRouteRecordRaw[] = []
  const flagMap = {}
  const filterArr: AppRouteRecordRaw[] = []
  // 确保过滤出来得路由顺序正确，不能依赖权限配置的顺序
  routes.forEach((v) => {
    // 只考虑两层，更多层级情况暂未考虑
    if (Array.isArray(isParentAuthCheck)) {
      if (isParentAuthCheck.includes(v.path)) {
        filterArr.push(v)
      }
    }
    // 处理当前节点
    else if (isParentAuthCheck || v.meta.ignoreAuth) {
      filterArr.push(v)
    } else {
      for (let i = 0; i < permission.length; i++) {
        const path = permission[i]
        const reg = new RegExp(v.path, 'g')
        // 有redirect属性的路由使用正则匹配
        if (v.redirect && !flagMap[v.path]) {
          const arr = v.path?.match(/\//g)
          // 包含2+个\可以用正则匹配，否则全等判断
          if (arr && arr.length >= 2) {
            if (reg.test(path)) {
              flagMap[v.path] = true
              filterArr.push(v)
            }
          } else {
            if (v.path?.split('/')[1] === path.split('/')[1]) {
              flagMap[v.path] = true
              filterArr.push(v)
            }
          }
        } else if (v.path == path) {
          filterArr.push(v)
        }
      }
    }
  })
  newTree.push(...filterArr)
  newTree.forEach((v) => {
    // 将外层的 ignoreAuth 带入 children 层
    v.children && (v.children = filterPermissionTree(v.children, permission, v.meta.ignoreAuth))
    // 将父级路由 redirect 指向子路由第一个
    if (v.redirect && v.children?.length) {
      v.redirect = v.children[0].path
    }
  })
  return newTree
}

// 将2级菜单变成多级
const getTree = (routesClone: AppRouteRecordRaw[], level = 1) => {
  const arr: any = []
  const hasRedirect = routesClone.filter((i) => i.redirect)

  if (hasRedirect.length && level > 1) {
    routesClone.forEach((i) => {
      // 获取path的层级
      const length = i.path?.match(/\//g)?.length
      // 如果是层级是当前的层级
      if (length && length === level) {
        // 我理解，有redirect的就应该有下级目录，这个我们可以约定
        if (i.redirect) {
          // 设置空数据
          if (!i.children) {
            i.children = []
          }
          // 将匹配的下级目录塞进去
          routesClone.forEach((j) => {
            if (j.path.includes(i.path) && j.path !== i.path) {
              i.children?.push(j)
            }
          })
        }
        arr.push(i)
        if (i.children && i.children.length) {
          i.children = getTree(i.children, length + 1)
        }
      }
    })
  } else {
    routesClone.forEach((i) => {
      arr.push(i)
      if (i.children && i.children.length) {
        i.children = getTree(i.children, 2)
      }
    })
  }
  return arr
}
