import { MockMethod } from 'vite-plugin-mock'

export default [
  {
    url: '/api/activity-backend-server/activity/definition/detail',
    timeout: 1000,
    method: 'get',
    response: () => {
      return {
        code: 0,
        data: {
          basicInfo: {
            // 活动基本信息
            activityTitle: '抽奖',
            activityDesc: '223',
            activityType: 102,
            activityTypeDesc: '抽奖',
            startTime: '2023-02-13 11:28:58',
            endTime: '2023-03-02 11:28:59',
            city: [],
          },
          activityUsersType: 0,
          activityUsers: [],
          triggerConditions: {
            // 触发条件
            selectedConditions: ['INVITEE_REGISTER', 'INVITEE_ASSISTANCE'],
            combine: [['INVITEE_REGISTER', 'INVITEE_ASSISTANCE']],
          },
          limitConditions: {
            // 限制条件
            selectedConditions: ['INVITEE_OBJECT'],
            combine: [['INVITEE_OBJECT']],
            inviteeLimitInfo: {
              // 被邀请人的限制条件
              inviteeUserStatus: '', //全部对象还是包
              inviteeUserIds: [],
              inviteeCrowdsId: '',
            },
          },
          invitationAwardInfo: {
            inviterAwardType: '', //人头类型 /总数类型
            inviterUserNum: '', //邀请人数
            inviterAwardId: '', // 邀请人的奖励
            inviterReceiveStatus: 'NONE_ACTIVE_RECEIVE', //是否主动领取
            inviteeAwardType: 'no',
            inviteeAwardId: '', //被邀请人奖励
          },
        },
      }
    },
  },
  {
    url: '/api/activity-backend-server/activity/strategyCondition/types',
    timeout: 1000,
    method: 'get',
    response: () => {
      return {
        code: 0,
        data: {
          triggerConditions: [
            {
              value: 'INVITEE_REGISTER',
              label: '受邀人注册',
            },
            {
              value: 'INVITEE_ASSISTANCE',
              label: '受邀人助力',
            },
          ],
          limitConditions: [
            {
              value: 'INVITEE_OBJECT',
              label: '受邀对象',
            },
          ],
          inviterAwards: [
            {
              value: 'ALL_EXCHANGE',
              label: '总数兑换',
            },
            {
              value: 'SINGLE_EXCHANGE',
              label: '人头奖励"',
            },
            {
              value: 'NUMBER_EXCHANGE',
              label: '人数兑换',
            },
          ],
          inviteeAwards: [
            {
              value: 'INVITEE_SINGLE',
              label: '发放权益',
            },
          ],
          awardPoolType: [
            {
              value: 'EQUITY_ATOMIC_GRANT',
              label: '权益',
            },
            {
              value: 'EQUITY_PACKAGE_GRANT',
              label: '权益包',
            },
          ],
        },
      }
    },
  },
  // {
  //   url: '/api/activity-backend-server/activity/equity/types',
  //   timeout: 1000,
  //   method: 'get',
  //   response: () => {
  //     return {
  //       code: 0,
  //       data: [
  //         {
  //           label: '原子权益',
  //           value: 1,
  //         },
  //         {
  //           label: '权益包',
  //           value: 2,
  //         },
  //       ],
  //     }
  //   },
  // },
] as MockMethod[]
