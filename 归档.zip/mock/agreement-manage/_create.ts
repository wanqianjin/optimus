import { MockMethod } from 'vite-plugin-mock'

export default [
  {
    url: '/api/user-backend/contract/user/list',
    timeout: 1000,
    method: 'post',
    response: () => {
      return {
        code: 0,
        data: {
          total: 2,
          list: [
            {
              username: 'yechun.sun',
              name: '孙业春',
            },
            {
              username: 'adadf',
              name: '了了',
            },
          ],
        },
      }
    },
  },
] as MockMethod[]
