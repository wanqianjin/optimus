import { resultSuccess, resultError, getRequestToken, requestParams } from '../_util'
import { MockMethod } from 'vite-plugin-mock'
import { createFakeUserList } from './user'

// 内容管理
const operationRoute = {
  path: '/operation',
  name: 'Operation',
  component: 'LAYOUT',
  redirect: '/operation/content-list',
  meta: {
    icon: 'ion:albums-outline',
    title: '内容管理',
  },
  children: [
    {
      path: 'content-list',
      name: 'ContentList',
      meta: {
        title: '内容列表',
      },
      component: '/operation/content-list/index',
    },
  ],
}

const adRoute = {
  path: '/ad',
  name: 'Ad',
  component: 'LAYOUT',
  redirect: '/ad/ad-list',
  meta: {
    icon: 'ion:settings-outline',
    title: '广告管理',
  },
  children: [
    {
      path: 'ad-list',
      name: 'AdList',
      meta: {
        title: '广告列表',
      },
      component: '/demo/system/password/index',
    },
  ],
}

export default [
  {
    url: '/basic-api/getMenuList',
    timeout: 1000,
    method: 'get',
    response: (request: requestParams) => {
      const token = getRequestToken(request)
      if (!token) {
        return resultError('Invalid token!')
      }
      const checkUser = createFakeUserList().find((item) => item.token === token)
      if (!checkUser) {
        return resultError('Invalid user token!')
      }
      const id = checkUser.userId
      let menu: Object[]
      switch (id) {
        case '1':
          menu = [operationRoute, adRoute]
          break

        default:
          menu = []
      }

      // console.log(menu);

      return resultSuccess(menu)
    },
  },
] as MockMethod[]
